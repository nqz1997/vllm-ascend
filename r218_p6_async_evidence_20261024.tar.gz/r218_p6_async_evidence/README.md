# P6 main 默认异步缺陷定位证据（2026-10-24，第 3 波设备轮 2）

组合：main 移植 `oscar-int2/m-port-full-ut @ 81295d899`（容器 r218-main-verify，nightly 镜像
CANN 9.2.0/torch 2.10.0/torch_npu 2.10.0.post7/vLLM 0.31.0），Qwen3-8B，NPU 7，eager，
B=1 1080 token 最小复现，REPS=12。**与冻结组合服务结果分账，本目录全部为 main 诊断。**

## 结论摘要（详见 delivery/PR_ADVANCE_20261024.md §3.5/§3.6/§9）
- 默认 async 8/12 输出坏（1 轻度+7 个 '!!!!'）vs blocking 0/12（leg_outputs/ 权威判据）。
- 首个分歧张量＝HP 环 bf16 行 recent 窗；分歧点 key_rot/value_rot/q/INT2 页哈希与 blocking 同。
- NaN 仅 recent 窗（张量 hk/hv 行 963–1023 起、prefix [0,128) 零 NaN），逐 rep 单调增长
  （62,464→144,384→319,488 元素/层，约每代 1,310,720）＝跨代环残留。
- ⚠ 口径（主 Agent 独立复核）："8/12"为输出级判据；朴素 ring 全张量哈希对比=11/12 分歧
  （含槽位布局敏感区良性漂移）。引用以输出级为准。
- ⚠ 表述边界（2026-10-24 第 4 波用户裁定）："输入 src 一致 ⇒ 写侧无罪"与"中段输出一致 ⇒
  中段算子排除"**均不成立**——不能排除写越界/内存副作用；写入者审计在第 4 波进行中。
- 修复状态：两个环写机制候选不治（R166_STREAMFIX=ring 12/12、R164_EAGER_SLIDE 9/12）；
  **可合入最小修复未取得，缺陷 OPEN**；NaN 种子来源两候选（外部越界写 vs 环读侧放大）未闭合。

## 目录
- `raw/p6{a_mdiag_async,b_mdiag_blk,g_krv_async,h_krv_blk,k_row_async,l_row_blk,l_row_blk2}/`
  —— jsonl 哈希流（src_k/src_v/src_ks/q/ring_k/ring_v/rk_*/rv_* 逐记录哈希）与 p6k 的 96 个
  环行张量（.pt，键 idx/layer/hk/hv，形状 [1024,8,128]）。
- `minimal_repro/` —— async_diag.sh（腿 runner）、p6_mdiag_diff.py（哈希流对比）、p6_compare.py
  （独立参考，合成往返已验证）、x1080x1_req.json（请求）、p6*.sh（本波腿驱动）。
  复现：容器内起服（int2exp 姿态）后 `REPS=12` 循环 curl，对照组加 `ASCEND_LAUNCH_BLOCKING=1`。
- `leg_outputs/` —— 每腿 analysis.txt（total/bad 权威判据）、status、battery 原始响应。
- `SHA256SUMS` —— 全部文件校验（原始 /tmp 副本在案，A 线第 4 波继续往 /tmp 增量写入）。

生成：主 Agent 2026-10-24 15:5xZ；不修改任何已有数值。
