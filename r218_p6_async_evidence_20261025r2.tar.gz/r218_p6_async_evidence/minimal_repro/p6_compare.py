#!/usr/bin/env python3
"""R218 P6 offline comparator for INT2 middle dumps (pure torch, CPU).

Modes:
  --qin A_DIR B_DIR      compare quantizer input/output dumps (write side)
  --mid A_DIR B_DIR      compare MIDCAP2 middle-op operand/output dumps
  --ref DIR              pure-torch reference from the dump's own inputs,
                         compared against the captured kernel out_h/lse_h
                         (independent adjudication of the custom op)

Dumps are produced in-container by R218_QINDUMP=1 (quantcache) and
R216_LSEDUMP=1 (MIDCAP2 in middle_candidate; files r218_midcap2_*.pt).
"""
import argparse
import glob
import math
import os

import torch


def thash(t):
    import hashlib
    return hashlib.sha256(t.contiguous().cpu().view(torch.uint8).numpy().tobytes()).hexdigest()[:12]


def cmp_tensor(name, a, b):
    if a is None or b is None:
        return f"{name}: MISSING a={a is not None} b={b is not None}"
    if a.shape != b.shape:
        return f"{name}: SHAPE {tuple(a.shape)} vs {tuple(b.shape)} DIFFER"
    if a.dtype != b.dtype:
        same = torch.equal(a.to(b.dtype), b)
    else:
        same = torch.equal(a, b)
    if same:
        return f"{name}: IDENTICAL ({thash(a)})"
    d = (a.float() - b.float())
    den = max(float(b.float().abs().max()), 1e-9)
    return (f"{name}: DIFFER sha={thash(a)}/{thash(b)} "
            f"maxabs={float(d.abs().max()):.6g} relmax={float(d.abs().max())/den:.3g} "
            f"ndiff={int((d != 0).sum())}/{d.numel()}")


def load_set(d, pat):
    return sorted(glob.glob(os.path.join(d, pat)))


def compare_qin(da, db):
    fa, fb = load_set(da, "qin_*.pt"), load_set(db, "qin_*.pt")
    print(f"[qin] A={len(fa)} files, B={len(fb)} files")
    for i, (x, y) in enumerate(zip(fa, fb)):
        a, b = torch.load(x, map_location="cpu"), torch.load(y, map_location="cpu")
        print(f"-- pair {i} route={a.get('route')} layer={a.get('layer')} T={a.get('T')} | "
              f"B route={b.get('route')} layer={b.get('layer')} T={b.get('T')}")
        for k in ["key_in", "value_in", "k_packed", "k_scale", "k_zero",
                  "v_packed", "v_scale", "v_zero"]:
            print("   " + cmp_tensor(k, a.get(k), b.get(k)))


def unpack_codes(packed_u8):
    """[..., S, nkv, D/4] uint8 -> float codes in [0,3], shape [..., S, nkv, D].

    Empirically pinned against the serve-path C++ quantizer via the MIDCAP2
    captures (p6e/p6f, wave 4): the packing is LANE-INTERLEAVED — byte j,
    nibble i maps to dim position i*(D/4)+j (NOT 4-consecutive like the
    Python _pack_int2_to_uint8 fallback), nibble shifts are little-endian
    (0,2,4,6), and the affine zero absorbs the level offset (raw [0,3] codes,
    no -2 shift). See PR_ADVANCE wave-4 T1 for the variant sweep.
    """
    p = packed_u8.to(torch.uint8)
    v = [(p >> s) & 0x03 for s in (0, 2, 4, 6)]
    st = torch.stack(v, dim=-1)              # [..., D/4, 4]
    return st.transpose(-1, -2).flatten(-2).float()   # lane-interleave -> [..., D]


def dequant(pages, scale, zero, S, nkv, hd):
    """pages [nb, bs, nkv, hd//4] uint8 (logical order), scale/zero [nb, bs, nkv]."""
    codes = unpack_codes(pages)                       # [nb, bs, nkv, hd]
    codes = codes.reshape(S, nkv, hd)
    s = scale.reshape(S, nkv, 1).float()
    z = zero.reshape(S, nkv, 1).float()
    return (codes - z) * s


def ref_attention(q_bnsd, kp, ks, kz, vp, vs, vz, askv, nq, nkv, hd, scale, bs):
    """Pure-torch three-tier MIDDLE reference in the rotated basis.

    q: [1, nq, 1, hd] (already rotated). GQA mapping: q head n -> kv head
    n // (nq // nkv) (block-contiguous grouping, the npu FIA/vendor
    convention). Returns out [nq, hd] fp32, lse [nq] fp32.
    """
    nb = kp.shape[0]
    S = nb * bs
    xk = dequant(kp, ks, kz, S, nkv, hd)
    xv = dequant(vp, vs, vz, S, nkv, hd)
    mid = int(askv[0])
    xk, xv = xk[:mid].double(), xv[:mid].double()    # [mid, nkv, hd]
    q = q_bnsd[0, :, 0, :].double()                  # [nq, hd]
    rep = nq // nkv
    kvh = torch.arange(nq, dtype=torch.long) // rep          # q head -> kv head
    kk = xk.index_select(1, kvh)                      # [mid, nq, hd]
    vv = xv.index_select(1, kvh)                      # [mid, nq, hd]
    scores = torch.einsum("qd,sqd->qs", q, kk) * scale        # [nq, mid]
    lse = torch.logsumexp(scores, dim=-1)                     # [nq]
    p = torch.exp(scores - lse.unsqueeze(-1))
    out = torch.einsum("qs,sqd->qd", p, vv)                   # [nq, hd]
    return out, lse


def run_ref(d):
    fs = load_set(d, "r218_midcap2_*.pt") or load_set(d, "midcap2_*.pt") or load_set(d, "*.pt")
    for f in fs:
        t = torch.load(f, map_location="cpu")
        if "k" not in t or "q" not in t:
            print(f"[ref] {f}: not a MIDCAP2 capture, skip")
            continue
        nq, nkv, bs, hd = t["nq"], t["nkv"], t["bs"], t["hd"]
        out, lse = ref_attention(t["q"], t["k"], t["ks"], t["kz"],
                                 t["v"], t["vs"], t["vz"], t["askv"],
                                 nq, nkv, hd, t["scale"], bs)
        oh = t["out_h"].float().reshape(nq, hd)
        lh = t["lse_h"].float().reshape(nq)
        cos = torch.nn.functional.cosine_similarity(
            out.flatten(), oh.flatten(), dim=0)
        print(f"[ref] {os.path.basename(f)} layer={t.get('layer')} mid={t['askv']} "
              f"nb={t['k'].shape[0]}: out cos={float(cos):.6f} "
              f"maxabs={float((out-oh).abs().max()):.4g} "
              f"lse maxabs={float((lse-lh).abs().max()):.4g} "
              f"ref_lse[0:3]={lse[:3].tolist()} kern_lse[0:3]={lh[:3].tolist()}")


def compare_mid(da, db):
    fa, fb = load_set(da, "*midcap2*.pt"), load_set(db, "*midcap2*.pt")
    print(f"[mid] A={len(fa)} files, B={len(fb)} files")
    for i, (x, y) in enumerate(zip(fa, fb)):
        a, b = torch.load(x, map_location="cpu"), torch.load(y, map_location="cpu")
        print(f"-- pair {i} A layer={a.get('layer')} mid={a.get('askv')} | "
              f"B layer={b.get('layer')} mid={b.get('askv')}")
        for k in ["q", "k", "v", "ks", "kz", "vs", "vz", "btrow", "out_h", "lse_h"]:
            print("   " + cmp_tensor(k, a.get(k), b.get(k)))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--qin", nargs=2, metavar=("A", "B"))
    ap.add_argument("--mid", nargs=2, metavar=("A", "B"))
    ap.add_argument("--ref", metavar="DIR")
    a = ap.parse_args()
    if a.qin:
        compare_qin(*a.qin)
    if a.mid:
        compare_mid(*a.mid)
    if a.ref:
        run_ref(a.ref)
