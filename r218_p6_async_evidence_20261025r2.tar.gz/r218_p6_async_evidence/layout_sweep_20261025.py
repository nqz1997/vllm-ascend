# B1 verification sweep: unpack layout x GQA mapping on the HEALTHY capture #1
# (nq=32, nkv=8, rep=4, bs=128, hd=128, mid=58). Only the combination pinned in
# verify_scripts/p6_compare.py (lane-interleaved unpack + block-contiguous GQA)
# should reach cos ~ 0.9999; every wrong combination must collapse.
import itertools, torch, torch.nn.functional as F

CAP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval/p6_async_evidence/raw/p6e_cap_async/r218_midcap2_1.pt"

def unpack(p, mode, shifts):
    v = [(p >> s) & 0x03 for s in shifts]
    st = torch.stack(v, dim=-1)
    if mode == "lane":      # byte j, nibble i -> dim i*(D/4)+j
        return st.transpose(-1, -2).flatten(-2).float()
    else:                   # "flat": 4-consecutive, dim j*4+i
        return st.flatten(-2).float()

t = torch.load(CAP, map_location="cpu")
nq, nkv, bs, hd, scale = t["nq"], t["nkv"], t["bs"], t["hd"], t["scale"]
rep = nq // nkv
nb = t["k"].shape[0]; S = nb * bs; mid = int(t["askv"][0])

def ref(mode, shifts, gqa):
    xk = (unpack(t["k"], mode, shifts).reshape(S, nkv, hd) - t["kz"].reshape(S, nkv, 1).float()) * t["ks"].reshape(S, nkv, 1).float()
    xv = (unpack(t["v"], mode, shifts).reshape(S, nkv, hd) - t["vz"].reshape(S, nkv, 1).float()) * t["vs"].reshape(S, nkv, 1).float()
    xk, xv = xk[:mid].double(), xv[:mid].double()
    q = t["q"][0, :, 0, :].double()
    if gqa == "block":       kvh = torch.arange(nq) // rep
    elif gqa == "interleaved": kvh = torch.arange(nq) % nkv
    else: raise ValueError
    kk = xk.index_select(1, kvh); vv = xv.index_select(1, kvh)
    scores = torch.einsum("qd,sqd->qs", q, kk) * scale
    lse = torch.logsumexp(scores, dim=-1)
    out = torch.einsum("qs,sqd->qd", torch.exp(scores - lse.unsqueeze(-1)), vv)
    return out, lse

oh = t["out_h"].float().reshape(nq, hd); lh = t["lse_h"].float().reshape(nq)
print(f"capture={CAP.rsplit('/',2)[-2]}/{CAP.rsplit('/',1)[-1]} nq={nq} nkv={nkv} rep={rep} bs={bs} hd={hd} mid={mid}")
print(f"{'unpack':<26}{'gqa':<14}{'out_cos':>10}{'lse_maxabs':>12}")
for (mode, shifts, mname), gqa in itertools.product(
        [("lane", (0,2,4,6), "lane-interleaved LE"), ("flat", (0,2,4,6), "4-consecutive LE"),
         ("lane", (6,4,2,0), "lane-interleaved BE"), ("flat", (6,4,2,0), "4-consecutive BE")],
        ["block", "interleaved"]):
    out, lse = ref(mode, shifts, gqa)
    cos = float(F.cosine_similarity(out.flatten(), oh.flatten(), dim=0))
    print(f"{mname:<26}{gqa:<14}{cos:>10.6f}{float((lse-lh).abs().max()):>12.4g}")
