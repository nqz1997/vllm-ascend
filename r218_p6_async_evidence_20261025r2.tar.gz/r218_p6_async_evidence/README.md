# P6 main 默认异步缺陷定位证据（2026-10-24/25，第 3+4 波）

## 最新有效版本（先读此块）

- **当前发布包：v4** `r218_p6_async_evidence_20261025r2.tar.gz`（74 个内容文件＝v3 的 71 项
  中替换 `minimal_repro/p6_compare.py` 为修复版，新增 `ref_reproduction_20261025.txt`、
  `layout_sweep_20261025.py`、`RAW_MANIFEST`、本 README v4 版本块；包级 sha256 见随包
  `.sha256` 文件与外部索引 `ARTICLE_MATERIALS_ENTRY.md` §8，不在包内自引）。
  包内校验：`cd r218_p6_async_evidence && sha256sum -c SHA256SUMS`（73 项，不含 SHA256SUMS 自身）。
- **v3 `r218_p6_async_evidence_20261025.tar.gz`（sha256 `92ac574b…ae4bee7`）已 SUPERSEDED**：
  其 `minimal_repro/p6_compare.py` 为缺陷版 `c72b874c…`（GQA reshape 必崩＋4-consecutive
  unpack 布局错）。引用脚本一律以 v4 内 `fe2fce54…` 为准。历史 v1/v2（`..._20261024.tar.gz`）
  亦 SUPERSEDED。
- **B1 修正记录（2026-10-25，子 Agent B 第 5 波）**：`minimal_repro/p6_compare.py` 两处缺陷
  （① GQA einsum 后 `view(nkv, rep, mid)` 对 nq=32/nkv=8 不成立；② unpack 布局应为
  lane-interleaved）已修复并逐字节对齐主 Agent 实跑版（`fe2fce54…`）。4 份 MIDCAP2 捕获
  CPU 复现全部退出码 0、结论逐字复现（async#2 cos=0.000000/kern_lse=−9999×3、blocking#2
  cos=0.999994、捕获#1 两腿 0.999927）；8 组合布局×GQA 判别扫描证明修复方向唯一。
  全记录：`ref_reproduction_20261025.txt`（命令/退出码/完整输出）＋判别脚本
  `layout_sweep_20261025.py`。
- 当前权威结论入口：`PR_ADVANCE_20261024.md` §3.5/§3.6/§9/§10；本 README 正文为摘要。

## 组合

main 移植 `oscar-int2/m-port-full-ut @ 81295d899`（容器 r218-main-verify，nightly 镜像
CANN 9.2.0/torch 2.10.0/torch_npu 2.10.0.post7/vLLM 0.31.0），Qwen3-8B，NPU 7，eager，
B=1 1080 token 最小复现，REPS=12。**与冻结组合服务结果分账，本目录全部为 main 诊断。**

## 当前结论（第 4 波为准）
- 输出级：async bad 8–12/12（探针依赖）vs blocking 0/12；**轻探针 WTRACE2 不再掩盖**（11/12＝
  未探针基线；重探针 3 sync/调用会掩盖——探针同步点本身改变竞态）。
- **首事件**：rep1/step4/L30 q/kr/vr **同时**全 0x7FFF（＝f32 0x7FFFFFFF/INT32_MAX 位型截断，
  非算术 NaN；哈希 9a887382f507 经主 Agent 独立构造复证）；前 5 层调用健康；**该时刻 L8 环
  逐字节干净 ⇒ 环读/写被排除**；污染经隐层流（前层 attn/mid/merge/MLP）进入 QKV。步级瞬态
  级联（L30-35→…→L4-35），不跨 token 边界。
- **载体层实锤（missing-write 报成功）**：MIDCAP2 async 捕获 #2 在全量
  `torch.npu.synchronize()` 后 lse 全 −9999（`int2_op_launch_lse_fast_r152.cpp:137`
  前置哨兵 `lse.fill_(-9999)`）＋out 垃圾 3.2e36，池载体为 torch.zeros（`middle_candidate.py:95-99`）
  ——真实 missing-write 且 enqueue 报成功（launcher 返回 `(r,ws,lr,g_ws_hits)`，消费方只看 r）。
  独立复现：`p6_compare.py --ref <dir>`（修复版；async#2 cos=0.000000、kern_lse=[−9999×3]；
  blocking#2 cos=0.999994；捕获#1 两腿同 cos=0.999927＝健康时数值正确）。
  **表述边界**：哨兵留存不能单独证明"算子从未写入"——哨兵 fill 也可能晚于内核执行（发射顺序
  未定）；A 线第 5 波正在验证发射顺序假设，采用本目录材料时按此边界措辞，不预设其结论。
- T1 三分类：有效数据损坏全在合法 recent 读集内（in=1065/2345/3625/4905，outside=0）
  → 污染进入注意力；未用槽位未捕获；合法重绑有限。
- 共享态风险（未定罪）：全局 g_ws 工作区跨全部层/调用、`_r112_opool` 池载体跨 36 层、
  kr_ptr 步内跨层复用。blocking=launch 串行化（结构差异，假设，非 CANN 归因）。
- **OPEN**：产生 0x7FFFFFFF 位型的具体写入指令未定位；无可合入最小修复。
- 口径纪律：输入/输出哈希一致只是观测，不能宣称"写侧无罪"或排除算子内存副作用（排除全部
  基于首事件/哨兵直接证据，见下方更正附录第 2 条）。

## 目录
- `raw/p6{a,b,g,h,k,l,l2}*` —— 第 3 波（哈希流+96 环张量；p6a/b 配对 async vs blocking）。
- `raw/p6e_cap_async`、`raw/p6f_cap_blk` —— 第 4 波 MIDCAP2 实操作数捕获（**哨兵实锤证据**；
  `p6_compare.py --ref <dir>`（修复版）可独立重跑复现）。
- `raw/p6o2_w2_async` —— WTRACE2 轻探针 onset 捕获（9936 条 jsonl＋66 dump＋onset01-30.pt＋
  `analysis/wtrace2_onset_analysis.txt` 首事件分析）。
- `minimal_repro/` —— async_diag.sh、**p6_compare.py（2026-10-25 修复版 fe2fce54…，见顶部
  B1 修正记录）**、p6_t1_ringclass.py、wtrace2_patch.py（轻探针补丁）、p6*.sh 腿驱动、x1080x1_req.json。
- `leg_outputs/` —— 每腿 analysis/status/battery 原始判据。
- `ref_reproduction_20261025.txt`＋`layout_sweep_20261025.py` —— B1 修复复现记录与判别扫描。
- 校验清单（**三者用途不同，勿混用**）：
  - `SHA256SUMS` —— 本目录（全量 229＋新增件）当前生效校验清单；
  - `RAW_MANIFEST` —— 229 项原始材料清单快照（修复 p6_compare.py 前口径，含缺陷版 sha）；
  - `PACKED_MANIFEST` —— **v3 发布包内实际 71 个文件**的清单（含 sha256）；子集包校验用它，
    用 229 项全量清单会把未打包文件误报缺失。

## 更正附录（历史撤回记录，append-only）

1. **第 3 波"跨代环残留"读法已推翻**（2026-10-25 第 4 波）：环尾 +80 行/rep 自 rep9 起为
   各自 prefill 自写（r09=74/r10=154/r11=234 行 [X,1023)，层间同构；rep1-8 的 prefill 均干净
   覆写）；等差计数观察仍真，"跨代残留"归因作废；NaN 不跨 token 边界。
2. **"写侧无罪"类推撤回**（2026-10-24 fix1）：不能由"写侧输入/输出哈希一致"推出写侧无罪或
   排除算子内存副作用；量化散写侧未经首事件检验不称无罪（撤回规则①③）。
3. **B1 脚本缺陷更正**（2026-10-25 第 5 波）：本目录（与 v3 包内）`p6_compare.py` 曾带
   GQA reshape 崩溃＋错 unpack 布局两缺陷，`--ref` 在 nq=32/nkv=8 捕获上必崩；已修复并全量
   复现（见顶部 B1 修正记录与 `ref_reproduction_20261025.txt`）。此前一切由 `--ref` 产出的
   结论均出自修复版脚本（主 Agent 2026-10-25 实跑），无受影响数值。

生成：主 Agent 2026-10-25；B1/B2 修订：子 Agent B 第 5 波 2026-10-25（纯 CPU，未占设备）；
不修改任何已有数值；更正按 append 原则以本 README 与 PR_ADVANCE §10 为准。
