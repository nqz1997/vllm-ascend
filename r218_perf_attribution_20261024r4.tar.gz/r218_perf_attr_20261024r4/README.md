# R218 OSCAR True-INT2 — 性能归因证据包 `20261024r4`

本目录是 `r218_perf_attribution_20261024r4.tar.gz` 解包后的内容。
包摘要见包旁 `r218_perf_attribution_20261024r4.tar.gz.sha256`；
包内逐文件摘要见 `SHA256SUMS`（不包含自身）。

## 1. 版本

| 版本 | 内容 | 状态 |
|---|---|---|
| `20261024r4`（本包） | 20261024r3 全部 ＋ `capacity/`（INT2 容量修复分支、补丁、服务尺寸日志、24/24+17/17 电池、异步负对照）＋ `PR_ADVANCE_20261024.md` ＋ main 异步定位更正（`MAIN_SERVICE_VERIFY` §6、addendum 版本边界、差异页 OP/OPEN 口径） | **最新** |
| `20261024r3` | r2 ＋ main 异步定位更正 | SUPERSEDED（保留） |
| `20261024r2` | 20261024 全部 ＋ 补充页（步级分析/时间分解） | SUPERSEDED（保留） |
| `20261024` | 四腿＋复跑、2K/16K 消融、归因账本 v2、吞吐对照、一页结论、`MAIN_SERVICE_VERIFY_20261024.md` | SUPERSEDED（保留） |
| `20261023` | 20261024 的前驱（无 main 服务验证记录） | SUPERSEDED（保留） |

公开取回：`nqz1997/vllm-ascend` 分支 `r218-evidence/20261024`（独立 orphan 证据分支，不含源码）。

## 2. 口径纪律（引用前必读）

1. **同 GMU 与同总 HBM 两种容量口径独立表述。** 同 GMU 0.75：同为 29.52 GiB KV 分配，
   池 **1,719,424 vs 214,912 tok = 8.00×**；但 HBM 峰 **93% vs 77%**（每步多占 ~10.5 GiB），
   **8.00× 池 ≠ 8× 显存收益**。相近总 HBM 的公平对：**4.27×**。
2. **池容量/引擎并发打印不是实测并发。** “746×/103×” 是 `池÷(ctx+256)` 推算；
   实测活跃 batch 仅 32（2K）与 8（16K）；16K 验证至 INT2 32 / BF16 16，32 为 tested-not-max。
3. **精度与性能分账。** 所有数字只属于已测交付树组合；main 移植版默认异步 **OPEN**（INT2 中层读路径；blocking 仅时序判别），
   **不得引用本包精度/性能**。
4. **归因账本非互斥、不配平 100%。** 单项消融在同一步内可重叠，重叠量未测；
   “未被覆盖”是下界，不是互斥残差；不把未证实原因归为硬件下限。
5. **首次慢样本保留。** 2K 首腿 104.39 s（prefill 离群）保留并标 SUPERSEDED；
   点估计为 3 次中位 49.31 s（4.73×）。

## 3. 已测组合（本包全部性能数字的版本边界）

- 框架：v4 PR-22 tip `983fbac1`（树 ≡ 已测 `ov_restore` overlay）；`attention_v1.py` sha `85051bbd2e74c117`
- 内核：冻结 `md5=c8a8d47a63be7ad7`，vendor `oscar_r144_v133c_grp`
- launcher：`int2_lse_fast_r152`；姿态：**eager**、前缀缓存关、block 128、MNBT 8192
- 运行时：`oscar-r103-runner`，CANN 9.0.0 / vLLM 0.22.1，Qwen3-8B，单卡 dev7，greedy，64 tok/请求

main 移植（单列）：`nqz1997/vllm-ascend` `oscar-int2/m-port-full-ut` @ `81295d899`
（main 基 `dde85f6b8`；attn `704cf4e0c3a7fa5a`；同一冻结 kernel），上游 nightly 镜像
（digest `8eaf0b4f…`，CANN 9.2.0 / torch 2.10.0 / vLLM 0.31.0 @ `db9527a4`）。
仅构建/import/BF16 冒烟/隔离 UT 135 passed（适配后）＋串行化发射 41/41；默认异步 18/24 损坏，
最小复现 B=1 1080 tok 5/12 vs blocking 0/12，定位 INT2 中层读路径。
**结论 OPEN（默认异步正确性未关闭），不标生产可用；容量记账修复已在独立分支设备验证（见 §7）。**

## 4. 目录

- `R218_PERF_ATTRIBUTION_20261023.md` — 归因主文（四腿、复跑、容量-vs-HBM、prefill/decode 拆分、标度律、消融账本、三级结论）
- `PERF_ATTRIBUTION_ADDENDUM_20261024.md` — **本轮补充**（步级二次分析、时间分解、已证实/推测/未知、版本映射）
- `R218_ONE_PAGE_CONCLUSION.md` — 一页结论；`R218_DIFF_20261023.md` — 一页差异说明
- `MAIN_SERVICE_VERIFY_20261024.md` — main 服务验证（OPEN；§6 异步定位更正、§7 容量修复设备验证）
- `capacity/` — 容量修复补丁、服务尺寸日志与电池原始分析（24/24、17/17、异步负对照 12/12）
- `PR_ADVANCE_20261024.md` — PR/依赖/修复映射/异步/容量对账报告
- `docs/` — 精度总表、限制、审阅摘要、旧结论归档
- `figs/` — 归因账本、吞吐对照、逐点证据、三联图、本轮两张 CSV
- `runs/bg1..bg5_*/` — 逐腿 `perq.json`／`serve.log`／`gates.txt`／HBM 采样
- `scripts/` — 可重跑生成脚本（含 `r218_addendum_tables.py`）

## 5. 校验

```bash
sha256sum -c r218_perf_attribution_20261024r4.tar.gz.sha256   # 包旁
cd r218_perf_attr_20261024r4 && sha256sum -c SHA256SUMS       # 包内
```

本页写作时间 2026-10-24；不修改任何已有数值。
