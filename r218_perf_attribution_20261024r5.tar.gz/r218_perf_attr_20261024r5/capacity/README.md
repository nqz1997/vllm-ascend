# INT2 KV 容量修复 — 设备验证原始件（2026-10-24 05:35Z）

分支：`oscar-int2/capfix-int2-spec` @ fork `d1db5264a8f1`（本地等价提交
`d67b3a0b16b9`，树 `3588297086dc`；逐文件 blob 与远端一致，raw 重下 sha256 相同）。
补丁：`int2_capacity_fix.patch`（sha256
`8289c8bf2ceb43d5ba6ec854a76da02440c2ab8475aeef26d896ccfaa59f4ce1`）。

## 文件

| 文件 | 内容 |
|---|---|
| `serve_kv_sizing.log` | 两次修复后服务的 `INT2: reserving … / Available KV cache memory / NPU KV cache size` 原始行 |
| `capfix2_blk.*` | 中层 6×4 电池（blocking）：`total=24 bad=0` |
| `capfix17_blk.*` | 通用 17 形态电池（blocking）：`total=17 bad=0` |
| `capfix_async1080.*` | 负对照：默认异步 1080 tok 最小复现仍 `total=12 bad=12` |

## 口径

- 环境：上游 nightly 镜像（CANN 9.2.0 / torch 2.10.0 / torch_npu 2.10.0.post7 /
  vLLM 0.31.0 @ `db9527a4`），容器 `r218-main-verify`，NPU 7，Qwen3-8B，
  `gpu_memory_utilization=0.60`，`--enforce-eager`，`max_model_len=2048`，
  `max_num_seqs=32`，canonical INT2 vendor/launcher。
- 正确性只在 **诊断姿态**（`ASCEND_LAUNCH_BLOCKING=1`）下取得；默认异步缺陷仍 OPEN，
  该修复不改变它（见 `../MAIN_SERVICE_VERIFY_20261024.md` §7）。
- 849,280 tok 是**引擎池容量**，不是实测最大可服务并发。
- 未测吞吐；未合入 `m-port-full-ut`、未开上游 PR。

## 复算

```
Available = 21.04 GiB - 4.64 GiB (HP ring) = 16.40 GiB
page      = 128 * 8 heads * 72 B = 73,728 B
blocks    = 16.40 GiB / (73,728 * 36 layers) = 6,635
tokens    = 6,635 * 128 = 849,280
physical  = 849,280 * 576 B * 36 = 16.40 GiB
```

HP 环（canonical `R199_PRREAD=1`）：`36 * 2 * 33 * 1024 * 8 * 128 * 2 B = 4.983e9 B`
= 4.64 GiB（prefix 128 + recent 896 = 1,024；ms = max(32, 4, 33) = 33）。
