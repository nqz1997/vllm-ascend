# R218 统一逐题配对汇总（自动生成：r218_pairs_all.py；方向统一 INT2−BF16）

> 正值=INT2 本次测得较高。退化=BF16 对且 INT2 错；改善=INT2 对且 BF16 错（逐题配对）。RULER 为格级官方分（见 ACCURACY_TABLE §RULER），不在此逐题表。

| 数据集 | 范围 | 指标口径 | n | INT2 % | BF16 % | Δ(I−B) | INT2退化/改善 | 去重/合并规则 |
|---|---|---|---|---|---|---|---|---|

| gsm8k | 全量 | evalscope 官方适配器+评分器（micro） | 1319 | 93.18 | 92.49 | +0.69 | 10 / 19 | 配对键=(shard,index)；重跑追加行经 index 去重 |
| ceval | 全量 | evalscope 官方适配器+评分器（micro） | 1346 | 78.45 | 79.05 | -0.60 | 30 / 22 | 配对键=(shard,index)；重跑追加行经 index 去重 |
| gpqa_diamond | 全量 | evalscope 官方适配器+评分器（micro） | 198 | 45.45 | 47.47 | -2.02 | 26 / 22 | 配对键=(shard,index)；重跑追加行经 index 去重 |
| humaneval | 全量 | evalscope 官方适配器+评分器（micro） | 164 | 84.76 | 86.59 | -1.83 | 3 / 0 | 配对键=(shard,index)；重跑追加行经 index 去重 |
| ifeval | 全量 | evalscope 官方适配器+评分器（micro） | 541 | 81.52 | 82.07 | -0.55 | 19 / 16 | 配对键=(shard,index)；重跑追加行经 index 去重 |
| math_500 | 全量 | 同库自算（extract_answer+math_equal）＝原生 report n=500 复核一致 | 500 | 80.80 | 80.80 | +0.00 | 18 / 18 | 盘满修复：撕裂行隔离留档、重跑重复行按 index 去重、缺失 {L5:132,133} C=1 补齐（确定性补集）；retry 再生行 12/12 与保留行逐字节同 |
| mmlu_pro | 预冻结 700 子集（14 学科×50） | evalscope 官方评分器 | 700 | 63.86 | 63.71 | +0.15 | 35 / 36 | 无重复/失败行 |
| aime25 | 全量 30 | 同库自算（compare_answers integer_only）＝26 行与原生复核零偏差 | 30 | 20.00 | 20.00 | +0.00 | 1 / 1 | 结构性超时 4 题 C=1 补齐；78 行 28 组重复输出逐字节同（dedup-anyrow 分数不变）；楔死中间态 .wedge* 隔离不参与 |
| livecodebench | release_v6 窗口 454 | 官方 sandbox pass@1 | 454 | 24.67 | 24.23 | +0.44 | 6 / 8 | 窗口 ID 固定；无重复 |
| longbench_e | 分层 20% 子集 735 | 官方 THUDM eval.py --e（数据集官方指标，加权总分为官方口径） | 735 | 36.83 | 39.26 | -2.43 | 28 / — | 同 _id 配对 735；only-int2/only-bf16=0；逐题退化 28 条全列 lbe_pairs.json |
