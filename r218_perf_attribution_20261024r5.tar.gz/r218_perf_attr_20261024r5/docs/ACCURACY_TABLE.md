# R218 精度总表（**终版 2026-10-22 —— 双模式全部收官**）

- 组合：PR 链 v3-pr-22 tip a6ef9b97 overlay（含修复 12ee434b/8c23a2ce）＋冻结内核 c8a8d47a（[R218ID] 85051bbd2e74c117 / R159K-ID c8a8d47a63be7ad7 双模式一致）
- 协议：两模式同题/同模板（qwen3_8b_nothink）/greedy t=0/同 max_tokens/同评分器
- 官方器口径：LongBench-E=THUDM eval.py --e；RULER=NVIDIA 官方 scripts；LCB=官方 sandbox pass@1；MMLU-Pro/AIME25/MATH-500=EvalScope 内置
- **核心六道总览（口径声明）：逐项差值 +0.69 / −0.60 / 0.00 / −2.02 / −1.83 / −0.55（INT2−BF16），简单平均 −0.72pp；单项最大差值 −2.02（GPQA-D）。GSM8K/LCB/MMLU-Pro 为本次 INT2 测得分数较高。无预先认可的质量阈值，本表不构成通过/失败判定**

## 核心六道（EvalScope，全量）
| 数据集 | n | INT2 % | BF16 % | Δ(I−B) | INT2劣化/反超（逐题） |
|---|---|---|---|---|---|
| GSM8K | 1319 | **93.18** | **92.49** | **+0.69（本次 INT2 测得较高）** | 10 / 19 |
| C-Eval val | 1346 | **78.45**（macro 78.88） | **79.05**（macro 79.64） | −0.60 | 30 / 22 |
| MATH-500 | 500 | **80.80**（404/500；原生 evalscope report n=500=0.808，其中 2 行为 C=1 top-up 生成、已归一化进原生评分路径；同库自校验零偏差；盘满撕裂行去重披露） | **80.80** | **0.00（总分相同：404/500 = 404/500；逐题 18 题退化 / 18 题改善）** | 18 / 18（386 双对/78 双错；`es/es_pairs_math500.json`） |
| GPQA-Diamond | 198 | **45.45** | **47.47** | −2.02 | 26 / 22 |
| HumanEval | 164 | **84.76** | **86.59** | −1.83 | 3 / 0 |
| IFEval | 541 | **81.52**（prompt-strict；inst-strict 87.05 / loose 85.03/89.45） | **82.07**（prompt-strict；inst-strict 87.65 / loose 85.77/90.17） | −0.55 | 19 / 16 |

统一逐题配对汇总（方向 INT2−BF16、含去重规则）：`PAIRED_SUMMARY.md`（生成器 r218_pairs_all.py）；明细 `es/es_pairs_{coreA,coreB,cross,math500}.json`。

## 扩展（Δ 同上口径：INT2−BF16）
| 数据集 | n | INT2 % | BF16 % | Δ |
|---|---|---|---|
| MMLU-Pro（700 子集） | 700 | **63.86** | **63.71** | +0.15 |
| AIME 2025 | 30 | **20.0**（6/30；26 题 evalscope 原生＋4 题 C=1 top-up 同库评分、verify 26/26 零偏差；3 题触 16K 顶） | **20.0**（6/30；7/30 触 16K 顶=no-think 发散 CoT） | 0.00 |
| LiveCodeBench pass@1（窗 454） | 454 | **24.67**（112/454；59 触 2000tok 顶） | **24.23**（110/454；55 题触 2000tok 顶） | +0.44 |

## RULER（官方器，N=30/格；4096/8192/16384）
| 任务 | INT2 (4096/8192/16384) | BF16 (4096/8192/16384) |
|---|---|---|
| niah_single_1 | 93.33 / 96.67 / 93.33 | 100 / 100 / 100 |
| niah_multikey_1 | 93.33 / 100 / 93.33 | 100 / 100 / 100 |
| niah_multiquery_1 | 97.50 / 100 / 96.67 | 99.17 / 100 / 100 |
| niah_multivalue_1 | 96.67 / 100 / 95.00 | 100 / 100 / 100 |
| variable_tracking | 0 / 0 / 0 | 0 / 0 / 0（官方 30tok 上限＋超限＝协议性 0，len_cap 30/30） |
| common_words_extraction | 60.33 / **0.33** / 8.33 | 69.33 / 14.0 / 14.33 |
| freq_words_extraction | 83.33 / 88.89 / 84.44 | 78.89 / 87.78 / 85.56 |
| qa_1 (squad) | 76.67 / 56.67 / 43.33 | 70 / 60 / 56.67 |
| qa_2 (hotpot) | 46.67 / 46.67 / 46.67 | 53.33 / 53.33 / 50 |

## LongBench-E（官方器，735 题分层 20% 子集；同 _id 配对；分桶见 lbe_pairs.json）
| 数据集 | n | INT2 | BF16 | Δ(INT2−BF16) |
|---|---|---|---|---|
| 2wikimqa | 60 | 47.05 | 49.10 | −2.05 |
| gov_report | 60 | 31.59 | 33.00 | −1.41 |
| hotpotqa | 60 | 61.30 | 68.47 | −7.17 （8k+ 桶 45.94 vs 72.83＝最大退化带）  |
| lcc | 60 | 1.43 | 1.42 | +0.01 |
| multi_news | 59 | 22.57 | 23.38 | −0.81 |
| multifieldqa_en | 31 | 51.90 | 53.18 | −1.28 |
| passage_count | 60 | **0.00** | 10.00 | −10.00 （INT2 计数任务全失败）  |
| passage_retrieval_en | 60 | 95.00 | 100.00 | −5.00 |
| qasper | 45 | 45.74 | 45.71 | +0.03 |
| repobench-p | 60 | 2.53 | 2.90 | −0.37 |
| samsum | 60 | 40.22 | 39.27 | +0.95 |
| trec | 60 | 0.00 | 0.00 | 0 （官方首行截断×chatty，两模式同）  |
| triviaqa | 60 | 88.71 | 92.04 | −3.33 （8k+ 桶 −10）  |
| **OVERALL** | 735 | **36.83** | **39.26** | −2.43 |

逐题退化（BF16≥0.5 且 INT2<BF16−0.2）28 条全列 `lc_eval/lbe_pairs.json`；INT2 本次测得较高：hotpotqa 0-4k/4-8k、qasper 0-4k、samsum 全桶、multifieldqa 4-8k、lcc 4-8k。

> INT2 侧 LB-E 分桶并发（<4k C=4/4-8k C=3/8k+ C=2）vs BF16 C=8 —— LC INT2 C=8 楔死缺陷的披露绕行；greedy 下并发不应改输出。

*完整性核对（预期/唯一/失败/重复/重试）见 `REVIEW_SUMMARY.md`；LB-E 逐任务长度/生成帽/触帽见 `lc_eval/lbe_task_detail.json`。*
