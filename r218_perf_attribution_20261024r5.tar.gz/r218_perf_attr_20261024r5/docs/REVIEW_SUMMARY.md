# R218 审阅摘要（2026-10-22 终版）— 供用户审阅与 GPT 报告取材

> 口径：只陈述测得数值与差值；无预先认可的质量阈值，任何单项差值不构成"通过"判定；差值为正写作"本次测得分数较高"；未经受控对照证明的机制解释标"假设"。

## 1. 已验证收益（当前版本直测）
- **KV 池容量比 8.00-8.03×**（同 GMU 实测；INT2 池 ≈1.7M tok vs BF16 ≈283k tok@GMU0.90）。
- **质量门内更大活跃 Batch@16K：INT2 验证至 32 vs BF16 验证至 16**（BF16 的 32 驻留物理不可行：池 281,472 tok=16.92×＜32×16,640，HBM 峰 91%——引擎 gates.txt 直证，无需补测；INT2 池 1,009,280 tok=60.65×、HBM 峰 79%，32 亦为 tested-not-max）。KV 池比例不等于吞吐/可用 Batch 收益（见代价）。
- **核心六道逐项差值（INT2−BF16，全量）**：GSM8K +0.69 / C-Eval −0.60 / MATH-500 0.00 / GPQA-D −2.02 / HumanEval −1.83 / IFEval-strict −0.55；**简单平均 −0.72pp**；MATH-500 总分相同（404/500 = 404/500；逐题 18 题退化 / 18 题改善）。GSM8K、MMLU-Pro（+0.15）、LCB（+0.44）本次 INT2 测得较高；AIME25 双 20%。
- **并发不变性**：bs=8 批服务下两模式各 100/100 输出与单并发逐字节相同（gsm8k-100）；重跑再生行 12/12 逐字节同（math_500 retry1）；aime25 全部 28 组重复行输出逐字节同——greedy 输出与并发/重跑无关（当前观测）。

## 2. 实际代价（当前版本直测）
- **decode TPOT 2.2-2.7×慢**（R159K_BATCH=1 稳态 p50：INT2 65.8-67.4ms vs BF16 24.7-30.7ms @1024-8192）；**并发吞吐比更大且随并发/上下文增长：C=8 吞吐比 2K/8K/16K＝8.9×/12.7×/17.0×**；**e2e 2.4-3.7×慢**（prefill 4-5×为主因）；16K-C32 单流 TPOT p50 ~5013ms vs C16 ~280ms。逐点证据=`figs/PERF_POINT_EVIDENCE.{csv,md}`。
- **吞吐全并发域落后**：2K 峰值 45.12 vs 273.43 tok/s；16K 3.30 vs 30.31。
- **长上下文质量**：LB-E 36.83 vs 39.26（−2.43；28 题逐题退化，hotpotqa 8k+ 桶最深）；RULER niah 族每 30 题丢 1-2 针、cwe/qa_2 各长度落后、fwe/qa_1 INT2 测得较高（27 格全表见 ACCURACY_TABLE）。
- **服务稳定性**：C=8 长上下文楔死（绕行=分桶并发）；C=1 长时累积楔死（重启恢复）；batch-64 row33 确定性缺位（详见 §5）。

## 3. 尚未成立 / OPEN（更新：2026-10-22 诊断后）
- LB-E 各任务机制占比精确分解
- **长上下文退化机制＝受控帽对照分层定谳（lc_diag/）**：cwe@8192 帽×CoT 长度交互【已证实：480 帽两模式 13/13 恢复】；hotpotqa 8k+ 帽机制排除【两帽分数逐字不变】＝信息性答错＋INT2 跨跑漂移实测（BF16 12/12 复现、INT2 3↔2 题翻转）；passage_count 帽 512 已测【双成分定谳：官方全数字计分×verbose 枚举（2/6 终答对仍 0 分）＋真计数错 3/6，「截断主导」撤回，lc_diag/DIAG512_RESULTS】；8k+ 检索任务不退化。各任务占比精确分解仍 OPEN。
- **楔死根因（C=8 与 C=1 两表象）均 UNKNOWN**；8110 终死（2026-10-22 05:48:15，无 traceback）死因未取证。
- **吞吐差距归因**：分组内核 10-12ms/层·调用是**当前实现**（两 vendor 变体共同）的观测地板，非硬件下限论断。
- 4K 容量点 tested-not-max；批 TTFT 为冷锚上界；"框架、算子均由 PR 源码构建"组合未运行＝OPEN（主结果全部出自"PR 框架＋冻结内核"）。

## 4. 最终测试版本（钉死）
| 项 | 值 |
|---|---|
| 框架 | branch `oscar-int2/v3-pr-22` tip **a6ef9b9780878e95d36bc45f68d5bc069b7ff165**（22-PR v3 栈；树与 23-PR tip 1b4fc58d 逐字节同，conservation_check.txt；基 5f6faa0c=vllm-ascend v0.22.1rc1） |
| 修复 1 | **12ee434b** "oscar: add r116_torch_op module (lazy-imported by int2 fused CU paths)"（2026-10-20）——PR 树缺 `vllm_ascend/oscar/r116_torch_op.py`，长上下文 fused-CU/ring 懒加载首触 ImportError 杀 EngineCore（≤4352 MML 短上下文不触发）；补链文件字节同冻结参考（sha256 0d5bc366…37aa8） |
| 修复 2 | **8c23a2ce** "oscar: make r116_torch_op resolve binding source and vendor on disk"（2026-10-20）——r116 绑定源/vendor 盘上解析回退（docker-exec env 白名单剥离＋W 硬编码布局不全 → OSError libcust_opapi 第二死因） |
| 两修复所在分支 | `oscar-int2/pr-13`（框架工作仓）；**未折入 v3 链任何 PR**（pr-branches-v3.bundle 的 23 refs 不含它们）——PR 提交阶段需折入对应 PR（r116 逻辑属长上下文 fused-CU/ring 懒加载） |
| overlay | `acceptance/runs/prv3/ov_restore`（bundle 克隆组装＋两修复）；加载锚点门 [R218ID] attention_v1.py sha=**85051bbd2e74c117** |
| 内核 | 冻结 vendor `oscar_r144_v133c_grp` md5 **c8a8d47a63be7ad7**（R157_OPP 空＋R144_LEG=grp）；门 R159K-ID 每次 EngineCore 启动打印 |
| 运行→版本映射 | 七条服腿全部同一 [R218ID] 锚点＋同一 vendor md5（含被截断的 es_lc_int2/es_int2_c，由 /tmp/r218_home_rescue 全量副本复核）；核心 A/B 腿（8110/8112，≤4352 MML）不含 r116 修复（不触发）；LC/RULER/ext/并行腿（8114-8118）含；perf 三联图 rp_* 腿=同身份框架、冻结内核（IDENTITY.md 分轨道表） |

## 5. 缺陷清单（复现条件/影响/状态：FACTS §B.1）
C=8 楔死（根因 UNKNOWN、已绕行）、C=1 长时楔死（重启恢复、根因 UNKNOWN）、batch-64 row33（3/3 复现、保留）、8110 无迹终死（未取证）、NS=1 残留/电池间歇（未复测）、r116×2（已修复）。

## 6. 评测完整性核对（预期 vs 实得）
| 数据集 | 预期 | INT2 唯一有效 | INT2 异常 | BF16 同口径 | 合并审计 |
|---|---|---|---|---|---|
| GSM8K | 1319 | 1319 | 触顶 1、空/错 0 | 1319（触顶 1） | 双侧 only_int2/only_bf16=空 |
| C-Eval val | 1346 | 1346 | 触顶 53、空/错 0 | 1346（触顶 47） | 同上；52 学科分片配对键=(文件,index) |
| MATH-500 | 500 | **500（0 错 0 重）** | — | 500 | 逐题 18 退化/18 改善；盘满修复审计见下 |
| GPQA-D | 198 | 198 | — | 198 | pairs n=198 |
| HumanEval | 164 | 164 | — | 164 | acc 键配对 |
| IFEval | 541 | 541 | — | 541 | prompt-strict 键配对 |
| MMLU-Pro | 700 | 700 | 错 0 | 700 | 预冻结分层子集（14 学科×50） |
| AIME25 | 30 | 30 | 触 16K 顶 3 | 30（触顶 7） | 合并审计见下 |
| LCB | 454 | 454 | 触 2000 顶 59（计失败） | 454（55） | 官方沙箱 0 请求错误 |
| RULER | 30/格×27 格 | 全 | vt 30/30 触 30tok 顶（协议性 0） | 全 | 双模式 summary.csv |
| LB-E | 735 | 735 | 触帽逐任务见下 | 735 | only_int2/only_bf16=0 |

- **MATH-500 盘满修复合并审计**：errno 28 致 1 行撕裂（隔离 `Level 5.jsonl.torn.bak` 留档）＋1 行未写＋auto-retry 追加重复；修复=剥撕裂（未删档）＋去重＋C=1 补齐**仅缺失的 2 个 index（Level 5 {132,133}，确定性补集、无选择余地）**→ 500 唯一行；评分=原生 evalscope report（n=500=0.808）与同库独立重打一致；**总分相同（404/500 = 404/500）；逐题 18 题退化 / 18 题改善**；被杀 retry 工作dir 的 12 行再生输出与保留行**逐字节同**（重复无择优空间；已移除的 3 条重复行未整体留档，此为唯一不可复核细节，但评分只遍历修复后 500 唯一行）。
- **AIME25 C=1 补跑合并审计**：结构超时（16384 发散 CoT 单流 ~6072s>客户端 timeout）饿死 4 题→C=1 补齐仅缺失 index；26 条既有行与 evalscope reviews 零偏差（26/26）；**78 行中 28 组重复全部输出逐字节同（dedup-anyrow acc=6/30 不变）＝无择优可能**；两次楔死中间态隔离 .wedge18/.wedge25（未参与评分）。

## 7. LB-E 逐任务明细（n/长度 p50/官方生成帽/触帽 _id 数 I|B）
| 任务 | n | len p50/max (tok) | cap | 触帽 I|B | Δ(B−I) |
|---|---|---|---|---|---|
| 2wikimqa | 60 | 5200/12233 | 32 | 1\|1 | +2.05 |
| gov_report | 60 | 6602/23442 | 512 | 25\|35 | +1.41 |
| hotpotqa | 60 | 6437/12126 | 32 | 1\|1 | **+7.17** |
| lcc | 60 | 4871/23278 | 64 | 60\|60 | −0.01 |
| multi_news | 59 | 5180/16385 | 512 | 34\|39 | +0.81 |
| multifieldqa_en | 31 | 5009/9607 | 64 | 3\|2 | +1.28 |
| passage_count | 60 | 6473/13417 | 32 | **52\|39** | **+10.00** |
| passage_retrieval_en | 60 | 6059/10607 | 32 | 1\|0 | +5.00 |
| qasper | 45 | 4104/14722 | 128 | 0\|0 | −0.03 |
| repobench-p | 60 | 5082/14166 | 64 | 60\|60 | +0.37 |
| samsum | 60 | 5995/11167 | 128 | 0\|0 | −0.95 |
| trec | 60 | 6453/12921 | 64 | 60\|60 | 0.00 |
| triviaqa | 60 | 5789/14272 | 32 | 0\|0 | +3.33 |

（机器可读 `lc_eval/lbe_task_detail.json`；原始 prompt 统一官方中段截断 16320 tok；RULER 27 格全表=ACCURACY_TABLE §RULER。）

## 8. 三联图溯源
`figs/r218_triple.{png,svg,pdf}`＋`triple_data.csv`＋`perf_detail.json`：每个点=一次实测腿（`runs/rp_*_{thrcap2k,thrcap8k,thrcap16k,cb64_repro}/perq.json`），组合同 §4（框架 v3 栈＋冻结内核、rp 腿身份见 IDENTITY 分轨道表）；质量态=NT=64 生成校验门（未过=质量失败点，图中标注）；OOM/超时/未测在 CSV 单列标注；面板 C 4K 点=tested-not-max；批 TTFT=冷锚上界（perf_detail.json 披露）。只画实测点，无插值。

## 9. 材料入口
- 统一逐题配对汇总（自动生成、方向 INT2−BF16、含范围/口径/去重规则）：`PAIRED_SUMMARY.md`＋`PAIRED_SUMMARY.json`（生成器 `r218_pairs_all.py`）
ACCURACY_TABLE.md（总表）· FACTS_AND_LIMITATIONS.md（事实/限制/未关闭）· IDENTITY.md（身份）· LOG_INDEX.md（日志）· ES/EXTENSIONS/LBE_PROTOCOL.md（冻结协议＋执行偏差披露）· 证据包 `evidence_pack/r218_evidence_<ts>.tar.gz`（gitcode 副本：oscar_39M 仓）· 索引 DELIVERABLES_INDEX.md。
