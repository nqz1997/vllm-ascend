# R218 最终交付组合为何没有吞吐收益 — 取证结论（2026-10-23）

机器可读账本：`throughput_nogain_ledger.json`（同目录）；原始 trace：
`report_eval/runs/bg1_{int2,bf16}_thrcap{2k_c32,16k_c8}/`（perq/gates/hbm_samples/serve.log）
＋ `opbench_delivered.json`。技术报告由 GPT 撰写，本件只给证据与结论。

## 固定组合与协议（无拼接）

- 组合＝交付组合不动：PR 框架 v4 tip `983fbac1`（ov_restore overlay，attention_v1 sha `85051bbd`）
  ＋冻结内核 vendor `oscar_b1_r218emitgrp`（`OscarInt2FusedAttnInt2Lse` .o md5 `c8a8d47a63be7ad7`），
  RC5 canonical env、eager、诊断关。
- 四条短窗腿（`r218rp_leg.sh thrcap` 冻结 SPEC，**DEV7 同卡同协议顺序跑**）：
  2K/C32 与 16K/C8 × {INT2, BF16}；质量门全绿（32/32、8/8 命中）。
- 时钟口径：TTFT 原始值＝混钟（到达=墙钟 vs token=单调钟）**不可用**（沿用 REPORT.md 定谳）；
  有效口径＝批墙钟与 decode 跨度（同为单调/同为墙钟）。
- 算子级对照＝交付树上 r152 launcher 全新 cpp_extension 编译直调（DEV6，50 次中位数）。
  早期（R159 候选时代）的分解数据（op 971us/dequant 93%、NS=32 overhead 52.5ms 拆分）
  **属不同姿态，未拼接**。

## 结果

| 工作点 | INT2 tok/s | BF16 tok/s | 差 | INT2 步(ms) | BF16 步(ms) | 步差(ms) |
|---|---|---|---|---|---|---|
| 2K/C32 | 19.62 | 196.12 | 10.0× 慢 | 1631.1 | 163.2 | **1467.9** |
| 16K/C8 | 4.51 | 26.37 | 5.8× 慢 | 1772.6 | 303.4 | **1469.2** |

算子级（交付内核直调）：LSE 算子 0.469ms@B32/S1920、0.466ms@B8/S15360（**随 S 平坦**）；
oscar_quant_kv 0.946/0.885ms。×36 层＝48.6/48.3ms 每步。

**两个工作点的步差几乎相同（1467.9 vs 1469.2ms），且与上下文长度和并发都无关**；
其中内核数学（LSE+量化，直测）仅占 3.3%，未归因部分 96.7%（≈1420ms/步 ≈ **39.4ms/层·步常数**）。

## 结论（三类分界）

1. **已证实的实现瓶颈**：INT2 三层组合路径的**每层每步 ~39ms 常数开销**（与 ctx/B 无关＝
   host 侧编排签名：每层的 carrier/staging/ring/merge/launch 链与派发，eager 姿态下逐层走
   Python/dispatch）。内核数学本身又快又平（0.47ms 不随 S 增长）——瓶颈在组合编排，不在冻结内核。
2. **已证实的硬件约束**：本两工作点**未证明任何硬件上限**。冻结内核直调平坦且亚毫秒；
   "分组内核 10-12ms/层"类历史口径属旧候选姿态，不作为硬件下限证据（FACTS_AND_LIMITATIONS
   既有纪律一致）。
3. **尚未确定**：96.7% 未归因部分在（其余设备算子：middle 组合 fill/merge、ring、scatter、
   dequant）与（host 派发/同步停顿）之间的精确切分——本轮诊断关闭（冻结姿态）、未加插桩
   （避免扰动与范围扩张），需一轮 diag 门控腿或 profiler 才能闭合。另：BF16 FIA 直调臂在
   独立进程持续失败（torch_npu 内建 aclnn 报错，两种参数形均试），BF16 参照改用同协议服务腿。

## 容量对照（交付的真实收益面）

同协议引擎实测：INT2 KV 池 1,009,280 tok vs BF16 50,688 tok（mml 8448，GMU 0.55；引擎最大并发
119× vs 6×）；16K 下 BF16 32 驻留物理不可行。**交付的收益是驻留容量（8× KV），不是单步速度**；
在全部测过的 (ctx, C) 点上聚合吞吐仍落后（DEV7：10.0×/5.8×；DEV1 时代 2K/C8 6.7×）。

---

## 更正（2026-10-23 10:20Z，复跑后）

**"两工作点步差几乎相同 ⇒ 与 ctx/并发无关的 ~39.4 ms/层·步常数"一节作废。**
该结论用的 2K/C32 INT2 单次墙钟 104,392 ms 是**prefill 离群**：同参数复跑两次为 49,310 / 49,100 ms，
decode 生成吞吐三次一致（55.5–56.8 tok/s @32 并发）——即离群只在 prefill 段，不是 decode 性质。

用复跑中位重算（decode 跨度均 63 个 token 间隔）：

| 点 | 每步 KV 遍历 token (C×ctx) | decode 步差 | 每 KV token 每步 |
|---|---|---|---|
| 2K/C32 | 65,536 | 484 ms | 7.38 µs |
| 16K/C8 | 131,072 | 977 ms | 7.45 µs |

差距比 2.019× vs token 比 2.000× ⇒ **标度律是 ∝ C×ctx，不是 per-layer 常数**。
结论修订为：多出的时间随每步遍历的 KV token 线性增长（≈7.4 µs/ token·步，≈0.205 µs/层·token），
内核平坦（0.47 ms 直调）；2K 下跳过中段算子执行只省 24 ms/步，16K 下省 841 ms/步（NOMIDE 实测，输出错误，仅诊断），故 2K 开销主要在**载体组装/搬运链**；
gather / dequant / scatter / host 编排四者之间仍未定量切分。

原文其余部分（算子直调数据、混钟警告、容量 8× 与"收益面是容量不是单步速度"）**仍然有效**。
新证据与图：`report_eval/R218_PERF_ATTRIBUTION_20261023.md` §4b/§5，
证据包 `report_eval/evidence_pack/r218_perf_attribution_20261023.tar.gz`。
