#!/usr/bin/env python3
# R218 sub-B: build the profiling deliverables (2026-10-24) deterministically
# from analysis outputs + steplogs:
#   figs/PERF_PROFILING_20261024.csv  (op-level decomposition, evidence column)
#   figs/PERF_PROFILING_STEP_20261024.png  (INT2 vs BF16 stacked bars)
# Pure host-side; matplotlib Agg.
import json, csv, os, statistics, collections

BASE = os.path.dirname(os.path.abspath(__file__))
RP = os.path.join(BASE, "..", "runs")
FIGS = os.path.join(BASE, "..", "figs")

def stepstats(tag):
    unprof, prof, pre = [], [], []
    for line in open(os.path.join(RP, tag, "prof_steps.jsonl")):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if r.get("tot") == 32 and r.get("ms"):
            if r.get("p"):
                prof.append(r["ms"])
            else:
                unprof.append(r["ms"])
    return unprof, prof

rows = []
step_summary = {}
for mode, tag, pref in (("INT2", "bg6_prof_int2_2k_c32", "bg6_prof_int2"),
                        ("BF16", "bg6_prof_bf16_2k_c32", "bg6_prof_bf16")):
    s = json.load(open(os.path.join(BASE, "analysis",
                                    pref + "_summary.json")))
    unprof, prof = stepstats(tag)
    wall = statistics.median(unprof)
    busy = s["kernel_union_per_step_ms"]
    gap = wall - busy
    step_summary[mode] = dict(wall=wall, busy=busy, gap=gap,
                              n_un=len(unprof), n_pr=len(prof),
                              probe=s["probe_overhead_ms"],
                              **s)
    rows.append(dict(mode=mode, level="step", category="<decode step>",
                     op="step wall (median, profiler OFF, tot==32)",
                     count=len(unprof), ms_per_step=round(wall, 2),
                     pct_wall=100.0, evidence="prof_steps.jsonl (same leg)"))
    rows.append(dict(mode=mode, level="step", category="device busy",
                     op="NPU kernel union (all streams)",
                     count=s["kernel_events"], ms_per_step=round(busy, 2),
                     pct_wall=round(100 * busy / wall, 2),
                     evidence="chrome trace interval union / 12 steps"))
    rows.append(dict(mode=mode, level="step", category="host/launch gap",
                     op="wall - kernel union (residual)",
                     count=None, ms_per_step=round(gap, 2),
                     pct_wall=round(100 * gap / wall, 2),
                     evidence="derived (wall median - trace union)"))
    rows.append(dict(mode=mode, level="step", category="probe overhead",
                     op="median(profiler ON) - median(profiler OFF)",
                     count=len(prof), ms_per_step=s["probe_overhead_ms"],
                     pct_wall=round(100 * s["probe_overhead_ms"] / wall, 2),
                     evidence="prof_steps.jsonl in-leg contrast"))
    with open(os.path.join(BASE, "analysis", pref + "_categories.csv")) as f:
        for r in csv.DictReader(f):
            rows.append(dict(mode=mode, level="category",
                             category=r["category"], op="<sum of named kernels>",
                             count=int(r["count"]),
                             ms_per_step=round(float(r["npu_ms_per_step"]), 3),
                             pct_wall=float(r["pct_of_step_wall_unprof"]),
                             evidence=r["evidence"] + "; names->categories by analyze_prof_trace.py"))
    with open(os.path.join(BASE, "analysis", pref + "_ops.csv")) as f:
        for r in csv.DictReader(f):
            rows.append(dict(mode=mode, level="op", category=r["category"],
                             op=r["op"], count=int(r["count"]),
                             ms_per_step=round(float(r["npu_ms_per_step"]), 3),
                             pct_wall=float(r["pct_of_step_wall_unprof"]),
                             evidence=r["evidence"]))

os.makedirs(FIGS, exist_ok=True)
out_csv = os.path.join(FIGS, "PERF_PROFILING_20261024.csv")
with open(out_csv, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["mode", "level", "category", "op",
                                      "count", "ms_per_step", "pct_wall",
                                      "evidence"])
    w.writeheader()
    for r in rows:
        w.writerow(r)
print("csv rows:", len(rows), "->", out_csv)

# ---- chart: INT2 vs BF16 decode-step wall decomposition (stacked bars) ----
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

C1, C2, C3 = "#2a78d6", "#eb6834", "#1baf7a"   # validated categorical slots 1-3
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e8e8e6"

att = {"INT2": ("OscarInt2FusedAttnInt2Lse (middle kernel)",
                step_summary["INT2"]["top10_kernels"][0][1] / 12),
       "BF16": ("FusedInferAttentionScore (attention)",
                step_summary["BF16"]["top10_kernels"][1][1] / 12)}
other = {m: step_summary[m]["busy"] - att[m][1] for m in ("INT2", "BF16")}
gap = {m: step_summary[m]["gap"] for m in ("INT2", "BF16")}
wall = {m: step_summary[m]["wall"] for m in ("INT2", "BF16")}

fig, ax = plt.subplots(figsize=(8.6, 3.1), dpi=200)
fig.patch.set_facecolor("#fcfcfb")
ax.set_facecolor("#fcfcfb")
modes = ["INT2", "BF16"]
y = [0, 1]
H = 0.5
for yi, m in zip(y, modes):
    seg = [(att[m][1], C1, "%s %.1f" % (att[m][0].split(" (")[0], att[m][1])),
           (other[m], C2, "other kernels %.1f" % other[m]),
           (gap[m], C3, "host gap %.1f" % gap[m])]
    left = 0.0
    for val, color, label in seg:
        ax.barh(yi, val, left=left, height=H, color=color,
                edgecolor="#fcfcfb", linewidth=1.4)
        if val / 640 > 0.075:
            ax.text(left + val / 2, yi, label, ha="center", va="center",
                    fontsize=8, color="white", fontweight="bold")
        left += val
    ax.text(left + 6, yi, "wall %.1f ms" % wall[m], ha="left", va="center",
            fontsize=9, color=INK, fontweight="bold")
# BF16 segments are too small for internal labels at this scale: annotate above
b = step_summary["BF16"]
ax.annotate("BF16: attention %.1f (%.0f%%)  ·  other kernels %.1f (%.0f%%)  ·  host gap %.1f (%.0f%%)"
            % (att["BF16"][1], 100 * att["BF16"][1] / wall["BF16"],
               other["BF16"], 100 * other["BF16"] / wall["BF16"],
               gap["BF16"], 100 * gap["BF16"] / wall["BF16"]),
            xy=(wall["BF16"] / 2, 1 - 0.44), xytext=(150, 1.56),
            fontsize=7.5, color=INK2, ha="left",
            arrowprops=dict(arrowstyle="-", color="#b9b8b2", lw=0.8))
# delta annotation
ax.text(320, -0.62,
        "decode-step difference (INT2 - BF16): wall +477.3  =  kernel +237.4  +  host gap +239.9 (ms/step)",
        fontsize=8.5, color=INK, ha="center", fontweight="bold")
ax.set_yticks(y)
ax.set_yticklabels(["INT2 (n=%d steps, probe off)" % step_summary["INT2"]["n_un"],
                    "BF16 (n=%d steps, probe off)" % step_summary["BF16"]["n_un"]],
                   fontsize=9, color=INK)
ax.set_xlabel("pure-decode step time @ batch 32, ctx 2048 (ms)", fontsize=9,
              color=INK2)
ax.set_xlim(0, 640)
for s in ("top", "right", "left"):
    ax.spines[s].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(colors=INK2, labelsize=8)
ax.xaxis.grid(True, color=GRID, linewidth=0.6)
ax.set_axisbelow(True)
handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in (C1, C2, C3)]
ax.legend(handles,
          ["attention-path kernel (INT2: frozen Oscar middle kernel; BF16: FusedInferAttentionScore)",
           "other NPU kernels", "host/launch gap (wall - kernel union)"],
          loc="upper center", bbox_to_anchor=(0.5, -0.32), ncol=1,
          frameon=False, fontsize=8, labelcolor=INK2)
ax.set_title("R218 2K/C32 decode-step decomposition — torch_npu profiler, 12 profiled steps per leg (bg6 legs, 2026-10-24)",
             fontsize=9.5, color=INK, loc="left", pad=10)
fig.tight_layout()
png = os.path.join(FIGS, "PERF_PROFILING_STEP_20261024.png")
fig.savefig(png, bbox_inches="tight", facecolor="#fcfcfb")
print("png ->", png)
json.dump({m: {k: step_summary[m][k] for k in
               ("wall", "busy", "gap", "n_un", "n_pr", "probe")}
           for m in ("INT2", "BF16")},
          open(os.path.join(BASE, "analysis", "step_decomp.json"), "w"),
          indent=1)
print(json.dumps({m: {k: round(step_summary[m][k], 2) for k in
                      ("wall", "busy", "gap", "probe")} for m in
                  ("INT2", "BF16")}))
