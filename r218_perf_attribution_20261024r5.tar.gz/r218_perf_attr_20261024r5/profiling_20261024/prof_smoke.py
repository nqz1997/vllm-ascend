#!/usr/bin/env python3
"""torch_npu.profiler smoke test (device 7): 3 matmul steps under
profile(CPU+NPU); exports chrome trace + key_averages. Verifies the export
path the EngineCore hook relies on, before any service leg is spent."""
import os, sys, json, time
os.environ.setdefault("ASCEND_RT_VISIBLE_DEVICES", os.environ.get("SMOKE_DEV", "7"))
import torch
import torch_npu
from torch_npu.profiler import profile, ProfilerActivity

OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/r218prof_smoke"
os.makedirs(OUT, exist_ok=True)
torch.npu.set_device(0)
a = torch.randn(1024, 1024, device="npu", dtype=torch.float16)
b = torch.randn(1024, 1024, device="npu", dtype=torch.float16)
for _ in range(3):
    c = a @ b
torch.npu.synchronize()

p = profile(activities=[ProfilerActivity.CPU, ProfilerActivity.NPU])
p.start()
t0 = time.perf_counter()
for _ in range(5):
    c = a @ b
    c = c * 1.0001
torch.npu.synchronize()
wall = (time.perf_counter() - t0) * 1000
p.stop()
p.export_chrome_trace(OUT + "/smoke.trace.json")
ka = p.key_averages()
txt = ka.table(sort_by="self_npu_time_total", row_limit=20)
open(OUT + "/smoke.key_averages.txt", "w").write(txt)
rows = []
for e in ka:
    rows.append({"name": str(e.key)[:80], "count": e.count,
                 "self_npu_us": float(getattr(e, "self_npu_time_total", 0) or 0),
                 "self_cpu_us": float(getattr(e, "self_cpu_time_total", 0) or 0)})
rows.sort(key=lambda r: -r["self_npu_us"])
json.dump({"wall_ms": round(wall, 2), "top": rows[:10],
           "trace_bytes": os.path.getsize(OUT + "/smoke.trace.json")},
          open(OUT + "/smoke.json", "w"), indent=1)
print(json.dumps({"wall_ms": round(wall, 2),
                  "trace_bytes": os.path.getsize(OUT + "/smoke.trace.json"),
                  "top3": [(r["name"], r["count"], r["self_npu_us"]) for r in rows[:3]]}))
print("SMOKE-OK")
