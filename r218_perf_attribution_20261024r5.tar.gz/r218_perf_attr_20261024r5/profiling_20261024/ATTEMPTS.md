# bg6 profiling legs — attempt log (honest record, 2026-10-24 UTC)

All attempts used the same frozen envelope (see r218rp_prof_leg.sh); only the
hook-injection mechanism differed. Device use was inside flock /tmp/r218_npu7.lock
throughout; window lines in /tmp/r218_npu7.lock.log (12:31 preflight … 13:14 END).

- **attempt 1 (12:33–12:38)**: wrapped `GPUModelRunner.execute_model`
  (vllm core). Legs rc=0, identity green, but NO hook artifacts: the V1
  EngineCore on Ascend uses `vllm_ascend.worker.model_runner_v1.NPUModelRunner`
  which OVERRIDES execute_model (model_runner_v1.py:1900) — wrapping the base
  class has no effect. (side observation: r114 steady rows were written from
  the EngineCore pid, proving hooks reach EngineCore only via inherited state.)
- **attempt 2 (12:44–12:49)**: polled sys.modules for the right module from
  sitecustomize only. Legs rc=0, but poll_started came from a helper pid
  (3647), NOT the EngineCore (3599): the EngineCore child is created by FORK
  and does not re-run sitecustomize; a bare sys.modules poll in sitecustomize
  only covers spawned children. No artifacts.
- **attempt 3 (12:58–13:01)**: eagerly imported
  `vllm_ascend.worker.model_runner_v1` in the CAN driver before LLM(). Failed:
  circular import (`DeviceOperator` from partially initialized
  `vllm_ascend.device.device_op`) poisoned the engine; both legs leg_rc=1
  (engine never came up). Lesson: never eager-import that module in the driver.
- **attempt 4 (13:04–13:09, FINAL)**: dual-path idempotent hook —
  (a) sitecustomize: poll sys.modules (spawn path) AND `os.register_at_fork(
  after_in_child=...)` arm (fork path); (b) CAN copy: same poll + fork arming
  in the driver, no eager import. Both legs rc=0, identity green, hook
  "installed" IN the EngineCore (pid 5724/6692, note=sitecustomize-poll),
  12 steps profiled each, chrome traces exported (229/18 MB).
  Probe overhead measured in-leg: INT2 +197.67 ms/step, BF16 +21.24 ms/step.

cfg gate: profiling_20261024/sitecustomize_r218prof/r218prof_cfg.json
(enabled only during a leg; the leg script disables it afterwards).
CAN delta: CAN_DIFF.txt (31 added lines; frozen CAN untouched).
Overlay: ZERO file changes in ov_restore (verify: gates.txt [R218ID] sha
85051bbd2e74c117 identical to frozen legs).
