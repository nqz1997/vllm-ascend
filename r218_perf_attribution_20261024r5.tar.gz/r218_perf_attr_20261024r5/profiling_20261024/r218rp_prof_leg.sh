#!/usr/bin/env bash
# R218 sub-B profiling leg (2026-10-24). Identical envelope to the frozen
# r218rp_leg.sh thrcap leg (bg1/bg2 2K/C32 posture: NS=32 CTX=2048 GMU=0.75
# MNBT env=0 -> engine default 8192, eager, points="32" only), plus ONE env-side
# delta: R118_SC points at sitecustomize_r218prof so the EngineCore subprocess
# loads the torch_npu profiler hook. NO overlay file is modified.
# usage: r218rp_prof_leg.sh <mode B|N> <tag> [dev]
set -u
MODEARG=$1; TAG=$2; DEV=${3:-7}
PHASE=thrcap; NS=32; CTX=2048; GMU=0.75; MNBT=0
OSD=/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD
RAW=/home/n00928095/OSCAR_PARALLEL_WORK/R172_INTEGRATION_PRODUCT_WIN/RAW
RC5=/home/n00928095/OSCAR_PARALLEL_WORK/R172_INTEGRATION_PRODUCT_WIN/TASK_OWNED/RC/rc5
RP=$OSD/acceptance/report_eval
PROF=$RP/profiling_20261024
OV=$OSD/acceptance/runs/prv3/ov_restore
VEND=/home/n00928095/OSCAR_PARALLEL_WORK/R173_INT2_UNPACK_EXECUTION_UNIT_MIGRATION/TASK_OWNED/local_opp/vendors/oscar_b1_r218emitgrp
OUT=$RP/runs/$TAG
mkdir -p "$OUT"

# per-leg profiler cfg (read by sitecustomize at EngineCore spawn)
WARM=${R218PROF_WARM:-8}; NSTEPS=${R218PROF_NSTEPS:-12}
python3 - "$PROF/sitecustomize_r218prof/r218prof_cfg.json" "$OUT" "$WARM" "$NSTEPS" <<'PY'
import json, sys, time
cfgp, out, warm, nsteps = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
json.dump({"enabled": True, "batch": 32, "warm": warm, "nsteps": nsteps,
           "steplog": out + "/prof_steps.jsonl",
           "out_prefix": out + "/prof",
           "install_deadline_s": 1200,
           "written": time.strftime("%FT%T")},
          open(cfgp, "w"), indent=1)
PY

export R146S=0
LEGSJSON=$(python3 -c "import json;print(json.dumps({'phase':'thrcap','outdir':'$OUT','points':'32','ctx':2048},separators=(',',':')))")

# host-side peak-HBM sampler for this device
( for i in $(seq 1 900); do
    npu-smi info -t usages -i "$DEV" 2>/dev/null | awk -F: '/HBM Usage Rate/ {gsub(/ /,"",$2); print strftime("%s"), $2}'
    sleep 2
  done ) >> "$OUT/hbm_samples.txt" &
SAMP=$!
trap "kill $SAMP 2>/dev/null" EXIT

RC_ENV_SH=$RC5/RC_ENV.sh RC_VENDOR="$VEND" \
R218_SERVE_CAN=$PROF/r218_report_eval_prof.py R218_MODE=$MODEARG R218_LD_MAX=0 R218_LD_RELAY=0 \
R218_EXTRA="export R218_LGP=3; export R148_OVERLAY=$OV; export R151_CANLEGS=2; \
export R157_OPP=; export R166_LEGS_JSON='$LEGSJSON'; export R164_MNBT=$MNBT; export R152_EAGER=1; export R148_MODE=$MODEARG; \
export R144_LAUNCHER_SRC=$OV/csrc/oscar/int2_op_launch_lse_fast_r152.cpp; \
export R144_LAUNCHER_NAME=int2_lse_fast_r152; export OSCAR_OPP_PATH=$VEND; \
export OSCAR_LSE_BRIDGE_SRC=$OV/csrc/oscar/int2_op_launch_lse_r98.cpp; \
export TORCH_EXTENSIONS_DIR=$OV/torch_ext; export R118_SC=$PROF/sitecustomize_r218prof; \
export R148_GMU=$GMU; export R116_GMU=$GMU; export R109_TT_MAX_SEQS=$NS" \
  timeout ${R218RP_TO:-7200} bash $RAW/r218_lddet_rc.sh "$TAG" "$DEV" "$VEND" "$NS" 12 "$CTX" \
  > "$OUT/leg.driver.log" 2>&1
LEGRC=$?
kill $SAMP 2>/dev/null
SL=$RAW/serve/serve_${TAG}.log
cp "$SL" "$OUT/serve.log" 2>/dev/null
# disable the profiler cfg again so any later python is inert
python3 -c "import json;p='$PROF/sitecustomize_r218prof/r218prof_cfg.json';d=json.load(open(p));d['enabled']=False;json.dump(d,open(p,'w'),indent=1)"
{
  echo "leg_rc=$LEGRC"
  grep -m1 "R218ID" "$SL" 2>/dev/null | cut -c1-220
  grep -m1 "R159K-ID" "$SL" 2>/dev/null | grep -oE "md5=[0-9a-f]+"
  grep -iE "KV cache size|Maximum concurrency|Running: 32" "$SL" 2>/dev/null | head -4
  grep -m1 "ASCEND_LAUNCH_BLOCKING=" "$SL" 2>/dev/null
  grep -m1 "R118_SC=" "$SL" 2>/dev/null
  echo "prof_cfg: warm=$WARM nsteps=$NSTEPS batch=32"
  echo "can: r218_report_eval_prof.py (= frozen CAN + idempotent profiler injection; sitecustomize_r218prof via R118_SC; no overlay file changed)"
  grep -m1 "R218PROF" "$SL" 2>/dev/null
  ls -la "$OUT"/prof.* 2>/dev/null
  tail -2 "$OUT/prof_steps.jsonl" 2>/dev/null
  tail -3 "$OUT/leg.driver.log" 2>/dev/null
} > "$OUT/gates.txt"
cat "$OUT/gates.txt"
exit $LEGRC
