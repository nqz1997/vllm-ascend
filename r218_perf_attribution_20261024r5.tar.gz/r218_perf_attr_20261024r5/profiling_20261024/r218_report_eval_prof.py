#!/usr/bin/env python3
"""R218 REPORT EVAL — frozen-spec per-question BF16/INT2 service evaluation.

Runs INSIDE oscar-r103-runner as the R164_SERVE_CAN payload (same boot/env
section as r218_needle_eval_rc.py, the proven instrument). Phase is carried
through the docker env whitelist via R166_LEGS_JSON (inert to the framework:
R166_MULTILEG defaults 0). All question sets are FROZEN manifests in
$RP (see SPEC.md). Greedy (t=0) everywhere; identical prompts for both modes.
"""
import os, sys, json, time, argparse, warnings, hashlib, ctypes
warnings.filterwarnings("ignore")

R116W = os.environ.get("R116_WORKDIR",
        "/home/n00928095/OSCAR_PARALLEL_WORK/R138_FINAL_SUPPLEMENTARY_EVIDENCE")
R114 = "/home/n00928095/OSCAR_PARALLEL_WORK/R114_TRUE_FUSION_OPAQUE_GRAPH_RELIABLE_TPOT"
R113 = "/home/n00928095/OSCAR_PARALLEL_WORK/R113_BGRAPH_GRAPH_VISIBLE_CPP_ORCH_PERF"
R106V = ("/home/n00928095/OSCAR_PARALLEL_WORK/"
         "R106_R99_R105_CROSSHARNESS_KVSPAN_ROOTCLOSE_CANDIDATE_FRAMEWORKB_NAB/"
         "RUNNER_VENDOR/vendors/oscar_r106_candidate")
R133V = ("/home/n00928095/OSCAR_PARALLEL_WORK/"
         "R133_GRAPH_NATIVE_DYNAMIC_LENGTH/TASK_OWNED/vendors/oscar_r133_v1")
R116V = "/home/n00928095/OSCAR_PARALLEL_WORK/R118_GRAPH_INPUT_FULLMODEL_PROFILE/TASK_OWNED/custom_opp_r116v2"
OVERLAY = os.environ.get("R148_OVERLAY",
        "/home/n00928095/OSCAR_PARALLEL_WORK/R150_NATIVE_PREFILL_INTEGRATION_AND_8K_PRODUCT_GATE/TASK_OWNED/vllm_ascend_r150")
RP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval"

ap = argparse.ArgumentParser()
ap.add_argument("--model", default=os.environ.get("R116_MODEL", "/home/n00928095/models/Qwen3-8B"))
ap.add_argument("--tokenizer", default=os.environ.get("R116_TOKENIZER", ""))
ap.add_argument("--rot-dir", default=os.environ.get("R116_ROT_DIR", "/home/n00928095/models/rotation/qwen3-8B"))
ap.add_argument("--max-model-len", type=int, default=int(os.environ.get("R116_MML", "2048")))
ap.add_argument("--prompt-file", default=os.environ.get("R116_PROMPT_FILE", R113 + "/DIRECT_RAW/r111_natural_para.txt"))
ap.add_argument("--plen", type=int, default=int(os.environ.get("R116_PLEN", "2")))
ap.add_argument("--decode-tokens", type=int, default=int(os.environ.get("R116_DECODE", "160")))
ap.add_argument("--device", default=os.environ.get("R116_DEV", "4"))
ap.add_argument("--mode", default=os.environ.get("MODE", "B"), choices=["N", "A", "B"])
ap.add_argument("--eager", type=int, default=int(os.environ.get("EAGER", "1")))
ap.add_argument("--leg", default=os.environ.get("LEG", ""))
ap.add_argument("--fused", type=int, default=int(os.environ.get("R116_FUSED_CACHE_UPDATE", "0")))
ap.add_argument("--gpu-mem-util", type=float, default=float(os.environ.get("R116_GMU", "0.85")))
ap.add_argument("--cudagraph-sizes", default=os.environ.get("R116_CG_SIZES", ""))
ap.add_argument("--cudagraph-mode", default=os.environ.get("R116_CG_MODE", ""))
args = ap.parse_args()

LEG = args.leg
EAGER = bool(args.eager)
MODE = args.mode
KVD = "auto" if MODE == "N" else "int2_per_token_head"

os.environ["ASCEND_RT_VISIBLE_DEVICES"] = args.device
os.environ["R41_DEV"] = "0"
os.environ["ASCEND_OPP_PATH"] = "/usr/local/Ascend/cann-9.0.0/opp"
_R144_LEG = os.environ.get("R144_LEG", "grp")
_R144_VENDORS = {
    "base":    "/home/n00928095/OSCAR_PARALLEL_WORK/R142_RUNTIME_BASELINE_AND_REAL_KERNEL_OPT/TASK_OWNED/vendors/oscar_r144_v133c_base",
    "grp":     "/home/n00928095/OSCAR_PARALLEL_WORK/R142_RUNTIME_BASELINE_AND_REAL_KERNEL_OPT/TASK_OWNED/vendors/oscar_r144_v133c_grp",
    "counter": "/home/n00928095/OSCAR_PARALLEL_WORK/R142_RUNTIME_BASELINE_AND_REAL_KERNEL_OPT/TASK_OWNED/vendors/oscar_r144_v133c",
}
_r142cand = _R144_VENDORS.get(_R144_LEG, _R144_VENDORS["grp"])
os.environ["ASCEND_CUSTOM_OPP_PATH"] = (os.environ.get("R157_OPP") + ":" if os.environ.get("R157_OPP") else "") + _r142cand + ":" + R133V + ":" + R116V + ":" + R106V
os.environ["R144_OPP_PATH"] = _r142cand + ":" + R133V + ":" + R116V + ":" + R106V
os.environ["R144_LAUNCHER_SRC"] = os.environ.get("R144_LAUNCHER_SRC",
    "/home/n00928095/OSCAR_PARALLEL_WORK/R152_FULL_GRAPH_CANONICAL_AND_STRIDE_CONTRACT/TASK_OWNED/r152_launcher/int2_op_launch_lse_fast_r152.cpp")
os.environ["R144_LAUNCHER_NAME"] = os.environ.get("R144_LAUNCHER_NAME", "int2_lse_fast_r152")
os.environ["R144_COUNTER_DUMP"] = os.environ.get("R144_COUNTER_DUMP", "0")
os.environ["R144_COUNTER_DIR"] = "/tmp/r145_counter_dumps"
os.makedirs(os.environ["R144_COUNTER_DIR"], exist_ok=True)
os.environ["R144_CORRECT_DUMP"] = os.environ.get("R144_CORRECT_DUMP", "0")
os.environ["R144_CORRECT_DIR"] = "/tmp/r145_correct_dumps_" + _R144_LEG
os.makedirs(os.environ["R144_CORRECT_DIR"], exist_ok=True)
os.environ["LD_LIBRARY_PATH"] = (R133V + "/op_api/lib:" + R116V + "/op_api/lib:" + R106V + "/op_api/lib:"
    + "/usr/local/Ascend/cann-9.0.0/opp/built-in/op_impl/ai_core/tbe/op_host/lib/linux/aarch64"
    + ":/usr/local/Ascend/cann-9.0.0/lib64:" + os.environ.get("LD_LIBRARY_PATH", ""))
os.environ.setdefault("R133_GRAPH_V1", "1")
if os.environ.get("R146_STRIDE", "0") == "1":
    _r146v = os.environ.get("R159K_R146VENDOR", "/home/n00928095/OSCAR_PARALLEL_WORK/R146_SENTINEL_FILL_SERVING_GAINS/TASK_OWNED/vendors/oscar_r146_stride")
    _keep = os.environ["ASCEND_CUSTOM_OPP_PATH"]
    os.environ["ASCEND_CUSTOM_OPP_PATH"] = _r146v + ":" + _keep
    os.environ["R144_OPP_PATH"] = _r146v + ":" + _keep

import hashlib as _hl, glob as _gl
def _r159k_log_lse_identity():
    _opname="oscar_int2_fused_attn_int2_lse"
    _pat=f"OscarInt2FusedAttnInt2Lse_d257ed55d0b9d048872312d5e768d2db.o"
    _paths=os.environ.get("ASCEND_CUSTOM_OPP_PATH","").split(":")
    _resolved=None
    for _p in _paths:
        if not _p: continue
        for _f in _gl.glob(os.path.join(_p,"op_impl/ai_core/tbe/kernel/ascend910b",_opname,_pat)):
            _md5=_hl.md5(open(_f,"rb").read()).hexdigest()[:16]
            _resolved=(_p,_f,_md5); break
        if _resolved: break
    import sys as _sys
    _leg=os.environ.get("R151_CANCFG","?")
    print(f"[R159K-ID] leg={_leg} resolved_lse_vendor={_resolved[0] if _resolved else None} md5={_resolved[2] if _resolved else None} file={_resolved[1] if _resolved else None}", file=_sys.stderr, flush=True)
_r159k_log_lse_identity()

os.environ["TORCH_EXTENSIONS_DIR"] = "/tmp/r145_serve_ext"
os.environ["KERNEL_META"] = R116W + "/TASK_OWNED/kernel_meta"
os.environ["VLLM_LOGGING_LEVEL"] = os.environ.get("VLLM_LOGGING_LEVEL", "WARNING")
os.environ["VLLM_USE_V1"] = "1"
os.environ["SGLANG_OSCAR_K_ROTATION_PATH"] = args.rot_dir.rstrip("/") + "/k_rotation_qqt_r_h_pbr.pt"
os.environ["SGLANG_OSCAR_V_ROTATION_PATH"] = args.rot_dir.rstrip("/") + "/v_rotation_sst_r_h_pbr.pt"
os.environ["R95_R91_BRIDGE"] = "0"
os.environ["R109_THREETIER_MIDDLE"] = "1" if MODE == "B" else "0"
os.environ["R110_THREETIER_MIDDLE"] = os.environ["R109_THREETIER_MIDDLE"]
for k in ("R111_HS", "R111_HASH", "R111_CAPTURE", "R111_CAPTURE_A", "R111_S2DUMP", "R109_CAPTURE"):
    os.environ[k] = "0"
os.environ["R109_TT_PREFIX"] = os.environ.get("R109_TT_PREFIX", "128")
os.environ["R110_TT_PREFIX"] = os.environ["R109_TT_PREFIX"]
os.environ["R109_TT_RECENT"] = os.environ.get("R109_TT_RECENT", "512")
for k in ("R112_LSE_FAST", "R112_NOSTATS", "R112_BUFPOOL", "R113_MIDDLE_CPP",
          "R113_QROT_DEDUPE", "R113_QUANT_CPP", "R113_QUANT_SYNC", "R113_SCATTER_CPP"):
    os.environ.setdefault(k, "1" if MODE == "B" else "0")
os.environ["R114_FUSED_CACHE_UPDATE"] = "0"
os.environ["R115_FUSED_CACHE_UPDATE"] = "0"
os.environ["R116_FUSED_CACHE_UPDATE"] = "1" if args.fused else "0"
os.environ["R115_QUEUE_WRAP"] = "0"
os.environ["R115_MERGE_UNROT"] = "0"
os.environ["R116_QUIET"] = os.environ.get("R116_QUIET", "1")
os.environ["R114_STEADY_HOOK"] = "1"
os.environ["R114_STEADY_OUT"] = "/tmp/r147_steady_%s.jsonl" % LEG
os.environ["R116_STATS_OUT"] = os.environ.get("R147_DATA_DIR", "/tmp") + "/r147_route_%s.json" % LEG
os.environ["R116_WORKDIR"] = R116W
os.environ.setdefault("R137_RK_PROOF_OUT", R116W + "/RAW/r138_rk_proof.jsonl")
os.environ["R116_VENDOR_DIR"] = R116V
os.environ["R116_BINDING_SRC"] = R116W + "/TASK_OWNED/r116_cu_aclnn.cpp"

_SC = os.environ.get("R118_SC", R114 + "/DIRECT_RAW/sitecustomize_r114")
sys.path.insert(0, '/vllm-workspace/vllm-ascend')
os.environ["PYTHONPATH"] = _SC + ":" + OVERLAY + ":" + os.environ.get("PYTHONPATH", "")
sys.path.insert(0, _SC)
sys.path.insert(0, OVERLAY)
ctypes.CDLL("/usr/local/Ascend/driver/lib64/driver/libascend_hal.so", mode=ctypes.RTLD_GLOBAL)
ctypes.CDLL("/usr/local/Ascend/cann-9.0.0/lib64/libopapi.so", mode=ctypes.RTLD_GLOBAL)
ctypes.CDLL(R133V + "/op_api/lib/libcust_opapi.so", mode=ctypes.RTLD_GLOBAL)
_R116V_LIB = R116V + "/op_api/lib/libcust_opapi.so"
if not os.path.exists(_R116V_LIB):   # top-level copy removed by a peer session; vendor-level identical
    _R116V_LIB = R116V + "/vendors/oscar_r115_min/op_api/lib/libcust_opapi.so"
    print("[RP] R116V opapi fallback -> %s" % _R116V_LIB, flush=True)
ctypes.CDLL(_R116V_LIB, mode=ctypes.RTLD_GLOBAL)
ctypes.CDLL(R106V + "/op_api/lib/libcust_opapi.so", mode=ctypes.RTCD_GLOBAL if False else ctypes.RTLD_GLOBAL)

from vllm import LLM, SamplingParams

# ---- phase config through the docker whitelist (R166_MULTILEG defaults 0) ----
_cfg = {}
try:
    _cfg = json.loads(os.environ.get("R166_LEGS_JSON") or "{}")
except Exception as _e:
    print("[RP] BAD R166_LEGS_JSON:", _e); _cfg = {}
PHASE = _cfg.get("phase", "accuracy")
OUTDIR = _cfg.get("outdir", RP + "/runs/" + LEG)
os.makedirs(OUTDIR, exist_ok=True)
print("[RP] phase=%s mode=%s outdir=%s mml=%d" % (PHASE, MODE, OUTDIR, args.max_model_len), flush=True)

t0 = time.time()
NSEQS = int(os.environ.get("R144_G3_NSEQS", "2"))
_llm_kwargs = {}
if args.cudagraph_sizes or args.cudagraph_mode:
    from vllm.config import CompilationConfig
    _cc = {}
    if args.cudagraph_sizes:
        _cc["cudagraph_capture_sizes"] = [int(x) for x in args.cudagraph_sizes.split(",") if x]
    if args.cudagraph_mode:
        _cc["cudagraph_mode"] = args.cudagraph_mode
    _llm_kwargs["compilation_config"] = CompilationConfig(**_cc)

# ==== R218 sub-B profiling injection (profiling legs only; 2026-10-24) ====
# The driver process never imports vllm_ascend.worker.model_runner_v1 itself,
# and eagerly importing it here triggers a circular import (DeviceOperator)
# that poisons the engine startup (attempt-3 lesson, leg_rc=1). Instead: arm
# the same idempotent sys.modules poll in this driver AND in every forked
# child of it (fork children do not re-run sitecustomize). Combined with
# sitecustomize_r218prof (spawn path + its own register_at_fork arming), all
# create-paths of the EngineCore are covered. Inert when cfg is disabled.
try:
    import json as _pjson
    _pcfgp = ("/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/"
              "report_eval/profiling_20261024/sitecustomize_r218prof/"
              "r218prof_cfg.json")
    _pcfg = _pjson.load(open(_pcfgp))
    if _pcfg.get("enabled"):
        import sys as _psys
        import threading as _pth
        _psys.path.insert(0, "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/"
                          "acceptance/report_eval/profiling_20261024/"
                          "sitecustomize_r218prof")
        import r218prof_hook
        try:
            import torch_npu.profiler  # noqa: F401  (prewarm, fork-safe)
        except Exception:
            pass
        _pth.Thread(target=lambda: r218prof_hook.install_when_ready(_pcfg),
                    daemon=True).start()
        os.register_at_fork(after_in_child=lambda: _pth.Thread(
            target=lambda: r218prof_hook.install_when_ready(_pcfg),
            daemon=True).start())
        print("[R218PROF] driver armed (poll+fork) pid=%d" % os.getpid(),
              flush=True)
except Exception as _pe:
    print("[R218PROF] driver arm FAILED: %r" % (_pe,), flush=True)
# ==== end R218 sub-B profiling injection ====

_r164_mnbt = int(os.environ.get("R164_MNBT", "0") or 0)
if _r164_mnbt > 0:
    _llm_kwargs["max_num_batched_tokens"] = _r164_mnbt
llm = LLM(model=args.model, dtype="bfloat16",
          max_model_len=args.max_model_len,
          block_size=int(os.environ.get("R218_BS", "16") or 16),
          enable_chunked_prefill=(os.environ.get("R218_NOCP", "0") != "1"),
          enforce_eager=EAGER,
          gpu_memory_utilization=args.gpu_mem_util, max_num_seqs=NSEQS,
          enable_prefix_caching=False, kv_cache_dtype=KVD,
          disable_log_stats=False, **_llm_kwargs)
load_s = time.time() - t0
print("[RP] engine up in %.1fs (max_num_seqs=%d)" % (load_s, NSEQS), flush=True)

_tk = llm.get_tokenizer()
import random as _nr

# ---------------- frozen question construction (SPEC.md) ----------------
_FILLER = ("In the quiet village of Aldermere, the people tended gardens and kept bees. "
           "The river flowed gently past the old stone bridge at the edge of town. ")
_fid = _tk.encode(_FILLER)
_QSUF = "\n\nQuestion: What is the secret code for the vault?\nAnswer: The secret code is"
_QSUF_IDS = None
def build_needle(ctx, dep, code, maxtok=None):
    global _QSUF_IDS
    _n = max(1, (ctx - 48) // len(_fid))
    _ids = (_fid * (_n + 1))[: _n * len(_fid)]
    _cut = int(_n * dep) * len(_fid)
    _ids = _ids[:_cut] + _tk.encode(f" The secret code for the vault is {code}. ") + _ids[_cut:]
    if _QSUF_IDS is None:
        _QSUF_IDS = _tk.encode(_QSUF)
    return list(_ids) + _QSUF_IDS

CAT_A = json.load(open(RP + "/catA_manifest.json"))
CAT_B = json.load(open(RP + "/catB_manifest.json"))
CAT_C = json.load(open(RP + "/catC_manifest.json"))
CAT_D = json.load(open(RP + "/catD_shuffle_perm.json"))
for q in CAT_A:  # assert the instrument's question stream == frozen manifest
    got = "%05d" % None if False else None
_rchk = _nr.Random(20261017)
for q in CAT_A:
    assert q["code"] == "%05d" % _rchk.randrange(10000, 99999), "catA manifest desync"
print("[RP] catA manifest stream-check OK (105)", flush=True)

def gsm_prompt(item):
    hdr = ""
    for s in CAT_B["shots"]:
        hdr += "Question: %s\nAnswer: %s\n\n" % (s["question"].strip(), s["solution"])
    return hdr + "Question: %s\nAnswer:" % item["question"].strip()

_norm_re = __import__("re")
def _squad_norm(s):
    s = s.lower()
    s = _norm_re.sub(r"\b(a|an|the)\b", " ", s)
    s = "".join(ch if ch.isalnum() or ch == " " else " " for ch in s)
    return " ".join(s.split())
def _tokf1(pred, golds):
    import string
    def cnt(t):
        return _squad_norm(t).split()
    p = cnt(pred); best = 0.0
    for g in golds:
        gg = cnt(g)
        if not p and not gg: return 1.0
        if not p or not gg: continue
        common = {}
        for w in p: common[w] = common.get(w, 0) + 1
        hit = 0
        for w in gg:
            if common.get(w, 0) > 0: common[w] -= 1; hit += 1
        prec = hit / len(p); rec = hit / len(gg)
        best = max(best, (2 * prec * rec / (prec + rec)) if prec + rec else 0.0)
    return best

def _req_metrics(o):
    m = {}
    try:
        mm = o.metrics
        at = getattr(mm, "arrival_time", None)
        ft = getattr(mm, "first_token_ts", None) or getattr(mm, "first_token_time", None)
        lt = getattr(mm, "last_token_ts", None) or getattr(mm, "finished_time", None)
        if at and ft: m["ttft_ms"] = round((ft - at) * 1000, 1)
        if at and lt: m["e2e_ms"] = round((lt - at) * 1000, 1)
    except Exception:
        pass
    return m

def run_one(qid, cat, pids, nt, ref=None, golds=None, note=None):
    t0 = time.time()
    outs = llm.generate([{"prompt_token_ids": pids}], SamplingParams(max_tokens=nt, temperature=0.0), use_tqdm=False)
    wall = round((time.time() - t0) * 1000, 1)
    o = outs[0]; co = o.outputs[0]
    txt = co.text; ids = list(co.token_ids)
    r = {"qid": qid, "cat": cat, "n_in": len(pids), "n_out": len(ids),
         "finish": co.finish_reason, "wall_ms": wall, "txt": txt,
         "sha": __import__("hashlib").sha256(str(ids).encode()).hexdigest()[:16]}
    r.update(_req_metrics(o))
    if cat in ("A", "D") or (note and "code" in note):
        r["code"] = note["code"]; r["hit"] = note["code"] in txt
    elif cat == "B":
        nums = _norm_re.findall(r"-?\d[\d,]*", txt)
        pred = nums[-1].replace(",", "") if nums else None
        r["pred"] = pred; r["ref"] = ref; r["hit"] = (pred is not None and pred.lstrip("-") == str(ref).lstrip("-"))
    elif cat == "C":
        f1 = _tokf1(txt.strip(), golds)
        r["f1"] = round(f1, 4); r["golds"] = golds; r["hit"] = f1 >= 0.5
    if note: r.update({k: v for k, v in note.items() if k not in ("code",)})
    return r, o

RESULTS = {"tag": LEG, "phase": PHASE, "mode": MODE, "mml": args.max_model_len,
           "max_num_seqs": NSEQS, "gmu": args.gpu_mem_util, "rows": []}

# ================= phase: accuracy =================
if PHASE == "accuracy":
    for q in CAT_A:
        pids = build_needle(q["ctx"], q["dep"], q["code"])
        r, _ = run_one("A_c%d_d%.1f_k%d" % (q["ctx"], q["dep"], q["k"]), "A", pids, 12,
                       note={"ctx": q["ctx"], "depth": q["dep"], "k": q["k"], "code": q["code"]})
        RESULTS["rows"].append(r)
        print("[RP-A] %s hit=%s ttft=%s" % (r["qid"], r["hit"], r.get("ttft_ms")), flush=True)
    for i, item in enumerate(CAT_B["test"]):
        pids = _tk.encode(gsm_prompt(item))
        if len(pids) + 330 > args.max_model_len:
            RESULTS["rows"].append({"qid": "B_g%d" % item["gid"], "cat": "B", "skip": "too long", "ref": item["ref"]}); continue
        r, _ = run_one("B_g%d" % item["gid"], "B", pids, 320, ref=item["ref"], note={"gid": item["gid"]})
        RESULTS["rows"].append(r)
        print("[RP-B] %s hit=%s pred=%s ref=%s" % (r["qid"], r["hit"], r["pred"], r["ref"]), flush=True)
    for i, item in enumerate(CAT_C["items"]):
        pids = _tk.encode(item["prompt"])
        r, _ = run_one("C_%s_%s" % (item["src"], i), "C", pids, 64, golds=item["answers"],
                       note={"src": item["src"], "lbid": item["_id"]})
        RESULTS["rows"].append(r)
        print("[RP-C] %s f1=%s" % (r["qid"], r.get("f1")), flush=True)

# ================= phase: order =================
elif PHASE == "order":
    grid2048 = [q for q in CAT_A if q["ctx"] == 2048]
    r6 = [q for q in grid2048 if q["dep"] in (0.1, 0.5, 0.9) and q["k"] in (0, 1)]
    print("[RP-D] sub1 R6 canonical (q0 = process FIRST request)", flush=True)
    for q in r6:
        pids = build_needle(2048, q["dep"], q["code"])
        r, _ = run_one("D_R6_d%.1f_k%d" % (q["dep"], q["k"]), "D", pids, 12, note={"code": q["code"], "sub": "r6_canonical", "depth": q["dep"], "k": q["k"]})
        RESULTS["rows"].append(r); print("[RP-D] %s hit=%s sha=%s" % (r["qid"], r["hit"], r["sha"]), flush=True)
    print("[RP-D] sub2 shuffled 15 (perm seed 20261021)", flush=True)
    for idx in CAT_D["order"]:
        q = grid2048[idx]
        pids = build_needle(2048, q["dep"], q["code"])
        r, _ = run_one("D_SH_d%.1f_k%d" % (q["dep"], q["k"]), "D", pids, 12, note={"code": q["code"], "sub": "shuffled", "grid_idx": idx, "depth": q["dep"], "k": q["k"]})
        RESULTS["rows"].append(r); print("[RP-D] %s hit=%s sha=%s" % (r["qid"], r["hit"], r["sha"]), flush=True)
    print("[RP-D] sub3 mixed-length single batch (9 prompts, one generate)", flush=True)
    mixed = [q for q in CAT_A if q["k"] == 0 and q["dep"] in (0.1, 0.5, 0.9)]
    pl = [{"prompt_token_ids": build_needle(q["ctx"], q["dep"], q["code"])} for q in mixed]
    t0 = time.time()
    outs = llm.generate(pl, SamplingParams(max_tokens=12, temperature=0.0), use_tqdm=False)
    bwall = round((time.time() - t0) * 1000, 1)
    for q, o in zip(mixed, outs):
        co = o.outputs[0]; txt = co.text
        r = {"qid": "D_MX_c%d_d%.1f" % (q["ctx"], q["dep"]), "cat": "D", "sub": "mixed_batch",
             "ctx": q["ctx"], "depth": q["dep"], "code": q["code"], "hit": q["code"] in txt,
             "n_in": len(build_needle(q["ctx"], q["dep"], q["code"])), "n_out": len(co.token_ids),
             "finish": co.finish_reason, "txt": txt, "batch_wall_ms": bwall,
             "sha": __import__("hashlib").sha256(str(list(co.token_ids)).encode()).hexdigest()[:16]}
        r.update(_req_metrics(o))
        RESULTS["rows"].append(r); print("[RP-D] %s hit=%s" % (r["qid"], r["hit"]), flush=True)

# ================= phase: perf =================
elif PHASE == "perf":
    grid2048 = [q for q in CAT_A if q["ctx"] == 2048]
    grid8k = [q for q in CAT_A if q["ctx"] == 8192]
    def timed_single(q, nt, label, warmup=False):
        pids = build_needle(q["ctx"], q["dep"], q["code"])
        r, _ = run_one("E_%s" % label, "E", pids, nt, note={"ctx": q["ctx"], "depth": q["dep"], "warmup": warmup, "code": q["code"]})
        RESULTS["rows"].append(r)
        print("[RP-E] %s ttft=%s e2e=%s n_out=%d" % (label, r.get("ttft_ms"), r.get("e2e_ms"), r["n_out"]), flush=True)
    timed_single(grid2048[0], 64, "W1_warm", warmup=True)
    for i in range(3): timed_single(grid2048[1 + i], 64, "W1_c1_r%d" % i)
    batch8 = grid2048[7:15]
    for rep in range(3):
        pl = [{"prompt_token_ids": build_needle(q["ctx"], q["dep"], q["code"])} for q in batch8]
        t0 = time.time()
        outs = llm.generate(pl, SamplingParams(max_tokens=64, temperature=0.0), use_tqdm=False)
        wall = round((time.time() - t0) * 1000, 1)
        toks = 0; rows = []
        for q, o in zip(batch8, outs):
            co = o.outputs[0]; toks += len(co.token_ids)
            r = {"qid": "E_W2_c8_r%d_c%d_d%.1f" % (rep, q["ctx"], q["dep"]), "cat": "E", "sub": "W2_c8",
                 "ctx": q["ctx"], "depth": q["dep"], "code": q["code"], "hit": q["code"] in co.text,
                 "n_in": None, "n_out": len(co.token_ids), "txt": co.text, "batch_wall_ms": wall}
            r.update(_req_metrics(o)); RESULTS["rows"].append(r); rows.append(r)
        print("[RP-E] W2_c8 rep%d wall=%sms toks=%d mean_ttft=%s" % (rep, wall, toks,
              round(sum(x.get("ttft_ms", 0) for x in rows) / 8, 1)), flush=True)
    timed_single(grid8k[0], 64, "W3_warm", warmup=True)
    for i in range(3): timed_single(grid8k[1 + i], 64, "W3_c1_r%d" % i)

# ================= phase: thrcap (throughput x concurrency grid; SPEC: figure A/B/C) =================
elif PHASE == "thrcap":
    import random as _tr
    TCTX = int(_cfg.get("ctx", 2048)); TNT = int(_cfg.get("nt", 64))
    TPOINTS = [int(x) for x in str(_cfg.get("points", "1,8,32")).split(",") if x]
    if TCTX < 1024:
        raise SystemExit("thrcap: bad ctx %d" % TCTX)
    def _rowcode(i):
        return "%05d" % _tr.Random(20261101 + 7 * i).randrange(10000, 99999)
    def _run_point(C, label):
        pl = [{"prompt_token_ids": build_needle(TCTX, 0.5, _rowcode(i))} for i in range(C)]
        t0 = time.time()
        outs = llm.generate(pl, SamplingParams(max_tokens=TNT, temperature=0.0), use_tqdm=False)
        wall = round((time.time() - t0) * 1000, 1)
        toks = 0; hits = 0; rows = []
        for i, (q, o) in enumerate(zip(pl, outs)):
            co = o.outputs[0]; toks += len(co.token_ids)
            code = _rowcode(i); h = code in co.text; hits += h
            r = {"qid": "G_%s_C%d_r%d" % (label, C, i), "cat": "G", "sub": "thrcap",
                 "ctx": TCTX, "C": C, "row": i, "code": code, "hit": h,
                 "n_out": len(co.token_ids), "txt": co.text, "batch_wall_ms": wall,
                 "ttft_raw": o.metrics and round((getattr(o.metrics, "first_token_ts", 0) or 0) * 1000, 1),
                 "e2e_raw": o.metrics and round((getattr(o.metrics, "last_token_ts", 0) or 0) * 1000, 1)}
            r.update(_req_metrics(o))
            RESULTS["rows"].append(r); rows.append(r)
        span_med = None
        ok = all("ttft_ms" in x for x in rows)
        if ok:
            spans = sorted(x["e2e_ms"] - x["ttft_ms"] for x in rows)
            span_med = spans[len(spans) // 2]
        summary = {"qid": "G_sum_%s_C%d" % (label, C), "cat": "G", "sub": "thrcap_summary",
                   "ctx": TCTX, "C": C, "nrows": C, "hits": hits, "all_hit": hits == C,
                   "batch_wall_ms": wall, "toks": toks, "tok_per_s": round(toks / (wall / 1000), 2),
                   "span_med_ms": span_med, "note": "per-step=%.1fms" % (wall / TNT)}
        RESULTS["rows"].append(summary)
        print("[RP-G] %s C=%d wall=%sms toks=%d %.2f tok/s hits=%d/%d span_med=%s" %
              (label, C, wall, toks, summary["tok_per_s"], hits, C, span_med), flush=True)
        return summary
    for C in TPOINTS:
        _run_point(C, "c%d" % TCTX)

# ================= phase: cap_batch =================
elif PHASE == "cap_batch":
    import random as _rr
    def rowq(i):
        return "%05d" % _rr.Random(20261021 + 1000 * i).randrange(10000, 99999)
    for N in [int(x) for x in _cfg.get("batches", "8,16,32,64,96,128").split(",")]:
        qs = [(i, rowq(i)) for i in range(N)]
        pl = [{"prompt_token_ids": build_needle(2048, 0.5, c)} for _, c in qs]
        t0 = time.time()
        try:
            outs = llm.generate(pl, SamplingParams(max_tokens=64, temperature=0.0), use_tqdm=False)
        except Exception as e:
            RESULTS["rows"].append({"qid": "F_B%d" % N, "cat": "F", "sub": "cap_batch", "n": N, "error": str(e)[:300]})
            print("[RP-F] batch %d ERROR %s" % (N, str(e)[:120]), flush=True)
            break
        wall = round((time.time() - t0) * 1000, 1)
        hits = 0
        for (i, c), o in zip(qs, outs):
            co = o.outputs[0]; h = c in co.text; hits += h
            r = {"qid": "F_B%d_r%d" % (N, i), "cat": "F", "sub": "cap_batch", "n": N, "row": i,
                 "code": c, "hit": h, "n_out": len(co.token_ids), "finish": co.finish_reason, "txt": co.text[:60]}
            r.update(_req_metrics(o)); RESULTS["rows"].append(r)
        RESULTS["rows"].append({"qid": "F_B%d_summary" % N, "cat": "F", "sub": "cap_batch_summary",
                                "n": N, "hits": hits, "nrows": N, "all_hit": hits == N, "wall_ms": wall})
        print("[RP-F] batch %d: %d/%d hit wall=%sms" % (N, hits, N, wall), flush=True)
        if hits != N: break

# ================= phase: cap_ctx =================
elif PHASE == "cap_ctx":
    ctxs = [int(x) for x in _cfg.get("ctxs", "2048,4096,8192,12288,16384").split(",")]
    for ctx in ctxs:
        for dep in (0.1, 0.5):
            if ctx in (2048, 4096, 8192):
                q = next(x for x in CAT_A if x["ctx"] == ctx and x["dep"] == dep and x["k"] == 0)
                code = q["code"]
            else:
                code = "%05d" % _nr.Random(20261022 + ctx + int(dep * 10)).randrange(10000, 99999)
            if ctx + 80 > args.max_model_len:
                RESULTS["rows"].append({"qid": "F_X%d_d%.1f" % (ctx, dep), "cat": "F", "sub": "cap_ctx", "ctx": ctx, "depth": dep, "skip": "ctx > mml"})
                print("[RP-F] ctx %d dep %.1f SKIP (> mml %d)" % (ctx, dep, args.max_model_len), flush=True)
                continue
            pids = build_needle(ctx, dep, code)
            r, _ = run_one("F_X%d_d%.1f" % (ctx, dep), "F", pids, 64, note={"ctx": ctx, "depth": dep, "code": code, "sub": "cap_ctx"})
            RESULTS["rows"].append(r)
            print("[RP-F] ctx %d dep %.1f hit=%s n_in=%d" % (ctx, dep, r["hit"], r["n_in"]), flush=True)

json.dump(RESULTS, open(OUTDIR + "/perq.json", "w"), indent=1)
_h = {"A": [r.get("hit", False) for r in RESULTS["rows"] if r["cat"] == "A" and "hit" in r],
      "B": [r.get("hit", False) for r in RESULTS["rows"] if r["cat"] == "B" and "hit" in r],
      "C": [r.get("hit", False) for r in RESULTS["rows"] if r["cat"] == "C" and "hit" in r]}
print("[RP] FINAL %s mode=%s A=%d/%d B=%d/%d C=%d/%d rows=%d -> %s" % (
    LEG, MODE, sum(_h["A"]), len(_h["A"]), sum(_h["B"]), len(_h["B"]), sum(_h["C"]), len(_h["C"]),
    len(RESULTS["rows"]), OUTDIR + "/perq.json"), flush=True)
