#!/usr/bin/env python3
# R218 sub-B: analyze torch_npu chrome traces from the profiling legs
# (2026-10-24). Pure host-side post-processing; no device access.
#   - kernels: ph=X, cat=None, name not in (Computing, Free)  [device time]
#   - cpu_op : ph=X, cat=cpu_op                               [host API time]
#   - HostToDevice/async_npu cats are ph=f/s flow links (no duration)
# Outputs per leg: <prefix>_ops.csv (op level), <prefix>_summary.json,
# and appends a category table <prefix>_categories.csv.
import json, sys, os, statistics, collections

MARKERS = {"Computing", "Free"}

def load(p):
    with open(p) as f:
        d = json.load(f)
    return d

def union_ms(iv):
    if not iv: return 0.0
    iv.sort()
    tot, cs, ce = 0.0, None, None
    for s, e in iv:
        if cs is None: cs, ce = s, e
        elif s <= ce: ce = max(ce, e)
        else: tot += ce - cs; cs, ce = s, e
    tot += ce - cs
    return tot / 1000.0

def categorize(name):
    n = name
    ln = n.lower()
    if n == "OscarInt2FusedAttnInt2Lse":
        return "middle_exec (frozen kernel)"
    if "oscar" in ln and "attn" not in ln:
        return "oscar other (custom)"
    if "quant" in ln:
        return "rotate+quant (write side, by name)"
    if "rotary" in ln or "rot" in ln.split("_"):
        return "rotate+quant (write side, by name)"
    if "matmul" in ln or n == "RmsNorm" or "LayerNorm" in n or "FlashAttention" in n \
       or "softmax" in ln or "silu" in ln or "swiglu" in ln or "gemm" in ln:
        return "other model compute"
    if "copy" in ln or "memcpy" in ln or "memset" in ln or "contiguous" in ln \
       or "cast" in ln or "concat" in ln or "slice" in ln or "transpose" in ln \
       or "fill" in ln or "traverse" in ln:
        return "copies/moves (incl. carrier staging candidates)"
    return "unmapped (cannot attribute)"

def main(trace_path, steplog_path, nsteps, mode, outdir, prefix):
    d = load(trace_path)
    kn = collections.Counter(); kd = collections.Counter()
    cpu = collections.Counter(); cpud = collections.Counter()
    ivs = []
    for e in d:
        if e.get("ph") != "X":
            continue
        cat = e.get("cat"); nm = e.get("name", "?")
        try: dur = float(e.get("dur", 0) or 0)
        except Exception: dur = 0.0
        if cat is None:
            if nm in MARKERS: continue
            kn[nm] += 1; kd[nm] += dur
            try: ivs.append((float(e.get("ts", 0)), float(e.get("ts", 0)) + dur))
            except Exception: pass
        elif cat == "cpu_op":
            cpu[nm] += 1; cpud[nm] += dur
    ktotal = sum(kd.values())
    # steps from steplog
    unprof, prof = [], []
    for line in open(steplog_path):
        try: r = json.loads(line)
        except Exception: continue
        if r.get("tot") == 32 and r.get("ms"):
            (prof if r.get("p") else unprof).append(r["ms"])
    med_un = statistics.median(unprof) if unprof else None
    med_pr = statistics.median(prof) if prof else None
    busy_union = union_ms(list(ivs))
    os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, prefix + "_ops.csv"), "w") as f:
        f.write("mode,category,op,count,npu_us_total,npu_ms_per_step,"
                "pct_of_step_wall_unprof,pct_of_npu_kernel_total,evidence\n")
        wall = med_un if med_un else 0.0
        for nm, tot_us in sorted(kd.items(), key=lambda kv: -kv[1]):
            ps_ms = tot_us / 1000.0 / nsteps
            f.write("%s,%s,\"%s\",%d,%.1f,%.3f,%.2f,%.2f,trace-direct\n" % (
                mode, categorize(nm), nm, kn[nm], tot_us, ps_ms,
                100 * ps_ms / wall if wall else 0,
                100 * tot_us / ktotal if ktotal else 0))
    cats = collections.defaultdict(float)
    catn = collections.defaultdict(int)
    for nm, tot_us in kd.items():
        c = categorize(nm); cats[c] += tot_us; catn[c] += kn[nm]
    with open(os.path.join(outdir, prefix + "_categories.csv"), "w") as f:
        f.write("mode,category,count,npu_ms_total,npu_ms_per_step,"
                "pct_of_step_wall_unprof,pct_of_npu_kernel_total,evidence\n")
        for c, tot_us in sorted(cats.items(), key=lambda kv: -kv[1]):
            ps_ms = tot_us / 1000.0 / nsteps
            f.write("%s,%s,%d,%.1f,%.3f,%.2f,%.2f,trace-direct (sum of named kernels)\n" % (
                mode, c, catn[c], tot_us / 1000.0, ps_ms,
                100 * ps_ms / med_un if med_un else 0,
                100 * tot_us / ktotal if ktotal else 0))
    summ = {
        "mode": mode, "trace": trace_path, "nsteps": nsteps,
        "kernel_events": sum(kn.values()), "kernel_total_ms": round(ktotal / 1000, 1),
        "kernel_union_ms": round(busy_union, 1),
        "kernel_per_step_ms": round(ktotal / 1000 / nsteps, 2),
        "kernel_union_per_step_ms": round(busy_union / nsteps, 2),
        "cpu_op_events": sum(cpu.values()),
        "cpu_op_total_ms": round(sum(cpud.values()) / 1000, 1),
        "steps_unprofiled_n": len(unprof),
        "steps_unprofiled_median_ms": med_un,
        "steps_profiled_n": len(prof),
        "steps_profiled_median_ms": med_pr,
        "probe_overhead_ms": round(med_pr - med_un, 2) if (med_pr and med_un) else None,
        "top10_kernels": [[n, round(kd[n] / 1000, 1), kn[n]] for n, _ in
                          sorted(kd.items(), key=lambda kv: -kv[1])[:10]],
        "top5_cpu": [[n, round(cpud[n] / 1000, 1), cpu[n]] for n, _ in
                     sorted(cpud.items(), key=lambda kv: -kv[1])[:5]],
    }
    json.dump(summ, open(os.path.join(outdir, prefix + "_summary.json"), "w"),
              indent=1)
    print(json.dumps({k: summ[k] for k in
                      ("mode", "kernel_total_ms", "kernel_per_step_ms",
                       "kernel_union_per_step_ms",
                       "steps_unprofiled_median_ms", "steps_profiled_median_ms",
                       "probe_overhead_ms")}))

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4],
         sys.argv[5], sys.argv[6])
