# R218 sub-B profiling hook core (2026-10-24).
# Wraps NPUModelRunner.execute_model (vllm_ascend.worker.model_runner_v1 —
# this subclass OVERRIDES the vllm-core method, model_runner_v1.py:1900)
# with a torch_npu.profiler window gated on pure-decode steps at batch==C.
# Idempotent via the _r218prof attribute, so it is safe to install from BOTH
# the CAN driver (fork-inheritance path) and sitecustomize (spawned-children
# path) without double wrapping.
import os
import json
import time
import threading


def install(cls, cfg, note=""):
    if getattr(cls.execute_model, "_r218prof", False):
        return False
    try:
        from torch_npu.profiler import profile as _tprof
        from torch_npu.profiler import ProfilerActivity as _PAct
    except Exception as e:
        try:
            with open(cfg["steplog"], "a") as d:
                d.write(json.dumps({"ev": "no_torch_npu_profiler",
                                    "err": repr(e)}) + "\n")
        except Exception:
            pass
        return False
    orig = cls.execute_model
    st = {"n": 0, "dec": 0, "prof": None, "prof_n": 0, "done": False}
    BATCH = int(cfg.get("batch", 32))
    WARM = int(cfg.get("warm", 10))
    NSTEPS = int(cfg.get("nsteps", 12))
    fh = open(cfg["steplog"], "a", buffering=1)
    fh.write(json.dumps({"ev": "installed", "pid": os.getpid(),
                         "ppid": os.getppid(), "note": note,
                         "batch": BATCH, "warm": WARM, "nsteps": NSTEPS,
                         "t": time.time()}) + "\n")

    def _export(prof):
        import traceback
        pre = cfg["out_prefix"]
        try:
            prof.export_chrome_trace(pre + ".trace.json")
            # torch_npu 2.10.0 profile has no key_averages(); the per-op
            # aggregate table is computed from the exported trace by
            # analyze_prof_trace.py on the host.
            with open(pre + ".DONE", "w") as f:
                f.write("exported %s\n" % time.strftime("%FT%T"))
        except Exception:
            with open(pre + ".EXPORT_FAIL", "w") as f:
                f.write(traceback.format_exc())

    def wrapped(self, scheduler_output, *a, **kw):
        tot = getattr(scheduler_output, "total_num_scheduled_tokens", None)
        nreq = None
        try:
            nreq = len(getattr(scheduler_output, "scheduled_reqs", []) or [])
        except Exception:
            pass
        is_dec = (tot == BATCH)
        if st["prof"] is None and not st["done"] and is_dec:
            st["dec"] += 1
            if st["dec"] > WARM:
                st["prof"] = _tprof(
                    activities=[_PAct.CPU, _PAct.NPU],
                    record_shapes=False, with_stack=False)
                st["prof"].start()
                fh.write(json.dumps({"ev": "prof_start", "n": st["n"] + 1,
                                     "pid": os.getpid(),
                                     "t": time.time()}) + "\n")
        t0 = time.perf_counter()
        try:
            out = orig(self, scheduler_output, *a, **kw)
        finally:
            ms = (time.perf_counter() - t0) * 1000.0
            st["n"] += 1
            fh.write(json.dumps({
                "n": st["n"], "tot": tot, "nreq": nreq,
                "ms": round(ms, 2),
                "p": (st["prof"] is not None and not st["done"])}) + "\n")
        if st["prof"] is not None and not st["done"]:
            st["prof_n"] += 1
            if st["prof_n"] >= NSTEPS:
                try:
                    st["prof"].stop()
                    fh.write(json.dumps({"ev": "prof_stop", "n": st["n"],
                                         "steps": st["prof_n"],
                                         "pid": os.getpid()}) + "\n")
                    _export(st["prof"])
                except Exception as e:
                    fh.write(json.dumps({"ev": "prof_stop_err",
                                         "err": repr(e)}) + "\n")
                st["prof"] = None
                st["done"] = True
                fh.write(json.dumps({"ev": "prof_done", "n": st["n"],
                                     "t": time.time()}) + "\n")
        return out

    wrapped._r218prof = True
    cls.execute_model = wrapped
    return True


def rearm(cfg):
    # for forked children of a process that installed the hook: the patched
    # class is inherited, so this is normally a no-op; kept as belt-and-braces
    # for children whose memory was patched BEFORE the guard attribute existed.
    try:
        import sys
        m = sys.modules.get("vllm_ascend.worker.model_runner_v1")
        if m is not None:
            install(m.NPUModelRunner, cfg, note="rearm")
    except Exception:
        pass


def install_when_ready(cfg, timeout_s=240):
    # poll sys.modules only (no imports in this thread); for spawned children
    # whose sitecustomize ran at interpreter start.
    import sys
    try:
        fh = open(cfg["steplog"], "a", buffering=1)
        fh.write(json.dumps({"ev": "poll_started", "pid": os.getpid(),
                             "ppid": os.getppid(),
                             "t": time.time()}) + "\n")
    except Exception:
        pass
    deadline = time.time() + float(timeout_s)
    while time.time() < deadline:
        m = sys.modules.get("vllm_ascend.worker.model_runner_v1")
        if m is not None and hasattr(m, "NPUModelRunner"):
            install(m.NPUModelRunner, cfg, note="sitecustomize-poll")
            return True
        time.sleep(0.2)
    try:
        with open(cfg["steplog"], "a") as d:
            d.write(json.dumps({"ev": "install_failed_no_module",
                                "pid": os.getpid()}) + "\n")
    except Exception:
        pass
    return False
