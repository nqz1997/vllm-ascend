# R218 sub-B profiling sitecustomize (2026-10-24).
# Chains the proven R137 sitecustomize (which chains R114 steady hook) verbatim
# via absolute-path exec, then — only when the cfg file enables it — installs
# the torch_npu profiler hook in THIS process once (and only if) it imports
# vllm_ascend.worker.model_runner_v1. This covers SPAWNED children. The CAN
# driver additionally installs the hook directly before LLM() creation
# (r218_report_eval_prof.py), covering FORKED EngineCore children that inherit
# the patched class without re-running sitecustomize. Both installs are
# idempotent (see r218prof_hook.py). NO overlay file is modified.
import os

# 1) chain the R137 sitecustomize (default R118_SC payload of the frozen leg)
try:
    _r137 = ("/home/n00928095/OSCAR_PARALLEL_WORK/"
             "R141_INT2_ATTENTION_KERNEL_MAJOR_OPTIMIZATION/TASK_OWNED/"
             "sitecustomize_r137/sitecustomize.py")
    with open(_r137) as _f:
        exec(compile(_f.read(), _r137, "exec"), {"__name__": "r137_sitecustomize"})
except Exception as _e:
    try:
        with open("/tmp/r218prof.diag", "a") as _d:
            _d.write("r137 chain failed: %r\n" % (_e,))
    except Exception:
        pass

# 2) profiler hook, cfg-file gated; covers spawned interpreter children only
_CFG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "r218prof_cfg.json")
try:
    import json as _json
    _cfg = _json.load(open(_CFG))
except Exception:
    _cfg = None

if _cfg and _cfg.get("enabled"):
    import threading as _threading

    def _arm():
        try:
            import sys
            sys.path.insert(0, os.path.dirname(_CFG))
            import r218prof_hook
            # prewarm torch_npu.profiler so forked children never need to
            # import it post-fork (import-lock deadlock avoidance)
            try:
                import torch_npu.profiler  # noqa: F401
            except Exception:
                pass
            r218prof_hook.install_when_ready(_cfg)
        except Exception:
            pass

    _threading.Thread(target=_arm, daemon=True).start()

    # FORK coverage: the V1 EngineCore on this stack is created by fork from
    # a process that ran this sitecustomize (observed 2026-10-24: the r114
    # steady wrap reached the EngineCore exactly this way). Fork children do
    # NOT re-run sitecustomize, so arm a poll thread inside every forked
    # child of every sitecustomize process. Idempotent with all other paths.
    def _arm_in_fork_child():
        try:
            _threading.Thread(target=_arm, daemon=True).start()
        except Exception:
            pass

    try:
        os.register_at_fork(after_in_child=_arm_in_fork_child)
    except Exception:
        pass
