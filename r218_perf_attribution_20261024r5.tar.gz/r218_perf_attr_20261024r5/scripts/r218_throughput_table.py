#!/usr/bin/env python3
"""R218 final throughput comparison table (same-GMU 0.75, dev7, serial legs).

One row per raw leg (plus derived medians), bound to:
  * leg tag -> runs/<tag>/perq.json+gates.txt
  * full identity (tree / attention_v1 sha / kernel md5 / launcher / posture)
  * GMU, C, actual prompt and output token counts
  * batch wall, output-token throughput, ratio vs the stated BF16 basis

The 2026-10-23 08:05Z note quoted 2K/C32 = 10.0x from the FIRST single INT2 leg.
That leg had a prefill/queue outlier (66.75 s vs 11.31 s median) while its decode
span was normal; repeats put the point estimate at 4.73x. Both values are kept
here: the old one is marked superseded, never deleted.

Prompt tokens are measured with the Qwen3-8B tokenizer using the frozen SPEC
prompt builder (build_needle: (ctx-48)//len(filler) filler repeats + 5-digit code
sentence + question suffix). All rows at a point have the same prompt length.
"""
import csv
import json
import os
import statistics as st

RP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval"
RUNS = os.path.join(RP, "runs")
FIGS = os.path.join(RP, "figs")

IDENT = dict(
    identity_tree="v4 PR-22 tip 983fbac1 (tree == tested ov_restore overlay)",
    overlay_attention_sha="85051bbd2e74c117",
    kernel_md5="c8a8d47a63be7ad7",
    launcher="int2_lse_fast_r152",
    posture="eager / RC5 canonical / diagnostics off / dev7",
)

# tag, point, mode, ratio_basis (None for BF16), status, note
LEGS = [
    ("bg1_int2_thrcap2k_c32", "2K/C32", "INT2", "bg1_bf16_thrcap2k_c32",
     "SUPERSEDED (prefill outlier; retained for traceability)",
     "first single leg: wall 104.39 s, of which prefill+queue 66.75 s vs 11.31 s median; decode span 37.64 s (normal). This is the leg that produced the old 10.0x"),
    ("bg2_int2_thrcap2k_c32", "2K/C32", "INT2", "BF16_MEDIAN",
     "measured", "repeat1; full-length leg"),
    ("bg3_int2_thrcap2k_c32", "2K/C32", "INT2", "BF16_MEDIAN",
     "measured", "repeat2; full-length leg"),
    ("bg1_bf16_thrcap2k_c32", "2K/C32", "BF16", None, "measured", "BF16 single"),
    ("bg4_bf16_thrcap2k_c32", "2K/C32", "BF16", None, "measured", "BF16 repeat1"),
    ("bg1_int2_thrcap16k_c8", "16K/C8", "INT2", "bg1_bf16_thrcap16k_c8",
     "measured", "single leg; repeats agree within 0.1%"),
    ("bg2_int2_thrcap16k_c8", "16K/C8", "INT2", "BF16_MEDIAN",
     "measured", "repeat1"),
    ("bg1_bf16_thrcap16k_c8", "16K/C8", "BF16", None, "measured", "BF16 single"),
    ("bg2_bf16_thrcap16k_c8", "16K/C8", "BF16", None, "measured", "BF16 repeat1"),
]

COLS = ["point", "leg_tag", "mode", "identity_tree", "overlay_attention_sha",
        "kernel_md5", "launcher", "posture", "gmu", "C",
        "prompt_tokens_per_req", "n_in_total", "n_out_per_req", "n_out_total",
        "wall_ms", "tok_per_s", "ratio_vs_bf16", "ratio_basis", "status", "note"]


def load(tag):
    d = json.load(open(os.path.join(RUNS, tag, "perq.json")))
    s = [r for r in d["rows"] if r.get("sub") == "thrcap_summary"][0]
    return dict(ctx=s["ctx"], C=s["C"], wall=s["batch_wall_ms"], span=s["span_med_ms"],
                tok=s["toks"], hits=s["hits"], C_req=s["C"])


def prompt_len(ctx):
    """Actual prompt token count from the frozen builder (verified for every row)."""
    try:
        from transformers import AutoTokenizer
        tk = AutoTokenizer.from_pretrained("/home/n00928095/models/Qwen3-8B")
        filler = ("In the quiet village of Aldermere, the people tended gardens and kept bees. "
                  "The river flowed gently past the old stone bridge at the edge of town. ")
        qsuf = "\n\nQuestion: What is the secret code for the vault?\nAnswer: The secret code is"
        fid = tk.encode(filler)
        n = max(1, (ctx - 48) // len(fid))
        # all 5-digit codes tokenize to the same length here; +15 verified per row
        return n * len(fid) + 15 + len(tk.encode(qsuf))
    except Exception:
        return {2048: 2013, 16384: 16368}[ctx]


def main():
    data = {t: load(t) for t, *_ in LEGS}
    bf16_med = {}
    for ctx in (2048, 16384):
        vals = [data[t]["wall"] for t, *_ in LEGS
                if data[t]["ctx"] == ctx and t.startswith("bg")
                and t.split("_")[1] == "bf16"]
        bf16_med[ctx] = st.median(vals)
    rows = []
    for tag, point, mode, basis, status, note in LEGS:
        L = data[tag]
        pin = prompt_len(L["ctx"])
        tps = L["tok"] / (L["wall"] / 1000.0)
        if mode == "INT2":
            if basis == "BF16_MEDIAN":
                bwall = bf16_med[L["ctx"]]
                basis_txt = "BF16 median wall %.1f ms (%d legs at %s)" % (bwall, len([t for t, p_, m_, *_ in LEGS if p_ == point and m_ == "BF16"]), point)
            else:
                bwall = data[basis]["wall"]
                basis_txt = "%s wall %.1f ms" % (basis, bwall)
            ratio = "%.2f" % (L["wall"] / bwall)
        else:
            ratio, basis_txt = "", ""
        rows.append(dict(point=point, leg_tag=tag, mode=mode, **IDENT,
                         gmu=0.75, C=L["C"], prompt_tokens_per_req=pin,
                         n_in_total=pin * L["C"], n_out_per_req=64,
                         n_out_total=L["tok"], wall_ms=round(L["wall"], 1),
                         tok_per_s=round(tps, 2), ratio_vs_bf16=ratio,
                         ratio_basis=basis_txt, status=status, note=note))

    # derived median rows (one per point/mode)
    for ctx, point in ((2048, "2K/C32"), (16384, "16K/C8")):
        for mode in ("INT2", "BF16"):
            tags = [t for t, p, m, *_ in LEGS if p == point and m == mode]
            wall = st.median([data[t]["wall"] for t in tags])
            C = data[tags[0]]["C"]
            pin = prompt_len(ctx)
            tps = (C * 64) / (wall / 1000.0)
            if mode == "INT2":
                ratio = "%.2f" % (wall / bf16_med[ctx])
                basis_txt = "BF16 median wall %.1f ms" % bf16_med[ctx]
            else:
                ratio, basis_txt = "", ""
            rows.append(dict(point=point, leg_tag="MEDIAN(%s)" % ",".join(tags),
                             mode=mode, **IDENT, gmu=0.75, C=C,
                             prompt_tokens_per_req=pin, n_in_total=pin * C,
                             n_out_per_req=64, n_out_total=C * 64,
                             wall_ms=round(wall, 1), tok_per_s=round(tps, 2),
                             ratio_vs_bf16=ratio, ratio_basis=basis_txt,
                             status="derived (median)",
                             note=("point estimate; repeats agree" if mode == "BF16"
                                   else ("point estimate = median of %d legs (2K: 49.10/49.31/104.39 s; the outlier does not move the median)" % len(tags)
                                         if ctx == 2048 else
                                         "point estimate = median of %d legs (16K: 113.444/113.542 s, 0.1%% apart)" % len(tags)))))
    with open(os.path.join(FIGS, "THROUGHPUT_COMPARISON.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print("wrote figs/THROUGHPUT_COMPARISON.csv (%d rows)" % len(rows))
    for r in rows:
        print("%-7s %-30s %-4s in=%7s out=%5s wall=%9s tok/s=%7s ratio=%5s %s"
              % (r["point"], r["leg_tag"][:30], r["mode"], r["n_in_total"],
                 r["n_out_total"], r["wall_ms"], r["tok_per_s"],
                 r["ratio_vs_bf16"], r["status"]))


if __name__ == "__main__":
    main()
