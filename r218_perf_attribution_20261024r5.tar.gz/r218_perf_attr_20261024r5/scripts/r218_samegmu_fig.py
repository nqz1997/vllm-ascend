#!/usr/bin/env python3
"""R218 same-GMU (0.75) matched-pair figure.

Separate from r218_triple (which keeps the original per-mode-GMU posture).
Reads figs/INT2_vs_BF16_attribution.csv (produced by r218_attribution_table.py)
and plots, for the two measured points only:

  left  - aggregate output-token throughput (BF16 vs INT2), the honest
          end-to-end number for the same workload;
  right - where the batch wall went: prefill+queue vs decode, split per mode.

Caption carries the caveats: tokens counted are generated tokens only, the
wall includes prefill; both legs run at gpu_memory_utilization 0.75 with the
same 29.52 GiB KV allocation, so the 8.00x pool ratio is NOT an 8x HBM saving;
HBM peaks 93% (INT2) vs 77% (BF16) because the INT2 path carries extra
per-step workspace.
"""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval"
FIGS = os.path.join(RP, "figs")
C_INT2, C_BF16 = "#d62728", "#1f77b4"

rows = list(csv.DictReader(open(os.path.join(FIGS, "INT2_vs_BF16_attribution.csv"))))


def get(panel, row):
    for r in rows:
        if r["panel"] == panel and r["row"].startswith(row):
            return r
    return None


POINTS = [("A75", "2K / C=32"), ("B75", "16K / C=8")]
data = {}
for panel, label in POINTS:
    i_wall = float(get(panel, "INT2 wall")["value_ms"])
    b_wall = float(get(panel, "BF16 wall")["value_ms"])
    i_pre = float(get(panel, "INT2 prefill")["value_ms"])
    b_pre = float(get(panel, "BF16 prefill")["value_ms"])
    data[panel] = dict(label=label, i_wall=i_wall, b_wall=b_wall,
                       i_pre=i_pre, b_pre=b_pre,
                       i_dec=i_wall - i_pre, b_dec=b_wall - b_pre)

fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(17.0, 4.9), gridspec_kw={"width_ratios": [0.95, 1.25, 1.05]})

# ---- left: throughput ----
xs = range(len(POINTS))
for off, mode, col in ((-0.18, "BF16", C_BF16), (0.18, "INT2", C_INT2)):
    vals = [data[p]["b_wall" if mode == "BF16" else "i_wall"] for p, _ in POINTS]
    toks = [32 * 64 if p == "A75" else 8 * 64 for p, _ in POINTS]
    tps = [t / (w / 1000.0) for t, w in zip(toks, vals)]
    bars = ax1.bar([x + off for x in xs], tps, width=0.34, color=col, label=mode)
    for b, v in zip(bars, tps):
        ax1.text(b.get_x() + b.get_width() / 2, v * 1.06, "%.1f" % v,
                 ha="center", fontsize=8)
ax1.set_yscale("log")
ax1.set_xticks(list(xs))
ax1.set_xticklabels([data[p]["label"] for p, _ in POINTS])
ax1.set_ylabel("aggregate output-token throughput (tok/s, log)")
ax1.set_title("Same workload, same GMU 0.75: BF16 vs INT2")
ax1.legend(frameon=False, fontsize=8)
ax1.grid(axis="y", alpha=.25, which="both")

# ---- right: wall split ----
labels, i_pre, i_dec, b_pre, b_dec = [], [], [], [], []
for p, label in POINTS:
    d = data[p]
    labels += ["%s\nBF16" % label, "%s\nINT2" % label]
    b_pre.append(d["b_pre"]); b_dec.append(d["b_dec"])
    i_pre.append(d["i_pre"]); i_dec.append(d["i_dec"])
ypos = range(len(labels))
pre = [b_pre[0], i_pre[0], b_pre[1], i_pre[1]]
dec = [b_dec[0], i_dec[0], b_dec[1], i_dec[1]]
ax2.barh(list(ypos), pre, color="#bbbbbb", label="prefill + queueing")
ax2.barh(list(ypos), dec, left=pre, color="#666666", label="decode (first->last token span)")
for y, p_, d_ in zip(ypos, pre, dec):
    ax2.text(p_ + d_ + 900, y, "%.1f s total\n(%.0f%% decode)" % ((p_ + d_) / 1000.0, 100 * d_ / (p_ + d_)),
             va="center", fontsize=8)
ax2.set_yticks(list(ypos))
ax2.set_yticklabels(labels, fontsize=8)
ax2.set_xlabel("batch wall (ms)")
ax2.set_xlim(0, max(p + d for p, d in zip(pre, dec)) * 1.30)
ax2.invert_yaxis()
ax2.legend(frameon=False, fontsize=8, loc="upper right")
ax2.set_title("Where the batch wall goes (measured, not instrumented)")

# ---- right: capacity vs device HBM peak (two different postures) ----
CAP = {
    "BF16": [(77.0, 214912, "BF16 GMU0.75"), (79.1, 223744, "BF16 GMU0.77")],
    "INT2": [(93.0, 1719424, "INT2 GMU0.75"), (80.6, 956032, "INT2 GMU0.535")],
}
OFF = {(77.0, 214912): (-8, 10), (79.1, 223744): (8, -12),
       (93.0, 1719424): (-10, -14), (80.6, 956032): (8, 4)}
for mode, pts in CAP.items():
    col = C_BF16 if mode == "BF16" else C_INT2
    xs_ = [p[0] for p in pts]; ys_ = [p[1] for p in pts]
    ax3.scatter(xs_, ys_, s=64, color=col, label=mode, zorder=3)
    for xv, yv, lab in pts:
        ax3.annotate("%s\n%.0fK tok" % (lab, yv / 1000.0), (xv, yv),
                     textcoords="offset points", xytext=OFF.get((xv, yv), (6, -4)),
                     fontsize=6.5, ha="right" if OFF.get((xv, yv), (6, 0))[0] < 0 else "left")
# connect the two pairs
for i, (style, txt) in enumerate((("-", "8.00x pool\n(GMU 0.75 both; HBM not matched)"),
                                  (":", "4.27x pool\n(HBM matched +/-1.9%)"))):
    b = CAP["BF16"][1 - i]; a = CAP["INT2"][1 - i]
    ax3.plot([b[0], a[0]], [b[1], a[1]], style, color="#444444", lw=1.2, zorder=2)
    px, py = ((86.6, 7.6e5) if i == 0 else (83.2, 4.7e5))
    ax3.annotate(txt, (px, py), fontsize=6.5, ha="center", va="center", color="#222222",
                 bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#999999", lw=0.5))
ax3.set_yscale("log")
ax3.set_xlabel("device HBM peak (%)")
ax3.set_ylabel("KV pool tokens (log)")
ax3.set_title("Capacity is real; 8x pool != 8x HBM saving")
ax3.set_xlim(70, 100)
ax3.set_ylim(1.85e5, 2.9e6)
ax3.grid(alpha=.25, which="both")
ax3.legend(frameon=False, fontsize=8, loc="lower right")

fig.text(.5, .012,
         "Measured points only. tok/s counts GENERATED tokens; the wall includes prefill, so this is end-to-end, not decode-only.\n"
         "Both legs: gpu_mem_util 0.75, KV allocation 29.52 GiB, block 128, max_num_batched_tokens 8192, eager, frozen kernel c8a8d47a.\n"
         "KV pool 1,719,424 vs 214,912 tokens = 8.00x, but HBM peak 93% vs 77%: INT2 carries ~10 GiB extra per-step workspace, so the 8x pool ratio is not an 8x HBM saving.\n"
         "INT2 2K/C32 wall is the median of 3 repeats (single-shot range 49.1-104.4 s; decode throughput identical across all three). "
         "Right panel: pool tokens are engine-reported capacity, NOT a servable batch; tested active batch is 32 (2K) / 8 (16K) / 64 (prcap pair).",
         ha="center", fontsize=6.8)

fig.tight_layout(rect=(0, .11, 1, .96))
for ext in ("png", "svg", "pdf"):
    fig.savefig(os.path.join(FIGS, "r218_samegmu_pair.%s" % ext), dpi=160)
print("wrote figs/r218_samegmu_pair.png/svg/pdf")
