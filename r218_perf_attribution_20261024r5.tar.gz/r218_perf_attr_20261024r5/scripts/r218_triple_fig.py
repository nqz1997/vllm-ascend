#!/usr/bin/env python3
"""R218 triple figure (A/B/C) + CSV from thrcap/perf/cap legs.
A: input 2K  -> aggregate output throughput vs client concurrency C
B: input 16K -> aggregate output throughput vs C
C: input length -> max VERIFIED quality-gated active batch
Only measured points are plotted; OOM/quality-fail/timeout/untested get
distinct markers and never count toward the capacity boundary."""
import json, os, csv, glob
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval"
RUN = RP + "/runs"
OUTD = RP + "/figs"
os.makedirs(OUTD, exist_ok=True)

C_INT2, C_BF16 = "#d62728", "#1f77b4"

def load(tag):
    p = f"{RUN}/{tag}/perq.json"
    return json.load(open(p)) if os.path.exists(p) else None

def thrcap_points(tag):
    d = load(tag)
    if not d: return {}
    pts = {}
    for r in d["rows"]:
        if r.get("sub") == "thrcap_summary":
            pts[(r["ctx"], r["C"])] = r
    return pts

def perf_c1(tag, wl, ctx):
    """C=1 throughput from perf legs (W1 ctx2048 / W3 ctx8192)."""
    d = load(tag)
    if not d: return None
    rs = [r for r in d["rows"] if r["qid"].startswith("E_%s_c1" % wl) and not r.get("warmup") and "wall_ms" in r]
    if not rs: return None
    walls = [r["wall_ms"] for r in rs]; toks = sum(r["n_out"] for r in rs)
    return round(toks / (sum(walls) / 1000), 2)

def capbatch_max(tag):
    d = load(tag)
    if not d: return None
    ns = [r["n"] for r in d["rows"] if r.get("sub") == "cap_batch_summary" and r.get("all_hit")]
    return max(ns) if ns else None

def capctx_ok(tag):
    """max ctx fully green at c=4 (cap_ctx legs)."""
    d = load(tag)
    if not d: return {}
    ok = {}
    for r in d["rows"]:
        if r.get("sub") == "cap_ctx" and r.get("hit"):
            ok[r["ctx"]] = max(ok.get(r["ctx"], 0), 1)
    return sorted(ok)

rows_csv = []

def add_csv(panel, ctx, C, mode, toks, wall, all_hit, status, source):
    rows_csv.append(dict(panel=panel, ctx=ctx, C=C, mode=mode, tok_per_s=toks,
                         batch_wall_ms=wall, all_hit=all_hit, status=status, source=source))

# ---- gather ----
ti = thrcap_points("rp_int2_thrcap2k"); tb = thrcap_points("rp_bf16_thrcap2k")
ti8 = thrcap_points("rp_int2_thrcap8k"); tb8 = thrcap_points("rp_bf16_thrcap8k")
ti16 = thrcap_points("rp_int2_thrcap16k"); tb16 = thrcap_points("rp_bf16_thrcap16k")

def series(pts, c1, label):
    xs, ys, ok_flags = [], [], []
    if c1 is not None:
        xs.append(1); ys.append(c1); ok_flags.append("hit")
    for (ctx, C), r in sorted(pts.items()):
        xs.append(C); ys.append(r["tok_per_s"]); ok_flags.append("hit" if r["all_hit"] else "qualfail")
    return xs, ys, ok_flags

xi, yi, oi = series(ti, perf_c1("rp_int2_perf", "W1", 2048), "i2")
xb, yb, ob = series(tb, perf_c1("rp_bf16_perf", "W1", 2048), "bf")
xi16, yi16, oi16 = series(ti16, None, "i2")
xb16, yb16, ob16 = series(tb16, None, "bf")

for x, y, o in zip(xi, yi, oi): add_csv("A", 2048, x, "INT2", y, None, o == "hit", o, "thrcap/perf")
for x, y, o in zip(xb, yb, ob): add_csv("A", 2048, x, "BF16", y, None, o == "hit", o, "thrcap/perf")
for x, y, o in zip(xi16, yi16, oi16): add_csv("B", 16384, x, "INT2", y, None, o == "hit", o, "thrcap")
for x, y, o in zip(xb16, yb16, ob16): add_csv("B", 16384, x, "BF16", y, None, o == "hit", o, "thrcap")
for mode, pts in (("INT2", ti8), ("BF16", tb8)):
    for (ctx, C), r in sorted(pts.items()):
        add_csv("A8k", ctx, C, mode, r["tok_per_s"], r["batch_wall_ms"], r["all_hit"],
                "hit" if r["all_hit"] else "qualfail", "thrcap")

# ---- same-GMU (0.75) matched pairs (2026-10-23 grid + repeats) ----
# Appended to the CSV only: the A/B/C panels above keep their original
# per-mode-GMU posture. Separate rendering: figs/r218_samegmu_pair.*
_SAME_GMU = [("A75", 2048, 32, "INT2", ["bg2_int2_thrcap2k_c32", "bg3_int2_thrcap2k_c32"],
              "runs/bg2+bg3 median (bg1 19.62 tok/s @104392 ms = prefill outlier)"),
             ("A75", 2048, 32, "BF16", ["bg1_bf16_thrcap2k_c32", "bg4_bf16_thrcap2k_c32"], "runs/bg1+bg4 median"),
             ("B75", 16384, 8, "INT2", ["bg1_int2_thrcap16k_c8", "bg2_int2_thrcap16k_c8"], "runs/bg1+bg2 median"),
             ("B75", 16384, 8, "BF16", ["bg1_bf16_thrcap16k_c8", "bg2_bf16_thrcap16k_c8"], "runs/bg1+bg2 median")]
for panel, ctx, C, mode, tags, src in _SAME_GMU:
    ws, toks, hits, Cseen = [], 0, 0, C
    for t in tags:
        r = thrcap_points(t).get((ctx, C))
        if r:
            ws.append(r["batch_wall_ms"]); toks = r["toks"]; hits += r["hits"]; Cseen = r["C"]
    if not ws: continue
    ws.sort(); wall = ws[len(ws)//2] if len(ws) % 2 else 0.5*(ws[len(ws)//2-1]+ws[len(ws)//2])
    add_csv(panel, ctx, C, mode, round(toks/(wall/1000), 2), round(wall, 1),
            hits == Cseen*len(ws), "hit" if hits == Cseen*len(ws) else "qualfail", src)

# panel C: max verified quality-gated active batch per (mode, ctx)
panelC = {}
cb_i = capbatch_max("rp_int2_cap_batch"); cb_b = capbatch_max("rp_bf16_cap_batch")
if cb_i: panelC[("INT2", 2048)] = cb_i
if cb_b: panelC[("BF16", 2048)] = cb_b
for mode, pts in (("INT2", ti), ("BF16", tb)):   # thrcap2k supersedes cap_batch when higher
    ok = [C for (ctx, C), r in pts.items() if r.get("all_hit")]
    if ok:
        panelC[(mode, 2048)] = max(panelC.get((mode, 2048), 0), max(ok))
for pts, mode in ((ti8, "INT2"), (tb8, "BF16")):
    ok = [C for (ctx, C), r in pts.items() if r["all_hit"]]
    if ok: panelC[(mode, 8192)] = max(ok)
for pts, mode in ((ti16, "INT2"), (tb16, "BF16")):
    ok = [C for (ctx, C), r in pts.items() if r["all_hit"]]
    if ok: panelC[(mode, 16384)] = max(ok)
# 4K: only cap_ctx c=4 evidence exists (batch not probed above 4)
for mode, tag in (("INT2", "rp_int2_cap_ctx"), ("BF16", "rp_bf16_cap_ctx")):
    ok = capctx_ok(tag)
    if ok: panelC[(mode, 4096)] = 4  # tested at c=4 only (labeled as tested-not-max in caption)
for (mode, ctx), v in sorted(panelC.items()):
    add_csv("C", ctx, None, mode, None, None, True, "max_verified_batch=%d" % v, "cap_batch/cap_ctx/thrcap")

with open(OUTD + "/triple_data.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_csv[0].keys()))
    w.writeheader(); w.writerows(rows_csv)

# ---- plot ----
fig, axes = plt.subplots(1, 3, figsize=(16.5, 4.6))
def draw(ax, xs, ys, ok, color, label):
    xs_ok = [x for x, o in zip(xs, ok) if o == "hit"]; ys_ok = [y for y, o in zip(ys, ok) if o == "hit"]
    xs_b = [x for x, o in zip(xs, ok) if o != "hit"]; ys_b = [y for y, o in zip(ys, ok) if o != "hit"]
    ax.plot(xs_ok, ys_ok, "o-", color=color, label=label, markersize=6)
    if xs_b: ax.scatter(xs_b, ys_b, marker="x", color=color, s=70, label=label + " (quality-fail)")

A, B, C = axes
draw(A, xb, yb, ob, C_BF16, "BF16 KV"); draw(A, xi, yi, oi, C_INT2, "OSCAR INT2 KV")
A.set_xscale("log", base=2)
A.set_xticks([1, 8, 32, 64, 128]); A.set_xticklabels(["1", "8", "32", "64", "128"])
A.set_xlabel("client concurrency C (= active batch, one call)"); A.set_ylabel("output throughput (tok/s)")
A.set_title("A: input 2048 tok, out 64 tok/req"); A.grid(alpha=.3); A.legend(fontsize=8)

draw(B, xb16, yb16, ob16, C_BF16, "BF16 KV"); draw(B, xi16, yi16, oi16, C_INT2, "OSCAR INT2 KV")
B.set_xscale("log", base=2); B.set_xticks(sorted(set(xi16 + xb16)) or [1, 8, 32]); B.set_xticklabels([str(t) for t in (sorted(set(xi16 + xb16)) or [1, 8, 32])])
B.set_xlabel("client concurrency C"); B.set_ylabel("output throughput (tok/s)")
B.set_title("B: input 16384 tok, out 64 tok/req"); B.grid(alpha=.3); B.legend(fontsize=8)

ctxs = sorted({c for (_, c) in panelC})
w_ = 0.35
for i, (mode, color) in enumerate((("BF16", C_BF16), ("INT2", C_INT2))):
    vals = [panelC.get((mode, c)) for c in ctxs]
    C.bar([x + (i - .5) * w_ for x in range(len(ctxs))], [v or 0 for v in vals], w_, color=color, label=mode)
    for x, v in zip(range(len(ctxs)), vals):
        if v: C.text(x + (i - .5) * w_, v, str(v), ha="center", va="bottom", fontsize=8)
        else: C.text(x + (i - .5) * w_, .5, "—", ha="center", fontsize=9)
C.set_xticks(range(len(ctxs))); C.set_xticklabels(["%d" % c for c in ctxs])
C.set_xlabel("input context length (tok)"); C.set_ylabel("max VERIFIED quality-gated batch")
C.set_title("C: capacity = all-rows-correct needle batches"); C.grid(alpha=.3, axis="y"); C.legend(fontsize=8)

fig.suptitle("Ascend 910B3 (64GB HBM) · Qwen3-8B · same PR overlay + frozen kernel c8a8d47a · eager · greedy · NT=64 · "
             "BF16 pool enlarged within same HBM budget", fontsize=9)
fig.text(.5, .012, "Only measured points plotted (× = quality-fail, not counted as capacity). Panel C: 4K tested at c=4 only (tested, not max); "
         "16K INT2 tested to 32 (engine pool 1,009,280 tok = 60.65x), BF16 verified 16 and 32-residency physically infeasible "
         "(pool 281,472 tok = 16.92x < 32x16,640; HBM peak 91%). Out cap 64 tok/req (NT=64 gate); per-point actual tokens, "
         "NS/pool/HBM and per-request records: PERF_POINT_EVIDENCE.csv.", ha="center", fontsize=7.5)
fig.tight_layout(rect=(0, .04, 1, .95))
for ext in ("png", "svg", "pdf"):
    fig.savefig(f"{OUTD}/r218_triple.{ext}", dpi=160)
print("figure + csv ->", OUTD)
