#!/usr/bin/env python3
"""Fold the bg1_ four-leg same-GMU throughput grid into the report CSVs.

Reads runs/<tag>/{perq.json,serve.log,gates.txt,hbm_peak.txt} and appends rows to
figs/triple_data.csv and figs/PERF_POINT_EVIDENCE.csv, plus emits
figs/bg1_fourleg_protocol.csv (identity + protocol, one row per leg).

Idempotent: a leg already present in a CSV is skipped. Old rows are never
modified; the new points use distinct panel labels (A75/B75) so the original
per-mode-GMU panels (A/B, gmu 0.55 INT2 / 0.75-0.9 BF16) stay as they were.

Panel A75 = ctx 2048 / C=32, Panel B75 = ctx 16384 / C=8; both at gmu 0.75.
"""
import csv
import json
import os
import re
import sys

RP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval"
RUNS = os.path.join(RP, "runs")
FIGS = os.path.join(RP, "figs")

# canonical folded points (diagnostic legs stay out of the figure CSVs)
LEGS = [
    ("bg1_int2_thrcap2k_c32", "A75", "INT2"),
    ("bg1_bf16_thrcap2k_c32", "A75", "BF16"),
    ("bg1_int2_thrcap16k_c8", "B75", "INT2"),
    ("bg1_bf16_thrcap16k_c8", "B75", "BF16"),
]

TD_COLS = ["panel", "ctx", "C", "mode", "tok_per_s", "batch_wall_ms", "all_hit", "status", "source"]
PP_COLS = ["panel", "leg", "mode", "ctx", "C", "NS", "mml", "gmu", "pool_tokens",
           "engine_max_conc", "n", "succ", "out_cap_per_req", "out_actual_sum",
           "tok_per_s", "tpot_p50", "tpot_p95", "wall_ms", "hbm_peak", "status",
           "evidence", "note"]
PROTO_COLS = ["tag", "panel", "mode", "kv_cache_dtype", "ctx_prompt_tokens", "max_model_len",
              "block_size", "max_num_batched_tokens", "max_num_seqs", "gpu_mem_util",
              "kv_pool_tokens", "engine_max_conc", "hbm_peak_pct", "C", "n_out_cap",
              "n_out_total", "hits", "wall_ms", "tok_per_s", "decode_span_ms",
              "decode_span_ms_per_tok", "prefill_plus_queue_ms", "overlay_attention_sha",
              "kernel_md5", "served_model", "vllm_version"]


def read_leg(tag):
    d = os.path.join(RUNS, tag)
    perq = json.load(open(os.path.join(d, "perq.json")))
    summ = [r for r in perq["rows"] if r.get("sub") == "thrcap_summary"][0]
    log = open(os.path.join(d, "serve.log"), errors="ignore").read()
    m = re.search(r"GPU KV cache size: ([\d,]+) tokens", log)
    pool = int(m.group(1).replace(",", "")) if m else None
    m = re.search(r"Maximum concurrency for [\d,]+ tokens per request: ([\d.]+)x", log)
    conc = float(m.group(1)) if m else None
    m = re.search(r"'kv_cache_dtype': '([a-z0-9_]+)'", log)
    kvd = m.group(1) if m else "auto"
    m = re.search(r"Chunked prefill is enabled with max_num_batched_tokens=(\d+)", log)
    mnbt = int(m.group(1)) if m else None
    m = re.search(r"'block_size': (\d+)", log)
    bs = int(m.group(1)) if m else None
    m = re.search(r"'max_num_seqs': (\d+)", log)
    nseq = int(m.group(1)) if m else None
    m = re.search(r"'gpu_memory_utilization': ([\d.]+)", log)
    gmu = float(m.group(1)) if m else None
    m = re.search(r"'max_model_len': (\d+)", log)
    mml = int(m.group(1)) if m else None
    m = re.search(r"initializing a V1 LLM engine \(v([\d.]+)\)", log)
    vllm_v = m.group(1) if m else ""
    m = re.search(r"\[R218ID\] file=(\S+) sha=([0-9a-f]+)", log)
    ov_sha = m.group(2) if m else ""
    m = re.search(r"md5=([0-9a-f]{16})", log)
    kmd5 = m.group(1) if m else ""
    hbm = open(os.path.join(d, "hbm_peak.txt")).read().strip().split("=")[-1]
    span = summ.get("span_med_ms")
    wall = summ["batch_wall_ms"]
    return dict(tag=tag, mode=perq["mode"], ctx=summ["ctx"], C=summ["C"],
                wall=wall, tok_s=summ["tok_per_s"], hits=summ["hits"],
                n_out=summ["toks"], span=span, pool=pool, conc=conc, kvd=kvd,
                mnbt=mnbt, bs=bs, nseq=nseq, gmu=gmu, mml=mml, vllm=vllm_v,
                ov_sha=ov_sha, kmd5=kmd5, hbm=hbm)


def existing(path, key_col):
    if not os.path.exists(path):
        return set()
    with open(path, newline="") as f:
        return {r.get(key_col) for r in csv.DictReader(f)}


def append_rows(path, cols, rows, key_col):
    seen = existing(path, key_col)
    new = [r for r in rows if str(r[key_col]) not in seen]
    if not new:
        print("no new rows for %s" % os.path.basename(path))
        return 0
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        for r in new:
            w.writerow(r)
    print("appended %d row(s) to %s" % (len(new), os.path.basename(path)))
    return len(new)


def main():
    legs = {tag: read_leg(tag) for tag, _, _ in LEGS}
    td, pp, proto = [], [], []
    for tag, panel, mode in LEGS:
        L = legs[tag]
        stat = "hit" if L["hits"] == L["C"] else "miss"
        note = ("same-GMU(0.75) matched pair; decode span %.0f ms / 64 tok = %.0f ms/tok; "
                "tok/s counts generated tokens only, wall includes prefill"
                % (L["span"], L["span"] / 63.0))
        td.append(dict(panel=panel, ctx=L["ctx"], C=L["C"], mode=mode,
                       tok_per_s=L["tok_s"], batch_wall_ms=L["wall"],
                       all_hit=(L["hits"] == L["C"]), status=stat,
                       source="runs/%s" % tag))
        pp.append(dict(panel=panel, leg=tag, mode=mode, ctx=L["ctx"], C=L["C"],
                       NS=L["nseq"], mml=L["mml"], gmu=L["gmu"], pool_tokens=L["pool"],
                       engine_max_conc=L["conc"], n=L["C"], succ=L["hits"],
                       out_cap_per_req=64, out_actual_sum=L["n_out"],
                       tok_per_s=L["tok_s"], tpot_p50="", tpot_p95="",
                       wall_ms=L["wall"], hbm_peak=L["hbm"], status=stat,
                       evidence="runs/%s/perq.json+gates.txt+hbm_samples.txt" % tag,
                       note=note))
        proto.append(dict(tag=tag, panel=panel, mode=mode, kv_cache_dtype=L["kvd"],
                          ctx_prompt_tokens=L["ctx"], max_model_len=L["mml"],
                          block_size=L["bs"], max_num_batched_tokens=L["mnbt"],
                          max_num_seqs=L["nseq"], gpu_mem_util=L["gmu"],
                          kv_pool_tokens=L["pool"], engine_max_conc=L["conc"],
                          hbm_peak_pct=L["hbm"], C=L["C"], n_out_cap=64,
                          n_out_total=L["n_out"], hits=L["hits"], wall_ms=L["wall"],
                          tok_per_s=L["tok_s"], decode_span_ms=round(L["span"], 1),
                          decode_span_ms_per_tok=round(L["span"] / 63.0, 1),
                          prefill_plus_queue_ms=round(L["wall"] - L["span"], 1),
                          overlay_attention_sha=L["ov_sha"], kernel_md5=L["kmd5"],
                          served_model="Qwen3-8B", vllm_version=L["vllm"]))
    append_rows(os.path.join(FIGS, "triple_data.csv"), TD_COLS, td, "source")
    append_rows(os.path.join(FIGS, "PERF_POINT_EVIDENCE.csv"), PP_COLS, pp, "leg")
    with open(os.path.join(FIGS, "bg1_fourleg_protocol.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=PROTO_COLS)
        w.writeheader()
        for r in proto:
            w.writerow(r)
    print("wrote figs/bg1_fourleg_protocol.csv (%d rows)" % len(proto))


if __name__ == "__main__":
    sys.exit(main())
