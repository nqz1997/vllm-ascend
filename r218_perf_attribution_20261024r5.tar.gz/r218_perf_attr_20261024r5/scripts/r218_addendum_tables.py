#!/usr/bin/env python3
"""R218 addendum tables (2026-10-24).

Pure re-analysis of the already-published background legs (no new NPU run).
Reads:
  runs/<tag>/perq.json        per-request first/last token timestamps
  figs/bg_legs_raw.json       wall / decode-span summaries used by the ledger
  /home/n00928095/R218_UPSTREAM_WORK/opbench_delivered.json  direct-call microbench
Writes:
  figs/PERF_ATTRIBUTION_ADDENDUM_20261024.csv
  figs/PERF_STEP_STATS_20261024.csv

Conventions (same as R218_PERF_ATTRIBUTION_20261023.md):
  * wall = prefill+queue + decode span
  * decode span = per-request first->last token, 63 intervals for 64 output tokens
  * step metrics are decode-step metrics unless the column says wall
  * deltas are baseline minus ablated; positive = the gate saved wall time
  * share_gap_pct is ALWAYS relative to the point's total wall gap
  * the ledger is NOT additive; overlap is not measured
  * pooled span stats mix rows and repeats; the published ledger uses
    median-of-leg-medians instead (difference <= 0.4%)
"""
import json
import os
import statistics as st

RP = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(RP, "runs")
FIGS = os.path.join(RP, "figs")
RAW = json.load(open(os.path.join(FIGS, "bg_legs_raw.json")))
OPB = json.load(open("/home/n00928095/R218_UPSTREAM_WORK/opbench_delivered.json"))

STEPS = 63          # 64 output tokens -> 63 first->last intervals
LAYERS = 36         # Qwen3-8B num_hidden_layers
KV_BYTES = 512      # per KV token: 2 (K,V) * 8 kv heads * 128 dim * 2 bit / 8

POINTS = {
    "2K/C32": dict(
        ctx=2048, C=32, n_in=64416, n_out=2048,
        int2_wall=49309.9, bf16_wall=10415.3,
        int2_dec=37999.8, bf16_dec=7516.5,
        nomide=RAW["bg2_int2_thrcap2k_c32_nomide"],
        noslide2=RAW["bg4_int2_2k_c32_noslide2"],
        nosrstage=RAW["bg4_int2_2k_c32_nosrstage"],
        nogstage=RAW["bg4_int2_2k_c32_nogstage"],
        opb=next(p for p in OPB["points"] if p["label"] == "2k_c32"),
        uncovered_decode=28221.0, uncovered_prefill=6877.0, uncovered_total=35098.0,
        span_tags=["bg1_int2_thrcap2k_c32", "bg2_int2_thrcap2k_c32", "bg3_int2_thrcap2k_c32"],
        bf16_span_tags=["bg1_bf16_thrcap2k_c32", "bg4_bf16_thrcap2k_c32"],
        engine_int2="55.5-55.7 tok/s / 32 reqs -> 574-577 ms/step (10 s samples)",
        engine_bf16="no steady sample (wall 10.4 s < 10 s log interval); span-based only",
    ),
    "16K/C8": dict(
        ctx=16384, C=8, n_in=130944, n_out=512,
        int2_wall=113493.1, bf16_wall=19399.8,
        int2_dec=73361.7, bf16_dec=11823.0,
        nomide=RAW["bg5_int2_16k_c8_nomide"],
        noslide2=RAW["bg5_int2_16k_c8_noslide2"],
        nosrstage=None, nogstage=None,
        opb=next(p for p in OPB["points"] if p["label"] == "16k_c8"),
        uncovered_decode=16715.5, uncovered_prefill=23928.7, uncovered_total=40644.2,
        span_tags=["bg1_int2_thrcap16k_c8", "bg2_int2_thrcap16k_c8"],
        bf16_span_tags=["bg1_bf16_thrcap16k_c8", "bg2_bf16_thrcap16k_c8"],
        engine_int2="8.4 tok/s / 8 reqs -> 952 ms/step (10 s samples)",
        engine_bf16="single late sample 4.0 tok/s / 8 reqs (straddles finish) -> not used",
    ),
}


def span_stats(tags):
    """Per-leg upper-median spans (the report's span_med convention), then
    median-of-leg-medians; distribution stats are pooled. ttft spread is
    computed WITHIN each leg (different legs use different monotonic clocks)."""
    spans, spreads, leg_meds = [], [], []
    for t in tags:
        j = json.load(open(os.path.join(RUNS, t, "perq.json")))
        rows = [r for r in j["rows"] if r.get("n_out")]
        sp = sorted(r["e2e_raw"] - r["ttft_raw"] for r in rows)
        spans += sp
        leg_meds.append(sp[len(sp) // 2])          # upper median, report convention
        tt = [r["ttft_raw"] for r in rows]
        spreads.append(max(tt) - min(tt))
    q1, q3 = st.quantiles(spans, n=4)[0], st.quantiles(spans, n=4)[2]
    point_med = st.median(leg_meds)
    return dict(n=len(spans), point_med=point_med, leg_meds=leg_meds,
                q1=q1, q3=q3, mn=min(spans), mx=max(spans),
                ttft_spread=max(spreads))


rows = []


def add(**kw):
    rows.append(kw)


for point, P in POINTS.items():
    gap = P["int2_wall"] - P["bf16_wall"]
    dec_gap = P["int2_dec"] - P["bf16_dec"]
    pre_gap = (P["int2_wall"] - P["int2_dec"]) - (P["bf16_wall"] - P["bf16_dec"])
    step_gap = dec_gap / STEPS
    kv_tok = P["n_in"] + P["C"] * 31.5
    us_kv = step_gap * 1000 / kv_tok
    gbs = (KV_BYTES / (us_kv / LAYERS * 1e-6)) / 1e9
    micro_kernel = P["opb"]["oscar_int2_op_ms"] * LAYERS
    micro_quant = P["opb"]["quant_kv_ms"] * LAYERS
    micro_sum = micro_kernel + micro_quant
    nom = P["nomide"]
    nom_wall = P["int2_wall"] - nom["wall"]
    nom_dec = P["int2_dec"] - nom["span"]
    nom_pre = nom_wall - nom_dec
    nom_remaining = (nom["span"] - P["bf16_dec"]) / STEPS
    ns2_wall = P["int2_wall"] - P["noslide2"]["wall"] if P["noslide2"] else None
    ns2_dec = P["int2_dec"] - P["noslide2"]["span"] if P["noslide2"] else None
    nrs_wall = P["int2_wall"] - P["nosrstage"]["wall"] if P["nosrstage"] else None
    ngs_wall = P["int2_wall"] - P["nogstage"]["wall"] if P["nogstage"] else None
    share = lambda v: round(100 * v / gap, 1)

    add(point=point, category="total", item="total wall gap (INT2-BF16)", phase="wall",
        value_ms=round(gap, 1), unit="ms", per_step_ms=round(gap / STEPS, 2),
        share_gap_pct=100.0, basis="median wall difference", confidence="proven",
        source="bg_legs_raw.json + attribution CSV")
    add(point=point, category="total", item="decode gap", phase="decode",
        value_ms=round(dec_gap, 1), unit="ms", per_step_ms=round(step_gap, 2),
        share_gap_pct=share(dec_gap), basis="median decode span difference",
        confidence="proven", source="attribution CSV")
    add(point=point, category="total", item="prefill+queue gap", phase="prefill",
        value_ms=round(pre_gap, 1), unit="ms", per_step_ms=round(pre_gap / P["n_in"], 3),
        share_gap_pct=share(pre_gap), basis="wall - decode span difference; per_step_ms = ms/input-token",
        confidence="proven", source="attribution CSV")
    add(point=point, category="scale", item="decode step gap per KV token", phase="decode",
        value_ms=round(us_kv, 3), unit="us/KV-token/step", per_step_ms="",
        share_gap_pct="", basis="kv_tokens = n_in + C*31.5 = %d" % kv_tok,
        confidence="proven", source="arithmetic")
    add(point=point, category="scale", item="implied per-layer bandwidth of the extra time", phase="decode",
        value_ms=round(gbs, 2), unit="GB/s", per_step_ms="",
        share_gap_pct="", basis="512 B per KV token / per-layer share of the step gap",
        confidence="proven (arithmetic)", source="arithmetic")
    add(point=point, category="middle_exec", item="NOMIDE wall differential (diagnostic)", phase="wall",
        value_ms=round(nom_wall, 1), unit="ms", per_step_ms=round(nom_wall / STEPS, 2),
        share_gap_pct=share(nom_wall), basis="end-to-end wall difference; outputs WRONG (0 hits)",
        confidence="proven (diagnostic only)", source=("%s_nomide" % ("bg2_int2_thrcap2k_c32" if point=="2K/C32" else "bg5_int2_16k_c8")))
    add(point=point, category="middle_exec", item="NOMIDE decode differential", phase="decode",
        value_ms=round(nom_dec, 1), unit="ms", per_step_ms=round(nom_dec / STEPS, 2),
        share_gap_pct=share(nom_dec), basis="decode span difference",
        confidence="proven (diagnostic only)", source="same")
    add(point=point, category="middle_exec", item="NOMIDE prefill+queue differential", phase="prefill",
        value_ms=round(nom_pre, 1), unit="ms", per_step_ms=round(nom_pre / P["n_in"], 3),
        share_gap_pct=share(nom_pre), basis="wall - decode difference; per_step_ms = ms/input-token",
        confidence="proven (diagnostic only)", source="same")
    add(point=point, category="middle_exec", item="remaining decode gap with middle op skipped", phase="decode",
        value_ms=round(nom["span"] - P["bf16_dec"], 1), unit="ms", per_step_ms=round(nom_remaining, 2),
        share_gap_pct=share(nom["span"] - P["bf16_dec"]),
        basis="NOMIDE decode span - BF16 decode span", confidence="proven (diagnostic only)", source="same")
    add(point=point, category="operand_prep", item="operand/carrier preparation", phase="decode",
        value_ms="not measured", unit="ms", per_step_ms="", share_gap_pct="",
        basis="no gate deletes the fill/gather; NOMIDE early-returns AFTER carrier assembly",
        confidence="unknown", source="middle_exec.py:1290-1385")
    add(point=point, category="rotation_quant", item="quant/rotation direct call x36", phase="decode",
        value_ms=round(micro_quant * STEPS, 1), unit="ms", per_step_ms=round(micro_quant, 2),
        share_gap_pct=share(micro_quant * STEPS),
        basis="direct-call median %.3f ms x 36, sync-per-call; flat in S/B" % P["opb"]["quant_kv_ms"],
        confidence="inferred (microbench, not in-serving)", source="opbench_delivered.json")
    add(point=point, category="middle_exec", item="custom attention op direct call x36", phase="decode",
        value_ms=round(micro_kernel * STEPS, 1), unit="ms", per_step_ms=round(micro_kernel, 2),
        share_gap_pct=share(micro_kernel * STEPS),
        basis="direct-call median %.3f ms x 36, sync-per-call; overlaps NOMIDE" % P["opb"]["oscar_int2_op_ms"],
        confidence="inferred (microbench, overlaps NOMIDE)", source="opbench_delivered.json")
    add(point=point, category="middle_exec", item="custom ops (attention+quant) if serialized", phase="decode",
        value_ms=round(micro_sum * STEPS, 1), unit="ms", per_step_ms=round(micro_sum, 2),
        share_gap_pct=share(micro_sum * STEPS),
        basis="sum of two direct-call medians x 36; upper-ish, overlap unmeasured",
        confidence="inferred", source="opbench_delivered.json")
    add(point=point, category="sr", item="NOSRSTAGE wall differential", phase="wall",
        value_ms=round(nrs_wall, 1) if nrs_wall is not None else "not measured", unit="ms",
        per_step_ms=round(nrs_wall / STEPS, 2) if nrs_wall is not None else "",
        share_gap_pct=share(nrs_wall) if nrs_wall is not None else "",
        basis="single-knob gate" if nrs_wall is not None else "not run at this point",
        confidence="proven" if nrs_wall is not None else "unknown",
        source="bg4_int2_2k_c32_nosrstage" if nrs_wall is not None else "n/a")
    add(point=point, category="ring_slide", item="NOSLIDE2 wall differential", phase="wall",
        value_ms=round(ns2_wall, 1), unit="ms", per_step_ms=round(ns2_wall / STEPS, 2),
        share_gap_pct=share(ns2_wall), basis="single-knob gate (slide2 path)",
        confidence="proven", source="bg4_int2_2k_c32_noslide2 / bg5_int2_16k_c8_noslide2")
    add(point=point, category="ring_slide", item="NOSLIDE2 decode differential", phase="decode",
        value_ms=round(ns2_dec, 1), unit="ms", per_step_ms=round(ns2_dec / STEPS, 2),
        share_gap_pct=share(ns2_dec), basis="decode span difference",
        confidence="proven", source="same")
    add(point=point, category="gstage", item="NOGSTAGE wall differential", phase="wall",
        value_ms=round(ngs_wall, 1) if ngs_wall is not None else "not measured", unit="ms",
        per_step_ms=round(ngs_wall / STEPS, 2) if ngs_wall is not None else "",
        share_gap_pct=share(ngs_wall) if ngs_wall is not None else "",
        basis="switch, not delete; negative = slower" if ngs_wall is not None else "not run at this point",
        confidence="proven" if ngs_wall is not None else "unknown",
        source="bg4_int2_2k_c32_nogstage" if ngs_wall is not None else "n/a")
    add(point=point, category="merge", item="merge gate", phase="decode",
        value_ms="not run", unit="ms", per_step_ms="", share_gap_pct="",
        basis="R155_T_NOMERGE exists but was not part of the bg1-bg5 campaign",
        confidence="unknown", source="gates.txt R155_T_NOMERGE=0")
    add(point=point, category="host", item="host-side orchestration / launch", phase="decode",
        value_ms="not measured", unit="ms", per_step_ms="", share_gap_pct="",
        basis="eager, no graph; no host-only gate in this campaign",
        confidence="unknown", source="serve.log compilation_config mode=NONE")
    add(point=point, category="uncovered", item="decode gap not covered by measured gates", phase="decode",
        value_ms=P["uncovered_decode"], unit="ms", per_step_ms=round(P["uncovered_decode"] / STEPS, 2),
        share_gap_pct=share(P["uncovered_decode"]),
        basis="face-value subtraction of positive gate deltas; NOT a residual of an exclusive ledger",
        confidence="proven (bound)", source="attribution CSV")
    add(point=point, category="uncovered", item="prefill+queue gap not covered by measured gates", phase="prefill",
        value_ms=P["uncovered_prefill"], unit="ms", per_step_ms=round(P["uncovered_prefill"] / P["n_in"], 3),
        share_gap_pct=share(P["uncovered_prefill"]), basis="same; per_step_ms = ms/input-token",
        confidence="proven (bound)", source="attribution CSV")
    add(point=point, category="uncovered", item="total gap not covered by measured gates", phase="wall",
        value_ms=P["uncovered_total"], unit="ms", per_step_ms=round(P["uncovered_total"] / STEPS, 2),
        share_gap_pct=share(P["uncovered_total"]),
        basis="lower bound; overlap can only increase it", confidence="proven (bound)",
        source="attribution CSV")

# per-leg pooled step statistics
stats_rows = []
for point, P in POINTS.items():
    for role, tags in (("INT2", P["span_tags"]), ("BF16", P["bf16_span_tags"])):
        s = span_stats(tags)
        stats_rows.append(dict(point=point, role=role, n_rows=s["n"],
                               leg_upper_medians_ms=";".join("%.1f" % x for x in s["leg_meds"]),
                               point_span_med_ms=round(s["point_med"], 1),
                               point_step_med_ms=round(s["point_med"] / STEPS, 2),
                               pooled_q1_ms=round(s["q1"], 1), pooled_q3_ms=round(s["q3"], 1),
                               pooled_min_ms=round(s["mn"], 1), pooled_max_ms=round(s["mx"], 1),
                               ttft_spread_within_leg_ms=round(s["ttft_spread"], 1),
                               engine_sample=P["engine_int2"] if role == "INT2" else P["engine_bf16"],
                               tags=",".join(tags)))

# sanity checks against the published ledger
assert abs((POINTS["2K/C32"]["int2_wall"] - POINTS["2K/C32"]["bf16_wall"]) - 38894.6) < 1
assert abs((POINTS["16K/C8"]["int2_wall"] - POINTS["16K/C8"]["bf16_wall"]) - 94093.3) < 1
assert abs(POINTS["2K/C32"]["nomide"]["span"] - 37158.7) < 1
assert abs(POINTS["16K/C8"]["nomide"]["span"] - 28617.4) < 1
assert abs(POINTS["2K/C32"]["uncovered_total"] - 35098.0) < 1
assert abs(POINTS["16K/C8"]["uncovered_total"] - 40644.2) < 1

cols = ["point", "category", "item", "phase", "value_ms", "unit", "per_step_ms",
        "share_gap_pct", "basis", "confidence", "source"]
out = os.path.join(FIGS, "PERF_ATTRIBUTION_ADDENDUM_20261024.csv")
with open(out, "w") as f:
    f.write(",".join(cols) + "\n")
    for r in rows:
        f.write(",".join('"%s"' % str(r.get(k, "")) for k in cols) + "\n")

cols2 = list(stats_rows[0].keys())
out2 = os.path.join(FIGS, "PERF_STEP_STATS_20261024.csv")
with open(out2, "w") as f:
    f.write(",".join(cols2) + "\n")
    for r in stats_rows:
        f.write(",".join('"%s"' % str(r.get(k, "")) for k in cols2) + "\n")

print("wrote", out, len(rows), "rows")
print("wrote", out2, len(stats_rows), "rows")
for r in stats_rows:
    print(r["point"], r["role"], r["point_step_med_ms"], "ms/step", "point_med", r["point_span_med_ms"], "legs", r["leg_upper_medians_ms"], "ttft spread", r["ttft_spread_within_leg_ms"])
