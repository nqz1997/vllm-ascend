#!/usr/bin/env bash
# R218 report-eval leg runner (frozen SPEC).
# usage: r218rp_leg.sh <phase> <mode B|N> <tag> [dev] [NS] [ctx-for-mml] [gmu] [mnbt]
# Envelope identical to the proven restore-smoke posture (RC5 canonical env,
# bundle-restored v3 overlay, frozen kernel, eager, diagnostics off).
set -u
PHASE=$1; MODEARG=${2:-B}; TAG=$3; DEV=${4:-7}
case $PHASE in
  accuracy|order)   NS=${5:-16}; CTX=${6:-8192};  GMU=${7:-}; MNBT=${8:-0} ;;
  perf)             NS=${5:-8};  CTX=${6:-8192};  GMU=${7:-}; MNBT=${8:-0} ;;
  cap_batch)        NS=${5:-128};CTX=${6:-8192};  GMU=${7:-0.75}; MNBT=${8:-0} ;;
  cap_ctx)          NS=${5:-4};  CTX=${6:-16384}; GMU=${7:-0.75}; MNBT=${8:-0} ;;
  thrcap)           NS=${5:-32}; CTX=${6:-2048};  GMU=${7:-0.75}; MNBT=${8:-0} ;;
  *) echo "bad phase"; exit 9 ;;
esac
OSD=/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD
RAW=/home/n00928095/OSCAR_PARALLEL_WORK/R172_INTEGRATION_PRODUCT_WIN/RAW
RC5=/home/n00928095/OSCAR_PARALLEL_WORK/R172_INTEGRATION_PRODUCT_WIN/TASK_OWNED/RC/rc5
RP=$OSD/acceptance/report_eval
OV=$OSD/acceptance/runs/prv3/ov_restore
VEND=/home/n00928095/OSCAR_PARALLEL_WORK/R173_INT2_UNPACK_EXECUTION_UNIT_MIGRATION/TASK_OWNED/local_opp/vendors/oscar_b1_r218emitgrp
OUT=$RP/runs/$TAG
mkdir -p "$OUT"
export R146S=0
LEGSJSON=$(python3 -c "import json,os;d={'phase':'$PHASE','outdir':'$OUT','points':os.environ.get('R218RP_POINTS','1,8,32'),'ctx':int('${CTX:-2048}')};os.environ.get('R218RP_BATCHES') and d.update({'batches':os.environ['R218RP_BATCHES']});print(json.dumps(d,separators=(',',':')))"  )
GMUENV=""; [ -n "$GMU" ] && GMUENV="export R148_GMU=$GMU; export R116_GMU=$GMU;"
TTSENV=""; { [ "$PHASE" = cap_batch ] || [ "$PHASE" = thrcap ]; } && TTSENV="export R109_TT_MAX_SEQS=$NS;"

# host-side peak-HBM sampler for this device
HBMF=$OUT/hbm_peak.txt
( for i in $(seq 1 900); do
    npu-smi info -t usages -i "$DEV" 2>/dev/null | awk -F: '/HBM Usage Rate/ {gsub(/ /,"",$2); print strftime("%s"), $2}'
    sleep 2
  done ) >> "$OUT/hbm_samples.txt" &
SAMP=$!
trap "kill $SAMP 2>/dev/null" EXIT

RC_ENV_SH=$RC5/RC_ENV.sh RC_VENDOR="$VEND" \
R218_SERVE_CAN=$RP/r218_report_eval.py R218_MODE=$MODEARG R218_LD_MAX=0 R218_LD_RELAY=0 \
R218_EXTRA="export R218_LGP=3; export R148_OVERLAY=$OV; export R151_CANLEGS=2; \
export R157_OPP=; export R166_LEGS_JSON='$LEGSJSON'; export R164_MNBT=$MNBT; export R152_EAGER=1; export R148_MODE=$MODEARG; \
export R144_LAUNCHER_SRC=$OV/csrc/oscar/int2_op_launch_lse_fast_r152.cpp; \
export R144_LAUNCHER_NAME=int2_lse_fast_r152; export OSCAR_OPP_PATH=$VEND; \
export OSCAR_LSE_BRIDGE_SRC=$OV/csrc/oscar/int2_op_launch_lse_r98.cpp; \
export TORCH_EXTENSIONS_DIR=$OV/torch_ext; $GMUENV $TTSENV" \
  timeout ${R218RP_TO:-7200} bash $RAW/r218_lddet_rc.sh "$TAG" "$DEV" "$VEND" "$NS" 12 "$CTX" \
  > "$OUT/leg.driver.log" 2>&1
LEGRC=$?
kill $SAMP 2>/dev/null
SL=$RAW/serve/serve_${TAG}.log
cp "$SL" "$OUT/serve.log" 2>/dev/null
# peak HBM (percent) across samples
awk '$2+0>m{m=$2+0} END{print "peak_hbm_pct=" m+0}' "$OUT/hbm_samples.txt" 2>/dev/null > "$HBMF"
{
  echo "leg_rc=$LEGRC"
  grep -m1 "R218ID" "$SL" 2>/dev/null | cut -c1-220
  grep -m1 "R159K-ID" "$SL" 2>/dev/null | grep -oE "md5=[0-9a-f]+"
  grep -iE "KV cache size|Maximum concurrency|token blocks|preempt" "$SL" 2>/dev/null | head -8
  cat "$HBMF" 2>/dev/null
  tail -3 "$OUT/leg.driver.log" 2>/dev/null
} > "$OUT/gates.txt"
cat "$OUT/gates.txt"
exit $LEGRC
