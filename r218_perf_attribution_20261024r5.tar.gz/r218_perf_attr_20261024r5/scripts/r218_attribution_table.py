#!/usr/bin/env python3
"""R218 attribution ledger v2 (same-GMU 0.75: 2K/C32 and 16K/C8).

WHAT CHANGED vs the first version (2026-10-23 10:24Z):
  * every ablation row now carries baseline_wall / ablated_wall / delta_wall /
    delta_over_base, plus a phase split (decode span vs prefill+queue). The
    52.96 s figure is the DIFFERENCE; the ablated leg itself took 60.53 s.
  * NOMIDE is described uniformly as an end-to-end wall-clock difference of
    skipping middle-op execution (R201_T_NOMIDE returns before the op call).
    It is NOT called pure launch latency, a hardware lower bound, or a strict
    achievable-speed-up bound.
  * the old "unattributed 7.1% / 54.6%" rows mixed phases: they subtracted a
    whole-batch ablation delta (which also saves prefill time) from the decode
    gap. v2 subtracts per-phase deltas and reports "not covered by any measured
    gate" as a RANGE. Ablations run in the same step and can overlap, so these
    numbers are explicitly NOT a mutually exclusive 100% ledger.

Sources: runs/bg1_* (four-leg grid), bg2_*/bg3_* (2K repeats), bg4_* (2K
ablations), bg5_* (16K ablations). Timestamps/rows come from perq.json; the
decode span is the per-request first->last token delta (device clock), and
wall = (prefill+queue) + decode span.
"""
import csv
import json
import os
import statistics as st

RP = "/home/n00928095/OSCAR_PARALLEL_WORK/R218_OSD/acceptance/report_eval"
RUNS = os.path.join(RP, "runs")
FIGS = os.path.join(RP, "figs")

LEGS = {
    "bg1_int2_thrcap2k_c32": ("INT2 2K/C32 single", "INT2", 2048, 32, "baseline", True,
                              "single shot; prefill outlier (see repeats)"),
    "bg2_int2_thrcap2k_c32": ("INT2 2K/C32 repeat1", "INT2", 2048, 32, "baseline", True, ""),
    "bg3_int2_thrcap2k_c32": ("INT2 2K/C32 repeat2", "INT2", 2048, 32, "baseline", True, ""),
    "bg2_int2_thrcap2k_c32_nomide": ("INT2 2K/C32 NOMIDE", "INT2", 2048, 32, "ablation", False,
                                     "R201_T_NOMIDE=1 (diagnostic): middle-op execution skipped -> outputs wrong (0/32 hits)"),
    "bg4_int2_2k_c32_noslide2": ("INT2 2K/C32 NOSLIDE2", "INT2", 2048, 32, "ablation", True,
                                 "R194_T_NOSLIDE2=1"),
    "bg4_int2_2k_c32_nogstage": ("INT2 2K/C32 NOGSTAGE", "INT2", 2048, 32, "ablation", True,
                                 "R194_T_NOGSTAGE=1 (switch, not delete)"),
    "bg4_int2_2k_c32_nosrstage": ("INT2 2K/C32 NOSRSTAGE", "INT2", 2048, 32, "ablation", True,
                                  "R194_T_NOSRSTAGE=1"),
    "bg1_bf16_thrcap2k_c32": ("BF16 2K/C32 single", "BF16", 2048, 32, "baseline", True, ""),
    "bg4_bf16_thrcap2k_c32": ("BF16 2K/C32 repeat1", "BF16", 2048, 32, "baseline", True, ""),
    "bg1_int2_thrcap16k_c8": ("INT2 16K/C8 single", "INT2", 16384, 8, "baseline", True, ""),
    "bg2_int2_thrcap16k_c8": ("INT2 16K/C8 repeat1", "INT2", 16384, 8, "baseline", True, ""),
    "bg5_int2_16k_c8_nomide": ("INT2 16K/C8 NOMIDE", "INT2", 16384, 8, "ablation", False,
                               "R201_T_NOMIDE=1 (diagnostic): middle-op execution skipped -> outputs wrong (0/8 hits)"),
    "bg5_int2_16k_c8_noslide2": ("INT2 16K/C8 NOSLIDE2", "INT2", 16384, 8, "ablation", True,
                                 "R194_T_NOSLIDE2=1"),
    "bg1_bf16_thrcap16k_c8": ("BF16 16K/C8 single", "BF16", 16384, 8, "baseline", True, ""),
    "bg2_bf16_thrcap16k_c8": ("BF16 16K/C8 repeat1", "BF16", 16384, 8, "baseline", True, ""),
}

COLS = ["panel", "row", "kind", "mode", "ctx", "C",
        "baseline_wall_ms", "ablated_wall_ms", "delta_wall_ms", "delta_over_base",
        "delta_decode_ms", "delta_prefill_ms",
        "value_ms", "value_tok_s", "share_of_int2_wall", "hits", "metric_ok",
        "timing_scope", "evidence", "note"]

TOKENS = {2048: (2013, 64416, 2048), 16384: (16368, 130944, 512)}
SCOPE = ("batch_wall = prefill+queue + decode span; decode span = per-request "
         "first->last token (63 intervals); 64 out/req; actual in/out %s/%s")


def load(tag):
    f = os.path.join(RUNS, tag, "perq.json")
    if not os.path.exists(f):
        return None
    d = json.load(open(f))
    s = [r for r in d["rows"] if r.get("sub") == "thrcap_summary"][0]
    return dict(wall=s["batch_wall_ms"], tok_s=s["tok_per_s"], hits=s["hits"],
                C=s["C"], span=s.get("span_med_ms"))


def median(xs):
    return st.median(xs)


def main():
    data = {}
    for tag, meta in LEGS.items():
        L = load(tag)
        if L:
            data[tag] = (meta, L)
    raw = {}
    for t, (m, L) in data.items():
        raw[t] = dict(label=m[0], mode=m[1], ctx=m[2], C=m[3], kind=m[4],
                      metric_ok=m[5], note=m[6], **{k: v for k, v in L.items() if k != "C"})
    json.dump(raw, open(os.path.join(FIGS, "bg_legs_raw.json"), "w"), indent=1)

    rows = []

    def add(panel, row, kind, mode, ctx, C, *, base=None, abl=None, dw=None,
            dbase=None, ddec=None, dpre=None, ms=None, tps=None, share=None,
            hits="", ok=True, scope="", ev="", note=""):
        rows.append(dict(
            panel=panel, row=row, kind=kind, mode=mode, ctx=ctx, C=C,
            baseline_wall_ms="" if base is None else round(base, 1),
            ablated_wall_ms="" if abl is None else round(abl, 1),
            delta_wall_ms="" if dw is None else round(dw, 1),
            delta_over_base="" if dbase is None else "%.1f%%" % (100 * dbase),
            delta_decode_ms="" if ddec is None else round(ddec, 1),
            delta_prefill_ms="" if dpre is None else round(dpre, 1),
            value_ms="" if ms is None else round(ms, 1),
            value_tok_s="" if tps is None else round(tps, 2),
            share_of_int2_wall="" if share is None else "%.1f%%" % (100 * share),
            hits=hits, metric_ok=ok, timing_scope=scope, evidence=ev, note=note))

    for ctx, panel in ((2048, "A75"), (16384, "B75")):
        i_base = [t for t, (m, L) in data.items()
                  if m[1] == "INT2" and m[2] == ctx and m[4] == "baseline"]
        b_base = [t for t, (m, L) in data.items()
                  if m[1] == "BF16" and m[2] == ctx and m[4] == "baseline"]
        iw = median([data[t][1]["wall"] for t in i_base])
        bw = median([data[t][1]["wall"] for t in b_base])
        isp = median([data[t][1]["span"] for t in i_base])
        bsp = median([data[t][1]["span"] for t in b_base])
        iC = data[i_base[0]][1]["C"]
        pin, nin, nout = TOKENS[ctx]
        scope = SCOPE % (nin, nout)

        def tps(ms):
            return nout / (ms / 1000.0)

        add(panel, "INT2 wall (median of %d)" % len(i_base), "measured", "INT2", ctx, iC,
            ms=iw, tps=tps(iw), share=1.0, scope=scope,
            ev="runs/{%s}" % ",".join(i_base),
            note="range %.0f-%.0f ms across repeats" % (
                min(data[t][1]["wall"] for t in i_base),
                max(data[t][1]["wall"] for t in i_base)))
        add(panel, "BF16 wall (median of %d)" % len(b_base), "measured", "BF16", ctx, iC,
            ms=bw, tps=tps(bw), scope=scope,
            ev="runs/{%s}" % ",".join(b_base), note="")
        add(panel, "INT2 prefill+queue", "derived", "INT2", ctx, iC,
            ms=iw - isp, share=(iw - isp) / iw, scope=scope, ev="wall - decode span",
            note="span=%.0f ms" % isp)
        add(panel, "INT2 decode", "derived", "INT2", ctx, iC, ms=isp,
            share=isp / iw, scope=scope, ev="decode span",
            note="%.0f ms/token at C=%d" % (isp / 63.0, iC))
        add(panel, "BF16 prefill+queue", "derived", "BF16", ctx, iC,
            ms=bw - bsp, share=(bw - bsp) / iw, scope=scope, ev="wall - decode span",
            note="span=%.0f ms" % bsp)
        add(panel, "BF16 decode", "derived", "BF16", ctx, iC, ms=bsp,
            share=bsp / iw, scope=scope, ev="decode span",
            note="%.0f ms/token at C=%d" % (bsp / 63.0, iC))
        add(panel, "gap: INT2 - BF16 (total)", "derived", "-", ctx, iC, ms=iw - bw,
            scope=scope, ev="median walls",
            note="BF16/INT2 output-token throughput ratio %.2fx (BF16 %.2f vs INT2 %.2f tok/s)"
                 % (tps(bw) / tps(iw), tps(bw), tps(iw)))
        add(panel, "  gap in prefill+queue", "derived", "-", ctx, iC,
            ms=(iw - isp) - (bw - bsp), scope=scope, ev="", note="")
        add(panel, "  gap in decode", "derived", "-", ctx, iC,
            ms=isp - bsp, scope=scope, ev="", note="")

        abls = [(t, m, L) for t, (m, L) in data.items()
                if m[2] == ctx and m[4] == "ablation"]
        for t, m, L in sorted(abls, key=lambda kv: kv[2]["wall"]):
            comp = m[0].split()[-1]
            part = "NOMIDE diagnostic" if comp == "NOMIDE" else comp
            add(panel, "ablation %s" % part, "ablation", "INT2", ctx, iC,
                base=iw, abl=L["wall"], dw=iw - L["wall"], dbase=(iw - L["wall"]) / iw,
                ddec=isp - L["span"],
                dpre=(iw - isp) - (L["wall"] - L["span"]),
                hits="%d/%d" % (L["hits"], iC), ok=m[5], scope=scope,
                ev="runs/%s" % t,
                note=("delta_wall is baseline minus ablated wall (NOT the ablated leg total); "
                      "%s; %s" % (
                          "end-to-end wall difference of skipping middle-op execution - not pure "
                          "launch latency, not a speed-up bound, outputs wrong (diagnostic limitation)"
                          if comp == "NOMIDE" else "single-knob ablation", m[6])))

        # ---- phase-consistent coverage accounting (face value, not a partition) ----
        dec_pos = sum(max(0.0, isp - L["span"]) for _, _, L in abls)
        dec_sig = sum(isp - L["span"] for _, _, L in abls)
        pre_pos = sum(max(0.0, (iw - isp) - (L["wall"] - L["span"])) for _, _, L in abls)
        pre_sig = sum((iw - isp) - (L["wall"] - L["span"]) for _, _, L in abls)
        dgap = isp - bsp
        pgap = (iw - isp) - (bw - bsp)
        add(panel, "sum of single-knob wall deltas (signed)", "derived", "INT2", ctx, iC,
            ms=sum(iw - L["wall"] for _, _, L in abls),
            share=sum(iw - L["wall"] for _, _, L in abls) / iw, ok=False, scope=scope,
            ev="sum over all ablation legs",
            note="bookkeeping only: the knobs run in the same step and can overlap; "
                 "this is not a mutually exclusive component sum and is not added to the gaps to make 100%")
        add(panel, "decode gap not covered by measured gates", "derived", "INT2", ctx, iC,
            ms=dgap - dec_pos, share=(dgap - dec_pos) / iw, scope=scope,
            ev="decode gap minus per-phase positive deltas",
            note="range %.1f-%.1f s (%.0f-%.0f ms/step); low end credits every positive "
                 "gate at face value, high end uses signed deltas -> NOT a 100%% ledger"
                 % ((dgap - dec_pos) / 1000.0, (dgap - dec_sig) / 1000.0,
                    (dgap - dec_pos) / 63.0, (dgap - dec_sig) / 63.0))
        add(panel, "prefill+queue gap not covered by measured gates", "derived", "INT2", ctx, iC,
            ms=pgap - pre_pos, share=(pgap - pre_pos) / iw, scope=scope,
            ev="prefill gap minus per-phase positive deltas",
            note="range %.1f-%.1f s (face value to signed)" % ((pgap - pre_pos) / 1000.0,
                                                               (pgap - pre_sig) / 1000.0))
        add(panel, "TOTAL gap not covered by measured gates", "derived", "INT2", ctx, iC,
            ms=(dgap - dec_pos) + (pgap - pre_pos),
            share=((dgap - dec_pos) + (pgap - pre_pos)) / iw, scope=scope,
            ev="decode + prefill remainders",
            note="%.0f%%-%.0f%% of the total gap; no claim that the remainder is a single cause"
                 % (100 * ((dgap - dec_pos) + (pgap - pre_pos)) / (iw - bw),
                    100 * ((dgap - dec_sig) + (pgap - pre_sig)) / (iw - bw)))

    with open(os.path.join(FIGS, "INT2_vs_BF16_attribution.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print("wrote figs/INT2_vs_BF16_attribution.csv (%d rows)" % len(rows))
    for r in rows:
        print("%-5s %-52s %10s %8s %8s %s" % (
            r["panel"], r["row"], r["delta_wall_ms"], r["value_ms"],
            r["share_of_int2_wall"], r["note"][:50]))


if __name__ == "__main__":
    main()
