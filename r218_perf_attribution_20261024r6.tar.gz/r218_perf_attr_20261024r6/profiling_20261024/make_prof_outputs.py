#!/usr/bin/env python3
# R218 sub-B wave-4 (2026-10-24 late): REBUILT to fix the wave-3 mixed-
# measurement presentation. The r5 version of this script computed
#   gap = median(step wall, profiler OFF) - (kernel interval union, profiler ON)/12
# and called it "host/launch gap" — a cross-measurement-condition mixture
# that is NOT a step composition. Per adjudication it is deprecated.
#
# v2 presents three SEPARATE measurement classes, never mixed:
#   profiler_off_wall    host wall of the execute_model call, profiler OFF
#                        (distribution + median, n stated; per B2 this is NOT
#                        a device-completion-inclusive step time)
#   profiler_on_sample   observations taken under torch_npu profiler ON
#                        (12 profiled steps): ON step wall, 12-step window
#                        span, kernel interval union, device idle in window,
#                        op-level kernel table (pct of kernel total only)
#   overhead             profiler observation cost: median(ON)-median(OFF),
#                        in-leg contrast
#   derived_deprecated   the retired r5 mixed quantities, kept for trace-
#                        ability ONLY (flagged, never to be quoted as data)
# Outputs: figs/PERF_PROFILING_20261024.csv, figs/PERF_PROFILING_STEP_20261024.png
#          analysis/step_decomp.json (v2 schema)
# Pure host-side; matplotlib Agg. Palette: categorical slots 1-2
# (#2a78d6, #eb6834), validated (dataviz skill validator, light mode).
import json, csv, os, statistics

BASE = os.path.dirname(os.path.abspath(__file__))
RP = os.path.join(BASE, "..", "runs")
FIGS = os.path.join(BASE, "..", "figs")
AN = os.path.join(BASE, "analysis")

MODES = (("INT2", "bg6_prof_int2_2k_c32", "bg6_prof_int2"),
         ("BF16", "bg6_prof_bf16_2k_c32", "bg6_prof_bf16"))


def stepstats(tag):
    unprof, prof = [], []
    for line in open(os.path.join(RP, tag, "prof_steps.jsonl")):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if r.get("tot") == 32 and isinstance(r.get("ms"), (int, float)):
            (prof if r.get("p") else unprof).append(r["ms"])
    return unprof, prof


def q(v, p):
    s = sorted(v)
    i = (len(s) - 1) * p
    lo = int(i)
    hi = min(lo + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (i - lo)


rows = []
S = {}
for mode, tag, pref in MODES:
    s = json.load(open(os.path.join(AN, pref + "_summary.json")))
    w = json.load(open(os.path.join(AN, ("int2" if mode == "INT2" else "bf16")
                                      + "_window_check.json")))
    unprof, prof = stepstats(tag)
    med_off = statistics.median(unprof)
    med_on = statistics.median(prof)
    wps = w["window_span_ms"] / s["nsteps"]
    S[mode] = dict(med_off=med_off, med_on=med_on, n_un=len(unprof),
                   n_pr=len(prof), probe=s["probe_overhead_ms"], s=s, w=w,
                   wps=wps,
                   idle_ps=w["device_idle_ms_in_window"] / s["nsteps"])

    # ---- class 1: profiler-OFF wall (execute_model host wall only) ----
    rows.append(dict(measurement_condition="profiler_off_wall", mode=mode,
                     level="step",
                     item="execute_model host wall, profiler OFF (tot==32 decode steps)",
                     count=len(unprof), statistic="min", ms=round(min(unprof), 2),
                     note="B2: does not provably cover device completion", evidence="prof_steps.jsonl"))
    rows.append(dict(measurement_condition="profiler_off_wall", mode=mode,
                     level="step", item="execute_model host wall, profiler OFF",
                     count=len(unprof), statistic="p25", ms=round(q(unprof, .25), 2), note="", evidence="prof_steps.jsonl"))
    rows.append(dict(measurement_condition="profiler_off_wall", mode=mode,
                     level="step", item="execute_model host wall, profiler OFF",
                     count=len(unprof), statistic="median", ms=round(med_off, 2), note="", evidence="prof_steps.jsonl"))
    rows.append(dict(measurement_condition="profiler_off_wall", mode=mode,
                     level="step", item="execute_model host wall, profiler OFF",
                     count=len(unprof), statistic="p75", ms=round(q(unprof, .75), 2), note="", evidence="prof_steps.jsonl"))
    rows.append(dict(measurement_condition="profiler_off_wall", mode=mode,
                     level="step", item="execute_model host wall, profiler OFF",
                     count=len(unprof), statistic="max", ms=round(max(unprof), 2), note="", evidence="prof_steps.jsonl"))

    # ---- class 2: profiler-ON sample ----
    rows.append(dict(measurement_condition="profiler_on_sample", mode=mode,
                     level="step",
                     item="execute_model host wall, profiler ON (same wrapper)",
                     count=len(prof), statistic="median",
                     ms=round(med_on, 2), note="probe active; not a throughput figure",
                     evidence="prof_steps.jsonl"))
    rows.append(dict(measurement_condition="profiler_on_sample", mode=mode,
                     level="window",
                     item="12-step window span (first kernel start -> last kernel end)",
                     count=s["nsteps"], statistic="window/12",
                     ms=round(wps, 2),
                     note="window includes inter-call segments (sample_tokens/scheduler)",
                     evidence="chrome trace timeline"))
    rows.append(dict(measurement_condition="profiler_on_sample", mode=mode,
                     level="window", item="NPU kernel interval union, all streams",
                     count=s["kernel_events"], statistic="window_union/12",
                     ms=round(s["kernel_union_per_step_ms"], 2),
                     note="mean over 12 profiled steps, not per-step median",
                     evidence="chrome trace interval union"))
    rows.append(dict(measurement_condition="profiler_on_sample", mode=mode,
                     level="window",
                     item="device idle inside 12-step window (window span - kernel union)",
                     count=s["nsteps"], statistic="window/12",
                     ms=round(S[mode]["idle_ps"], 2),
                     note="device busy %.1f%% of window (ON condition)" % w["device_busy_pct_of_window"],
                     evidence="chrome trace timeline minus interval union"))
    # op-level table, percentages of kernel total only (same condition)
    with open(os.path.join(AN, pref + "_ops.csv")) as f:
        for r in csv.DictReader(f):
            rows.append(dict(measurement_condition="profiler_on_sample", mode=mode,
                             level="op", item=r["op"], count=int(r["count"]),
                             statistic="total/12",
                             ms=round(float(r["npu_ms_per_step"]), 3),
                             note="pct_of_npu_kernel_total=%s" % r["pct_of_npu_kernel_total"],
                             evidence="chrome trace (profiler ON), category=%s" % r["category"]))
    with open(os.path.join(AN, pref + "_categories.csv")) as f:
        for r in csv.DictReader(f):
            rows.append(dict(measurement_condition="profiler_on_sample", mode=mode,
                             level="category", item=r["category"], count=int(r["count"]),
                             statistic="total/12",
                             ms=round(float(r["npu_ms_per_step"]), 3),
                             note="pct_of_npu_kernel_total=%s" % r["pct_of_npu_kernel_total"],
                             evidence="sum of named kernels, name->category heuristic"))

    # ---- class 3: observation overhead ----
    rows.append(dict(measurement_condition="overhead", mode=mode, level="step",
                     item="profiler observation cost = median(ON) - median(OFF)",
                     count=len(prof), statistic="median diff",
                     ms=s["probe_overhead_ms"],
                     note="+%.1f%% of OFF median" % (100 * s["probe_overhead_ms"] / med_off),
                     evidence="prof_steps.jsonl in-leg contrast (same leg, same hook)"))

# ---- deprecated r5 mixed quantities (kept for traceability ONLY) ----
gi = S["INT2"]["med_off"] - S["INT2"]["s"]["kernel_union_per_step_ms"]
gb = S["BF16"]["med_off"] - S["BF16"]["s"]["kernel_union_per_step_ms"]
dk = S["INT2"]["s"]["kernel_union_per_step_ms"] - S["BF16"]["s"]["kernel_union_per_step_ms"]
dw = S["INT2"]["med_off"] - S["BF16"]["med_off"]
for mode, g in (("INT2", gi), ("BF16", gb)):
    rows.append(dict(measurement_condition="derived_deprecated", mode=mode,
                     level="step",
                     item="r5 'host/launch gap' = median(wall, profiler OFF) - kernel_union(profiler ON)/12",
                     count=None, statistic="cross-condition difference",
                     ms=round(g, 2),
                     note="DEPRECATED r5 mixed quantity; NOT a step composition; superseded by profiler_on_sample window rows",
                     evidence="superseded 2026-10-24 wave-4; old file figs/_backup_20261024r5/"))
rows.append(dict(measurement_condition="derived_deprecated", mode="INT2-BF16",
                 level="step",
                 item="r5 claim 'step delta = delta-kernel 237.4 + delta-host-gap 239.9, roughly half each'",
                 count=None, statistic="cross-condition split",
                 ms=round(dw, 2),
                 note="DEPRECATED: mixes OFF wall delta (%.2f) with ON kernel delta (%.2f); no valid same-condition decomposition exists in current data" % (dw, dk),
                 evidence="superseded 2026-10-24 wave-4"))

os.makedirs(FIGS, exist_ok=True)
out_csv = os.path.join(FIGS, "PERF_PROFILING_20261024.csv")
with open(out_csv, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["measurement_condition", "mode", "level",
                                      "item", "count", "statistic", "ms",
                                      "note", "evidence"])
    w.writeheader()
    for r in rows:
        w.writerow(r)
print("csv rows:", len(rows), "->", out_csv)

json.dump({"supersedes": "r5 step_decomp (wall/busy/gap mixture)",
           "profiler_off_wall": {m: {"n": S[m]["n_un"],
                                     "median_ms": round(S[m]["med_off"], 2),
                                     "min_ms": None} for m, _, _ in MODES},
           "profiler_on_sample": {m: {"n": S[m]["n_pr"],
                                      "step_wall_median_ms": round(S[m]["med_on"], 2),
                                      "window_per_step_ms": round(S[m]["wps"], 2),
                                      "kernel_union_per_step_ms": S[m]["s"]["kernel_union_per_step_ms"],
                                      "device_idle_per_step_ms": round(S[m]["idle_ps"], 2),
                                      "device_busy_pct_of_window": S[m]["w"]["device_busy_pct_of_window"]}
                                 for m, _, _ in MODES},
           "overhead_ms": {m: S[m]["probe"] for m, _, _ in MODES},
           "derived_deprecated": {"r5_host_gap_mixture_ms": {"INT2": round(gi, 2), "BF16": round(gb, 2)},
                                  "r5_half_half_claim": "retracted 2026-10-24 wave-4"}},
          open(os.path.join(AN, "step_decomp.json"), "w"), indent=1)
print("step_decomp.json (v2) written")

# ---- chart: three measurement conditions, faceted; NO stacked composition ----
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

C_INT2, C_BF16 = "#2a78d6", "#eb6834"      # categorical slots 1-2 (validated)
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e8e8e6"
SURF = "#fcfcfb"

fig, axes = plt.subplots(1, 3, figsize=(11.6, 3.6), dpi=200,
                         gridspec_kw={"width_ratios": [1, 1.25, 0.8]})
fig.patch.set_facecolor(SURF)
labels = ["INT2", "BF16"]
colors = [C_INT2, C_BF16]


def style(ax):
    ax.set_facecolor(SURF)
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.yaxis.grid(True, color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


# panel 1: profiler OFF — execute_model host wall, distribution
ax = axes[0]
for i, (m, tag, _) in enumerate(MODES):
    un, _ = stepstats(tag)
    med = statistics.median(un)
    ax.bar(i, med, width=0.55, color=colors[i], edgecolor=SURF, linewidth=1.4)
    ax.errorbar(i, med, yerr=[[med - q(un, .25)], [q(un, .75) - med]],
                fmt="none", ecolor=INK2, elinewidth=1.2, capsize=4)
    ax.text(i, q(un, .75) + 12, "median %.1f\n[p25 %.0f – p75 %.0f] n=%d"
            % (med, q(un, .25), q(un, .75), len(un)),
            ha="center", va="bottom", fontsize=7.5, color=INK)
ax.set_xticks([0, 1]); ax.set_xticklabels(labels, fontsize=9, color=INK)
ax.set_ylim(0, 700)
ax.set_title("A. profiler OFF — execute_model host wall per decode step\n(43 steps/leg; NOT device-completion-inclusive)",
             fontsize=8.5, color=INK, loc="left")
ax.set_ylabel("ms / step", fontsize=8.5, color=INK2)
style(ax)
axes[0].annotate("same-condition delta INT2−BF16 = +%.1f ms" % (S["INT2"]["med_off"] - S["BF16"]["med_off"]),
                 xy=(0.5, 0.965), xycoords="axes fraction", ha="center",
                 fontsize=7.5, color=INK2)

# panel 2: profiler ON — wall vs kernel union in the same (ON) condition
ax = axes[1]
xs = [0, 1, 2.6, 3.6]
vals = [S["INT2"]["med_on"], S["INT2"]["s"]["kernel_union_per_step_ms"],
        S["BF16"]["med_on"], S["BF16"]["s"]["kernel_union_per_step_ms"]]
names = ["step wall\n(median, n=12)", "kernel union\n(window/12)",
         "step wall\n(median, n=12)", "kernel union\n(window/12)"]
for x, v, m_i in zip(xs, vals, [0, 0, 1, 1]):
    ax.bar(x, v, width=0.62, color=colors[m_i], edgecolor=SURF, linewidth=1.4)
    ax.text(x, v + 12, "%.1f" % v, ha="center", va="bottom", fontsize=8,
            color=INK, fontweight="bold")
# window span marker (ON condition): tick showing full window extent
for x0, m_i in ((0.5, 0), (3.1, 1)):
    ax.plot([x0 - 0.31, x0 + 0.31], [S[labels[m_i]]["wps"]] * 2,
            color=INK2, linewidth=1.4)
    ax.text(x0 + 0.36, S[labels[m_i]]["wps"], "window/step %.0f" % S[labels[m_i]]["wps"],
            fontsize=7, color=INK2, va="center")
ax.set_xticks(xs); ax.set_xticklabels(names, fontsize=7, color=INK2)
ax.set_ylim(0, 880)
ax.set_title("B. profiler ON — same-condition observations (12 profiled steps)\ndevice busy: INT2 34.7% / BF16 25.2% of window",
             fontsize=8.5, color=INK, loc="left")
style(ax)

# panel 3: observation overhead (ON - OFF, in-leg contrast)
ax = axes[2]
for i, m in enumerate(labels):
    v = S[m]["probe"]
    ax.bar(i, v, width=0.5, color=colors[i], edgecolor=SURF, linewidth=1.4)
    ax.text(i, v + 5, "+%.1f ms\n(+%.1f%% of OFF median)" % (v, 100 * v / S[m]["med_off"]),
            ha="center", va="bottom", fontsize=7.5, color=INK)
ax.set_xticks([0, 1]); ax.set_xticklabels(labels, fontsize=9, color=INK)
ax.set_ylim(0, 260)
ax.set_title("C. profiler observation cost\n(median ON − median OFF, same leg)",
             fontsize=8.5, color=INK, loc="left")
style(ax)

fig.suptitle("R218 2K/C32 pure-decode step — three measurement conditions, never mixed (bg6 legs, 2026-10-24; wave-4 correction of r5 stacked chart)",
             fontsize=9.5, color=INK, x=0.01, ha="left")
fig.text(0.01, -0.04,
         "Panels come from different measurement conditions: A (profiler OFF) and B (profiler ON) must not be subtracted or stacked into a step composition. "
         "B shows wall and kernel union separately; window device-idle (65.3% INT2 / 74.8% BF16) is an ON-condition observation including probe cost. "
         "The r5 'host gap 300.7/60.8 ms' and 'half kernel / half host' claims are retracted (see PERF_ATTRIBUTION_ADDENDUM_20261024.md §10.5).",
         fontsize=6.8, color=INK2, ha="left", va="top", wrap=True)
fig.tight_layout(rect=[0, 0.02, 1, 0.93])
png = os.path.join(FIGS, "PERF_PROFILING_STEP_20261024.png")
fig.savefig(png, bbox_inches="tight", facecolor=SURF)
print("png ->", png)
