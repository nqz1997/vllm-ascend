# PERF_PROFILING_20261024 新旧对照（r5 → r6；第 4 波 sub-B，2026-10-24 深夜）

> 缺陷根因：r5 的 `profiling_20261024/make_prof_outputs.py`（旧行 :34/:35/:51/:152）把
> **profiler-OFF 步墙钟**（prof_steps.jsonl 中位）与 **profiler-ON kernel 区间并集**
> （chrome trace/12 步）相减并命名为 "host/launch gap"。探针开销 +197.67/+21.24 ms/步
> 本身就是两条件的差，因此该残差是**跨测量条件混合量**，不是步构成。r6 起按测量条件
> 三分类（profiler_off_wall / profiler_on_sample / overhead），混合量仅存于
> `derived_deprecated` 行。更正全文见 `PERF_ATTRIBUTION_ADDENDUM_20261024.md` §10.5。

## 数值级取代关系

| 旧量（r5，已废弃） | 数值 | 处置 | 取代它的量（r6） | 数值 |
|---|---:|---|---|---|
| INT2 "host/launch gap"（墙钟−kernel 并集） | 300.66 ms/步 | 撤回为直接测量 | ①OFF execute_model 墙钟中位 567.05（n=43，[563.17–571.55]）；②ON 窗口设备空闲/步 502.12（65.3% 空闲，含探针）；③探针开销 +197.67 | 见左 |
| BF16 "host/launch gap" | 60.79 ms/步 | 同上 | ①OFF 墙钟中位 89.74（n=43，[88.86–91.12]）；②ON 窗口设备空闲/步 85.81（74.8% 空闲）；③探针开销 +21.24 | 见左 |
| "步差≈Δkernel 237.4＋Δhost 239.9，各半" | 477.31 | 撤回 | 同条件分列：Δwall(OFF)=+477.31（n=43/43）；Δkernel(ON)=+237.44；Δwindow(ON)=+653.75。任何"kernel+host=步"的分解不存在于现有数据 | 见左 |
| "NOMIDE 只省 13 ms/步＝host 遮蔽" | — | 撤回归因 | 保留事实：NOMIDE 差分 24.25 ms/步（§4.1.3）与中层核 ON 条件 209.25 ms/步 并存，关系未解释（OPEN） | — |
| "host 间隙 INT2 300.7 vs BF16 60.8 ⇒ host 成本随 ctx 变化（证伪 §4.2.4）" | — | 撤回推理 | 无取代量；问题回 OPEN（同 ctx 双模式 host 链路不同，不构成对 ctx 标度的证据） | — |
| "服务内 5.81 ms＝直调 0.456 ms 的 12.7×" | 12.7× | 降级 | 观测比（两场景，条件对照见 §10.5）：服务内 n=432 次 5.78–5.85 ms（ON trace）vs 直调 0.456 ms（B=32/S=1920/合成块表 15/sync-per-call，无 profiler）。成因未查 | — |
| 堆叠图"步＝注意力核+其他核+host gap" | — | 撤回图形 | 三面板分列图（A OFF 墙钟分布/B ON 条件墙钟与 kernel 并集并列/观测开销），无任何"步构成"堆叠 | — |

## 保留不变的量（r5→r6 未动）

- profiler-OFF execute_model 墙钟分布（两模式 n=43，min/p25/中位/p75/max）；
- profiler-ON kernel 并集与逐 op 表（kernel union 266.39/28.95；op 行自 r6 起只报
  pct_of_npu_kernel_total，不再报对 OFF 墙钟的跨条件百分比）；
- 探针开销 +197.67/+21.24 ms/步（同腿前后对照）；
- bg6 腿身份/门（[R218ID] sha 85051bbd2e74c117、内核 md5 c8a8d47a63be7ad7、32/32 命中）。

## 文件级取代关系

| 文件 | r5 状态 | r6 状态 |
|---|---|---|
| `figs/PERF_PROFILING_20261024.csv` | 78 行，"host/launch gap" 行 + op 行含跨条件 pct | 93 行三分类（measurement_condition 列）；旧文件逐字节备份 `figs/_backup_20261024r5/PERF_PROFILING_20261024.r5_78rows.csv`（也在只读 r5 证据包内） |
| `figs/PERF_PROFILING_STEP_20261024.png` | 堆叠条形图（步构成） | 三面板分列图；旧图备份 `...r5_stacked.png` |
| `profiling_20261024/analysis/step_decomp.json` | wall/busy/gap 混合 | v2 结构（supersedes 字段指向 r5；deprecated 子对象保留旧数值）；旧文件备份 `figs/_backup_20261024r5/step_decomp.r5.json` |
| `profiling_20261024/make_prof_outputs.py` | 混合量生成逻辑 | 重写为三分类（文件头注明缺陷与裁定） |
| `PERF_ATTRIBUTION_ADDENDUM_20261024.md` §10 | §10.2–10.4 含混合表述 | 原文保留＋警示指针＋新增 §10.5 更正小节 |
| 新增 `analysis/{int2,bf16}_window_check.json` | — | 12 步窗口跨度/并集/空闲、kernel 尾越出最后 cpu_op 2.44/1.02 ms（B2 佐证） |

## execute_model 计时核查（B2，结论）

计时只包 `NPUModelRunner.execute_model`；该 fork 常规路径发射 forward 后 `return None`，
采样与 D2H 同步在 `sample_tokens`/`_bookkeeping_sync`（窗口外）⇒ **"ms"＝EngineCore 内
execute_model 调用的 host 墙钟，不保证覆盖本步设备完成**；是否含对前序设备工作的隐式
等待**离线不可判定**。证据形态与全文见 ADDENDUM §10.5。
