# main 服务验证记录（2026-10-24，NPU 7）

对象：`nqz1997/vllm-ascend` 分支 `oscar-int2/m-port-full-ut`（main 基 `dde85f6b8`）。
本文件只记录 **main 移植版** 的服务级验证；不引用交付树（release 基）的精度/性能数字。

## 1. 环境（上游验证组合，宿主未改动）

| 项 | 值 |
|---|---|
| 镜像 | `swr.cn-north-12.myhuaweicloud.com/atlas_inference/vllm-ascend:nightly-ci-main-a2-openeuler` |
| 镜像 digest | `sha256:8eaf0b4fd652097a6db123bda845abdaf6d1f3c3e3c68429b470f677c5920f8b`（image id `b08f059e942e`） |
| CANN | 9.2.0（镜像自带 `/usr/local/Ascend/cann-9.2.0`） |
| torch / torch_npu | 2.10.0+cpu / 2.10.0.post7 |
| vLLM | 0.31.0，源码 `/vllm-workspace/vllm` @ `db9527a4`（tag `v0.31.0`） |
| Python | 3.12.13 |
| 容器 | `r218-main-verify`：`--privileged`，`-v /usr/local/Ascend/driver:ro`、`-v /usr/local/dcmi:ro`、`-v /home`、`-v <worktree>:/workspace/oscar-vllm-ascend`；`ASCEND_RT_VISIBLE_DEVICES=7` |
| 设备 | NPU 7：启动前核实无进程（`npu-smi` 空）；未触碰其他用户负载 |
| 宿主 | 未修改驱动、系统 OPP、CANN；未伪造宏、未删除版本校验 |

## 2. 构建与 import

- `pip install -e . --no-build-isolation --no-deps` → **EXIT 0**；
  产物 `vllm_ascend_C.cpython-312-aarch64-linux-gnu.so`（torch 2.10.0 + CANN 9.2 编成）。
- `import vllm` 触发 vllm_ascend 平台插件加载成功；`vllm_ascend.attention.int2.ctx`
  `__all__` 46 项（import 适配后的期望值）。
- 隔离 UT（host venv_main，CPU）：`pytest --noconftest tests/ut/oscar/test_int2_*.py`
  → **15 文件 / 98 passed**；6 文件运行时适配提交 `18d56c698` 后复跑仍 **98 passed**。
  口径：这是隔离 UT，不等于全仓测试。

## 3. BF16 冒烟（同镜像、同容器、同参数）

命令：`vllm serve Qwen3-8B --max-model-len 2048 --max-num-seqs 32 --gpu-memory-utilization 0.60
--trust-remote-code --enforce-eager`（默认 BF16 KV）。

- 启动成功；`NPU KV cache size: 153,216 tokens`，`Maximum concurrency ... 74.81x`。
- greedy `"The capital of France is"` → `" Paris. The capital of Italy is Rome. The capital of Germany is Berlin."`

## 4. INT2 服务

启动脚本：`R218_UPSTREAM_WORK/verify_scripts/serve_int2.sh`（+ `canonical_env.sh`）。
姿态与交付线生产口径一致：

- vendor 链 `oscar_r144_v133c_grp : oscar_r133_v1 : custom_opp_r116v2 : oscar_r106_candidate`；
  候选内核 `.o` md5 **`c8a8d47a63be7ad79abce43de005f238`**（= 交付冻结门）。
- 运行时扩展：`[R112-FAST] Extension loaded: r113.orch.v9+r145v3`（launcher
  `int2_op_launch_lse_fast_r152.cpp`，与交付树逐字节同）＋ `[R108-LSE] r98.lse.v1`。
- 源码身份横幅：`[R218ID] file=.../attention_v1.py sha=704cf4e0c3a7fa5a`。
- `NPU KV cache size: 306,560 tokens`；同 `gpu-memory-utilization=0.60` 下为 BF16 的
  **2.00×**（容量观察，非验收指标）。

### 4.1 功能回归（`ASCEND_LAUNCH_BLOCKING=1`，串行化发射）

| 场景 | 结果 |
|---|---|
| 单请求（5 tok，无 middle） | PASS：`" Paris. The capital of Italy is Rome. The capital of Germany is Berlin."` |
| 批量 2/3/4/8（同一短提示） | PASS |
| ragged：6 / 121 / 1001 / 1601 tok 同批 | PASS |
| 短 middle 带：1601 tok（middle ≈ 577 tok） | PASS |
| 批量长上下文：2×1601、4×1601、短+长混合 | PASS |
| 长度截止（`finish_reason="length"`） | PASS |
| 前缀复用：1601 tok 同请求连发两次 | PASS（两次输出逐字相同；日志 `Prefix cache hit rate: 85.7%`） |
| 全量电池（17 种请求形态） | **17/17 无损坏** |
| 中段重负载电池 6×4 请求 | **24/24 无损坏** |
| 合计（BLOCKING=1） | **41/41 无损坏** |

### 4.2 已知缺陷：异步发射下的间歇空注意力（环境级）

同一电池在 `ASCEND_LAUNCH_BLOCKING=0`（默认异步发射）下：**18/24 请求出现损坏输出**
（表现为 `!!!!!!` 类退化文本，按请求随机落行）；`=1` 下 **0/24**（全量电池另 17/17）。
另在异步模式下观察到一次冷启动形态：短请求（5 tok）之后的首个 middle 请求（1601 tok）
单行损坏，下一次同请求即自愈。该签名与 2026-10-20 A1 判定一致（当时 0/50 vs 7/49）：
**CANN aclnn 发射层竞态**，不是 INT2 算子算术错误。本次未在 main 树内修复该环境竞态；
生产化需等待 CANN 侧修复，或以串行化/同步发射作为临时手段（牺牲并发性能）。

### 4.3 运行时适配（已提交）

`oscar-int2/m-port-full-ut` @ **`18d56c698`**（在 `268b8ff16` 之上）：

| 文件 | 适配 |
|---|---|
| `patch/platform/patch_kv_cache_dtype.py` | 接受 `int2_per_token_head`；注册 packed uint8 存储 dtype |
| `worker/worker.py` | INT2 cache dtype → `torch.uint8` |
| `attention/attention_v1.py` | 去掉 release-only kvcomp/hamming 分支；INT2 豁免静态量化配方检查 |
| `attention/int2/quantcache.py` | packed KV 走 (block, offset) 索引写，适配 V2 runner 的块跨距页 |
| `attention/int2/bridge.py` | CANN 根从 `ASCEND_HOME_PATH`/`ASCEND_TOOLKIT_HOME` 解析 |
| `attention/int2/slotstate.py` | b 键 HP 池尺寸覆盖引擎最大批宽 + V2 padding 行 |

补丁导出：`R218_UPSTREAM_WORK/main_port_runtime_fixes.patch`
（sha256 `c227321dc4a7ff10d55d5daad5f9d470971c4ab8fd3a59c20cecaa29b6481da6`）。
分支已推 GitHub fork `nqz1997/vllm-ascend` `oscar-int2/m-port-full-ut` @ `18d56c698`，
远端 blob 与本地一致（`slotstate.py` blob `24ed168d…`）。

## 5. 边界与结论

- **PASS（BLOCKING=1 诊断口径）**：单请求、批量、ragged、短 middle、长度截止、前缀复用均正确；
  BF16 同环境冒烟通过；构建/import/UT 通过。
- **未通过/不可宣称**：默认异步发射下的间歇损坏（环境竞态，18/24 vs 0/24）；
  因此不能把 main 服务标为生产可用，也不能引用交付树的精度/性能数字。
- 后续工作：CANN 竞态复测（换镜像/驱动版本）、在 main 树补 warmup 前置（交付线用 R160 热修，
  main 无该 overlay）、把串行化脚注写进 launcher 说明。
