# P6 main 默认异步缺陷定位证据（2026-10-24/25，第 3+4 波）

组合：main 移植 `oscar-int2/m-port-full-ut @ 81295d899`（容器 r218-main-verify，nightly 镜像
CANN 9.2.0/torch 2.10.0/torch_npu 2.10.0.post7/vLLM 0.31.0），Qwen3-8B，NPU 7，eager，
B=1 1080 token 最小复现，REPS=12。**与冻结组合服务结果分账，本目录全部为 main 诊断。**

## 当前结论（第 4 波为准；权威记录 PR_ADVANCE_20261024.md §3.5/§3.6/§9/§10）
- 输出级：async bad 8–12/12（探针依赖）vs blocking 0/12；**轻探针 WTRACE2 不再掩盖**（11/12＝
  未探针基线；重探针 3 sync/调用会掩盖——探针同步点本身改变竞态）。
- **首事件**：rep1/step4/L30 q/kr/vr **同时**全 0x7FFF（＝f32 0x7FFFFFFF/INT32_MAX 位型截断，
  非算术 NaN）；前 5 层调用健康；**该时刻 L8 环逐字节干净 ⇒ 环读/写被排除**；污染经隐层流
  （前层 attn/mid/merge/MLP）进入 QKV。步级瞬态级联（L30-35→…→L4-35），不跨 token 边界。
- **第 3 波"跨代环残留"读法已推翻**：环尾 +80 行/rep 自 rep9 起为各自 prefill 自写
  （r09=74/r10=154/r11=234 行 [X,1023)，层间同构）；等差计数观察仍真、归因作废。
- **载体层实锤（missing-write 报成功）**：MIDCAP2 async 捕获 #2 在全量
  `torch.npu.synchronize()` 后 lse 全 −9999（`int2_op_launch_lse_fast_r152.cpp:137`
  前置哨兵 `lse.fill_(-9999)`）＋out 垃圾 3.2e36，池载体为 torch.zeros（`middle_candidate.py:95-99`）
  ——真实 missing-write 且 enqueue 报成功（launcher 返回 `(r,ws,lr,g_ws_hits)`，消费方只看 r）。
  **主 Agent 亲自重跑 `p6_compare.py --ref` 复现**：async#2 cos=0.000000、kern_lse=[−9999×3]；
  blocking#2 cos=0.999994；捕获#1 两腿同 cos=0.999927（健康时数值正确）。
- T1 三分类：有效数据损坏全在合法 recent 读集内（in=1065/2345/3625/4905，outside=0）
  → 污染进入注意力；未用槽位未捕获；合法重绑有限。
- 共享态风险（未定罪）：全局 g_ws 工作区跨全部层/调用、`_r112_opool` 池载体跨 36 层、
  kr_ptr 步内跨层复用。blocking=launch 串行化（结构差异，假设，非 CANN 归因）。
- **OPEN**：产生 0x7FFFFFFF 位型的具体写入指令未定位；无可合入最小修复。
- 表述边界：输入/输出哈希一致只是观测，不能宣称"写侧无罪"或排除算子内存副作用（本波的
  排除全部基于首事件/哨兵直接证据）。

## 目录
- `raw/p6{a,b,g,h,k,l,l2}*` —— 第 3 波（哈希流+96 环张量；p6a/b 配对 async vs blocking）。
- `raw/p6e_cap_async`、`raw/p6f_cap_blk` —— 第 4 波 MIDCAP2 实操作数捕获（**哨兵实锤证据**；
  `p6_compare.py --ref <dir>` 可独立重跑复现）。
- `raw/p6o2_w2_async` —— WTRACE2 轻探针 onset 捕获（9936 条 jsonl＋66 dump＋onset01-30.pt＋
  `analysis/wtrace2_onset_analysis.txt` 首事件分析）。
- `minimal_repro/` —— async_diag.sh、p6_compare.py（纯 torch 参考）、p6_t1_ringclass.py、
  wtrace2_patch.py（轻探针补丁）、p6*.sh 腿驱动、x1080x1_req.json。
- `leg_outputs/` —— 每腿 analysis/status/battery 原始判据。
- `SHA256SUMS` —— 全部文件校验。

生成：主 Agent 2026-10-25；不修改任何已有数值；第 3 波结论的更正按 append 原则以本 README
与 PR_ADVANCE §10 为准。
