#!/bin/bash
# Wave-4 full device window (runs INSIDE flock /tmp/r218_npu7.lock).
set -u
V=/home/n00928095/R218_UPSTREAM_WORK/verify_scripts
CT=r218-main-verify
PRISTINE=/home/n00928095/R218_UPSTREAM_WORK/oscar_port_ut_tree/vllm_ascend/attention/int2/middle_exec.py

echo "[window] $(date -Is) start: caps legs (pristine tree)"
bash "$V/p6_wave4_run.sh" caps
echo "[window] $(date -Is) applying wtrace patch"
docker cp "$V/wtrace_patch.py" "$CT:/tmp/wtrace_patch.py"
docker exec "$CT" python3 /tmp/wtrace_patch.py
docker exec "$CT" md5sum /workspace/oscar-vllm-ascend/vllm_ascend/attention/int2/middle_exec.py
echo "[window] $(date -Is) wtrace legs (patched tree)"
bash "$V/p6_wave4_run.sh" wtrace
echo "[window] $(date -Is) restoring pristine middle_exec.py"
docker cp "$PRISTINE" "$CT:/workspace/oscar-vllm-ascend/vllm_ascend/attention/int2/middle_exec.py"
docker exec "$CT" md5sum /workspace/oscar-vllm-ascend/vllm_ascend/attention/int2/middle_exec.py
for pat in 'vllm.entrypoints.cli.main' 'VLLM::EngineCore'; do
  docker exec "$CT" bash -lc "pkill -9 -f '$pat'" >/dev/null 2>&1
done
sleep 5
npu-smi info 2>/dev/null | grep -E "7     910B3|0000:42" | head -2
echo "[window] $(date -Is) done"
