#!/bin/bash
set -u
RUN=/home/n00928095/R218_UPSTREAM_WORK/verify_scripts/async_diag.sh
docker exec r218-main-verify bash -lc 'rm -rf /tmp/r218_p6/p6l_row_blk /tmp/r218_ringrows; mkdir -p /tmp/r218_ringrows; rm -f /tmp/r218_krv_diag.jsonl /tmp/r117_mid_e_diag.jsonl'
sleep 20
env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS=12 bash "$RUN" p6l_row_blk int2exp R117_MID_DIAG=1 R218_KRVDBG=1 R218_RINGROWDBG=1 ASCEND_LAUNCH_BLOCKING=1
docker exec r218-main-verify bash -lc 'mkdir -p /tmp/r218_p6/p6l_row_blk && mv /tmp/r117_mid_e_diag.jsonl /tmp/r218_krv_diag.jsonl /tmp/r218_p6/p6l_row_blk/ 2>/dev/null; mv /tmp/r218_ringrows /tmp/r218_p6/p6l_row_blk/ringrows 2>/dev/null; true'
docker cp r218-main-verify:/tmp/r218_p6/p6l_row_blk /tmp/r218_p6_host/p6l_row_blk2 >/dev/null 2>&1
find /tmp/r218_p6_host/p6l_row_blk2 -name "*.pt" | wc -l
echo BLK-RERUN-DONE
