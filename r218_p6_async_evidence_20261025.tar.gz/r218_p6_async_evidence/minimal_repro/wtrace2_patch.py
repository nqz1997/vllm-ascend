p = "/workspace/oscar-vllm-ascend/vllm_ascend/attention/int2/middle_exec.py"
s = open(p).read()

aA = '        if _os.environ.get("R147_PROBE", "0") == "1" and _r147n[0] <= 120:'
assert s.count(aA) == 1
pA = '''        # R218 WTRACE2 (DIAGNOSTIC_ONLY, default OFF; wave-4 lite): p6k-load
        # probe - per layer-call (post ring-maintenance) hashes of key_rot/
        # value_rot/query + data_ptrs; ring-row saves at each rep's first
        # captured decode step; ONSET-TRIGGERED tensor dumps (kr==vr== the
        # [1,8,128] all-0x7FFF hash) with a rolling 6-call device stash. No
        # steady-state syncs beyond the three hash reads.
        if _os.environ.get("R218_WTRACE2", "0") == "1":
            try:
                import hashlib as _hlw, json as _jw
                import torch as _tw
                def _hw2(_t):
                    return _hlw.sha256(_t.contiguous().view(_tw.uint8).cpu().numpy().tobytes()).hexdigest()[:12]
                torch.npu.synchronize()
                _lidw = int(self._oscar_layer_ord(layer))
                _stw = _R2XX_G.setdefault("_R218_W2_ST", [0])
                _stw[0] += 1
                _call = _stw[0] - 1
                _krh = _hw2(key_rot); _vrh = _hw2(value_rot); _qh = _hw2(query)
                _hkw, _hvw = self._tt_hp_bufs(_lidw, query.device, query.dtype)
                with open("/tmp/r218_wtrace.jsonl", "a") as _fw:
                    _fw.write(_jw.dumps({
                        "st": _call, "layer": _lidw,
                        "sl": [int(_x) for _x in seq_lens][:4],
                        "q": _qh, "kr": _krh, "vr": _vrh,
                        "q_ptr": int(query.data_ptr()),
                        "kr_ptr": int(key_rot.data_ptr()),
                        "vr_ptr": int(value_rot.data_ptr()),
                        "hk_ptr": int(_hkw.data_ptr())}) + "\\n")
                if (_call % 828) < 36 and _lidw in (8, 15, 16) and (_call // 828) < 12:
                    torch.save({
                        "idx": _call, "layer": _lidw,
                        "hk": _hkw[0].detach().cpu().clone(),
                        "hv": _hvw[0].detach().cpu().clone(),
                    }, "/tmp/r218_wtrace_dumps/ring_r%02d_l%02d.pt" % (_call // 828, _lidw))
                _stash = _R2XX_G.setdefault("_R218_W2_STASH", [])
                _stash.append({
                    "st": _call, "layer": _lidw,
                    "sl": [int(_x) for _x in seq_lens][:4],
                    "q": query.detach().clone(), "kr": key_rot.detach().clone(),
                    "vr": value_rot.detach().clone()})
                if len(_stash) > 6:
                    del _stash[:len(_stash) - 6]
                if _krh == _vrh == "5abbd4b74175":
                    _trig = _R2XX_G.setdefault("_R218_W2_TRIG", [0])
                    if _trig[0] < 30:
                        _trig[0] += 1
                        _rk8, _rv8 = self._tt_hp_bufs(8, query.device, query.dtype)
                        torch.save({
                            "ev": "onset", "trig": _trig[0], "layer": _lidw,
                            "sl": [int(_x) for _x in seq_lens][:4],
                            "stash": _stash[:-1],
                            "hk8": _rk8[0].detach().cpu().clone(),
                            "hv8": _rv8[0].detach().cpu().clone(),
                        }, "/tmp/r218_wtrace_dumps/onset%02d.pt" % _trig[0])
            except Exception:
                pass
'''
s = s.replace(aA, pA + aA)
open(p, "w").write(s)
print("wtrace2 patched")
