#!/bin/bash
set -u
RUN=/home/n00928095/R218_UPSTREAM_WORK/verify_scripts/async_diag.sh
env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS=12 bash "$RUN" p6g_krv_async int2exp R117_MID_DIAG=1 R218_KRVDBG=1
docker exec r218-main-verify bash -lc 'mkdir -p /tmp/r218_p6/p6g_krv_async && mv /tmp/r117_mid_e_diag.jsonl /tmp/r218_krv_diag.jsonl /tmp/r218_p6/p6g_krv_async/ 2>/dev/null; true'
docker cp r218-main-verify:/tmp/r218_p6/p6g_krv_async /tmp/r218_p6_host/ >/dev/null 2>&1 || true
env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS=12 bash "$RUN" p6h_krv_blk int2exp R117_MID_DIAG=1 R218_KRVDBG=1 ASCEND_LAUNCH_BLOCKING=1
docker exec r218-main-verify bash -lc 'mkdir -p /tmp/r218_p6/p6h_krv_blk && mv /tmp/r117_mid_e_diag.jsonl /tmp/r218_krv_diag.jsonl /tmp/r218_p6/p6h_krv_blk/ 2>/dev/null; true'
docker cp r218-main-verify:/tmp/r218_p6/p6h_krv_blk /tmp/r218_p6_host/ >/dev/null 2>&1 || true
echo DONE
