#!/bin/bash
# R218 subagent A: async-vs-blocking diagnostic driver (NPU 7, inside the
# r218-main-verify container). Must be launched through the flock wrapper:
#   flock /tmp/r218_npu7.lock -c 'bash async_diag.sh <tag> <mode> [KEY=VAL ...]'
# modes: int2 | bf16
# Runs the 6x4 middle battery (ragged l4 l4mix long2) and stores raw output.
set -u
TAG="$1"; MODE="$2"; shift 2
LOGDIR=/tmp/r218_async_diag
mkdir -p "$LOGDIR"
OUT="$LOGDIR/battery_${TAG}.txt"
CT=r218-main-verify
CTL=/tmp/serve_${TAG}.log

echo "$(date -Is) start tag=$TAG mode=$MODE extra=$*" > "$LOGDIR/${TAG}.status"
# kill BOTH the api-server parent and the EngineCore child (the child is
# re-titled VLLM::EngineCore, so the entrypoint pattern alone leaks it and the
# next serve OOMs on device memory).
for pat in 'vllm.entrypoints.cli.main' 'VLLM::EngineCore'; do
  docker exec "$CT" bash -lc "pkill -9 -f '$pat'" >/dev/null 2>&1
done
sleep 5

ENVARGS=()
for kv in "$@"; do ENVARGS+=(-e "$kv"); done

if [ "$MODE" = "int2" ]; then
  SRV="bash /home/n00928095/R218_UPSTREAM_WORK/verify_scripts/serve_int2.sh"
elif [ "$MODE" = "int2exp" ]; then
  SRV="bash /home/n00928095/R218_UPSTREAM_WORK/verify_scripts/serve_int2_exp.sh"
elif [ "$MODE" = "bf16" ]; then
  SRV="bash /home/n00928095/R218_UPSTREAM_WORK/verify_scripts/serve_bf16.sh"
else
  echo "bad mode" >&2; exit 2
fi

docker exec -d "${ENVARGS[@]}" "$CT" bash -lc "exec $SRV > $CTL 2>&1"
ready=0
for i in $(seq 1 200); do
  code=$(docker exec "$CT" curl -s -o /dev/null -w '%{http_code}' http://localhost:8000/health 2>/dev/null || true)
  if [ "$code" = "200" ]; then ready=1; break; fi
  if ! docker exec "$CT" bash -lc "pgrep -f 'vllm.entrypoints.cli.main|VLLM::EngineCore' >/dev/null"; then
    echo "server died before ready"; break
  fi
  sleep 2
done
echo "$(date -Is) ready=$ready" >> "$LOGDIR/${TAG}.status"
if [ "$ready" != "1" ]; then
  docker exec "$CT" bash -lc "tail -40 $CTL" > "$LOGDIR/${TAG}.serve_tail.txt" 2>&1
  for pat in 'vllm.entrypoints.cli.main' 'VLLM::EngineCore'; do docker exec "$CT" bash -lc "pkill -9 -f '$pat'" >/dev/null 2>&1; done
  echo "NOT-READY" >> "$LOGDIR/${TAG}.status"
  exit 3
fi

FILES=${R218_DIAG_FILES:-"ragged l4 l4mix long2"}
REPS=${R218_DIAG_REPS:-6}
for i in $(seq 1 "$REPS"); do
  for f in $FILES; do
    docker exec "$CT" curl -s --max-time 300 http://localhost:8000/v1/completions \
      -H "Content-Type: application/json" -d @/tmp/${f}_req.json >> "$OUT"
    echo >> "$OUT"
  done
done

for pat in 'vllm.entrypoints.cli.main' 'VLLM::EngineCore'; do
  docker exec "$CT" bash -lc "pkill -9 -f '$pat'" >/dev/null 2>&1
done
sleep 5
python3 /home/n00928095/R218_UPSTREAM_WORK/verify_scripts/analyze_battery.py "$OUT" $FILES > "$LOGDIR/${TAG}.analysis.txt" 2>&1
echo "$(date -Is) done" >> "$LOGDIR/${TAG}.status"
tail -2 "$LOGDIR/${TAG}.analysis.txt"
