#!/bin/bash
set -u
sleep 25
RUN=/home/n00928095/R218_UPSTREAM_WORK/verify_scripts/async_diag.sh
env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS=12 bash "$RUN" p6z_pristine_async int2exp
echo FINAL-CHECK-DONE
