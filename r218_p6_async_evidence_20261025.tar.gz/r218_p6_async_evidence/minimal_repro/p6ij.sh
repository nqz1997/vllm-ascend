#!/bin/bash
set -u
RUN=/home/n00928095/R218_UPSTREAM_WORK/verify_scripts/async_diag.sh
env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS=12 bash "$RUN" p6i_sfix_async int2exp R166_STREAMFIX=ring
env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS=12 bash "$RUN" p6j_eslide_async int2exp R164_EAGER_SLIDE=1
echo BOTH-DONE
