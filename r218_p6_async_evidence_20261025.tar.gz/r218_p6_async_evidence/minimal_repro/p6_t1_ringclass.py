#!/usr/bin/env python3
"""R218 T1 formal ring-row three-class classifier (wave 4, CPU-only).

Input: ring-row capture dirs produced by the R218_RINGROWDBG probe
(<dir>/r218_ringrows/rNN_lNN.pt, keys idx/layer/hk/hv; hk [mhp, nkv, hd]
bf16 = HP ring row of slot b=0 at the FIRST captured decode step of rep NN,
i.e. BEFORE that step's append; state = end of previous rep + this rep's
prefill writes).

Semantics for the x1080x1 geometry (prompt 1082, R109_TT_PREFIX=128,
R109_TT_RECENT=896, R199_PRREAD=1 -> mhp=1024):
  mid window   = [128, 186)  (INT2 paged tier, askv=58)
  valid read set at the captured step (sl=1082, rcnt=896 pinned)
             = prefix rows [0, 128) + recent rows [128, 1024)
  -> EVERY row of the captured row is inside the valid read set.

Three classes (per request/layer/row):
  A valid-data corruption   : row is non-finite (NaN/Inf) inside the read set
  B unused-slot difference  : row differs but lies OUTSIDE any valid read set
                              (margin rows [1024, mhp) if mhp>1024; other
                              slots' rows -- not captured by the probe)
  C legal rebinding/drift   : finite row differing across reps where the
                              difference is explainable by legal generation
                              drift (ring content is documented to differ per
                              generation even in blocking; see PR_ADVANCE
                              section 9 review note on p6a).

Also reports the NaN bit payload (canonical qNaN 0x7FC0 vs 0x7FFF) and the
per-rep per-layer NaN block boundary + growth, and the in/out-of-read-set
verdict for the attention-consumption question.

Usage: p6_t1_ringclass.py ASYNC_DIR [BLK_DIR]
"""
import glob
import json
import os
import sys

import torch

READ_LO, READ_HI = 128, 1024


def rows_nan(t):
    return torch.isnan(t).any(dim=(1, 2))


def classify_dir(d, label):
    pats = ["r218_ringrows/r*.pt", "ringrows/r218_ringrows/r*.pt", "r*.pt"]
    files = []
    for p in pats:
        files = sorted(glob.glob(os.path.join(d, p)))
        if files:
            break
    out = {"label": label, "reps": {}}
    for f in files:
        t = torch.load(f, map_location="cpu")
        rep = int(os.path.basename(f).split("_")[0][1:])
        lay = int(t["layer"])
        hk, hv = t["hk"], t["hv"]
        nk, nv = rows_nan(hk), rows_nan(hv)
        inf_k = torch.isinf(hk).any(dim=(1, 2))
        nanidx = torch.nonzero(nk).flatten().tolist()
        # payload census
        payloads = {}
        if nanidx:
            u16 = hk.view(torch.uint16)[nk].to(torch.int32)
            for v in u16.unique().tolist():
                payloads[hex(v)] = int((u16 == v).sum())
        in_read = [r for r in nanidx if READ_LO <= r < READ_HI]
        out_read = [r for r in nanidx if not (READ_LO <= r < READ_HI)]
        fin = torch.isfinite(hk).all(dim=(1, 2))
        # finite-row magnitude sanity (class C support)
        fr = hk[READ_LO:READ_HI][fin[READ_LO:READ_HI]]
        r = out["reps"].setdefault(rep, {})
        r[lay] = {
            "nan_rows": len(nanidx),
            "span": [min(nanidx), max(nanidx) + 1] if nanidx else None,
            "v_nan_rows": int(nv.sum()),
            "inf_rows": int(inf_k.sum()),
            "payloads": payloads,
            "nan_in_valid_read_set": len(in_read),
            "nan_outside_read_set": len(out_read),
            "finite_row_absmax": (None if fr.numel() == 0
                                  else float(fr.float().abs().max())),
        }
    return out


def main(da, db=None):
    A = classify_dir(da, "async")
    print(json.dumps({"meta": {
        "valid_read_set": [READ_LO, READ_HI],
        "capture_point": "first captured decode step of each rep (pre-append)",
        "probe": "R218_RINGROWDBG slot b=0, hk/hv [mhp,nkv,hd] bf16",
    }}, indent=1))
    for rep in sorted(A["reps"]):
        lays = A["reps"][rep]
        l08 = lays.get(8, {})
        l16 = lays.get(16, {})
        allnan_in = sum(v["nan_in_valid_read_set"] for v in lays.values())
        allnan_out = sum(v["nan_outside_read_set"] for v in lays.values())
        payloads = {}
        for v in lays.values():
            for k, c in v["payloads"].items():
                payloads[k] = payloads.get(k, 0) + c
        print(f"rep{rep:02d} layers={len(lays)} "
              f"l08_nan={l08.get('nan_rows', 0)} span={l08.get('span')} "
              f"l16_nan={l16.get('nan_rows', 0)} span={l16.get('span')} "
              f"TOTAL_nan_in_read_set={allnan_in} outside={allnan_out} "
              f"payloads={payloads}")
    if db:
        B = classify_dir(db, "blocking")
        # cross-mode finite-row comparison (logical-token aligned is impossible
        # across legs: ring content legally differs per generation; report the
        # blocking NaN census as the reference class-A count)
        print("== blocking reference census ==")
        for rep in sorted(B["reps"]):
            lays = B["reps"][rep]
            tot = sum(v["nan_rows"] for v in lays.values())
            print(f"rep{rep:02d} layers={len(lays)} total_nan_rows={tot}")


if __name__ == "__main__":
    main(*sys.argv[1:])
