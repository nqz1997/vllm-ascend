#!/bin/bash
# R218 wave-4 device legs (NPU 7, inside flock /tmp/r218_npu7.lock).
# W1 p6e_cap_async  : MIDCAP2 operand capture (R216_LSEDUMP), async, 3 reps
# W2 p6f_cap_blk    : same + ASCEND_LAUNCH_BLOCKING=1
# W4 p6m_wtrace_async : R218_WTRACE + R117_MID_DIAG (patched tree), async, 12 reps
# W5 p6n_wtrace_blk   : same + blocking
# Patch lifecycle: pristine -> W1/W2 -> apply wtrace_patch.py -> W4/W5 -> restore.
set -u
RUN=/home/n00928095/R218_UPSTREAM_WORK/verify_scripts/async_diag.sh
CT=r218-main-verify
H=/tmp/r218_p6_host
mkdir -p "$H"

clean() {
  for pat in 'vllm.entrypoints.cli.main' 'VLLM::EngineCore'; do
    docker exec "$CT" bash -lc "pkill -9 -f '$pat'" >/dev/null 2>&1
  done
  sleep 5
}

harvest() {  # tag
  local tag="$1"
  docker exec "$CT" bash -lc "mkdir -p /tmp/r218_p6/$tag && \
    mv /tmp/r218_midcap2_*.pt /tmp/r218_p6/$tag/ 2>/dev/null; \
    mv /tmp/r117_mid_e_diag.jsonl /tmp/r218_p6/$tag/ 2>/dev/null; \
    mv /tmp/r218_wtrace.jsonl /tmp/r218_p6/$tag/ 2>/dev/null; \
    cp -r /tmp/r218_wtrace_dumps /tmp/r218_p6/$tag/ 2>/dev/null; true"
  docker cp "$CT:/tmp/r218_p6/$tag" "$H/$tag" >/dev/null 2>&1 || true
  docker exec "$CT" bash -lc "rm -rf /tmp/r218_wtrace_dumps /tmp/r218_p6" 2>/dev/null || true
}

leg() {  # tag mode reps extra-env...
  local tag="$1" mode="$2" reps="$3"; shift 3
  echo "=== $(date -Is) leg $tag start (mode=$mode reps=$reps extra=$*)"
  clean
  docker exec "$CT" bash -lc "mkdir -p /tmp/r218_wtrace_dumps"
  env R218_DIAG_FILES=x1080x1 R218_DIAG_REPS="$reps" bash "$RUN" "$tag" "$mode" "$@"
  harvest "$tag"
  echo "=== $(date -Is) leg $tag done: $(tail -1 /tmp/r218_async_diag/${tag}.analysis.txt 2>/dev/null)"
}

case "${1:-all}" in
  caps)
    leg p6e_cap_async int2exp 3 R216_LSEDUMP=1 R216_LSEDUMP_MINBP=1
    leg p6f_cap_blk   int2exp 3 R216_LSEDUMP=1 R216_LSEDUMP_MINBP=1 ASCEND_LAUNCH_BLOCKING=1
    ;;
  wtrace)
    leg p6m_wtrace_async int2exp 12 R218_WTRACE=1 R117_MID_DIAG=1
    leg p6n_wtrace_blk   int2exp 12 R218_WTRACE=1 R117_MID_DIAG=1 ASCEND_LAUNCH_BLOCKING=1
    ;;
  all)
    leg p6e_cap_async int2exp 3 R216_LSEDUMP=1 R216_LSEDUMP_MINBP=1
    leg p6f_cap_blk   int2exp 3 R216_LSEDUMP=1 R216_LSEDUMP_MINBP=1 ASCEND_LAUNCH_BLOCKING=1
    leg p6m_wtrace_async int2exp 12 R218_WTRACE=1 R117_MID_DIAG=1
    leg p6n_wtrace_blk   int2exp 12 R218_WTRACE=1 R117_MID_DIAG=1 ASCEND_LAUNCH_BLOCKING=1
    ;;
esac
echo "=== wave4 legs complete $(date -Is)"
