#!/usr/bin/env python3
"""Diff two R117_MID_DIAG hash streams (async vs blocking) record by record.

Each jsonl record: {mode, layer, cnt, mid, askv, nb_now, bt, src_k, src_v, q,
curblk_k, slotmap, src_ks, ring_k, ring_v, rk_pre, rk_r0, rk_r1, rk_r2,
rk_tail, rv_tail, rk_slots, rv_slots, [raw_*]}
plus post-launch records {mode: eager_oh, cnt, oh, lh, mid}.

Report: per record index, first differing field; summary of which field
diverges first overall. bt lists may legitimately differ between reps
(block ids assigned by prefix cache state) — reported separately.
"""
import json
import sys


def load(p):
    recs = []
    with open(p) as f:
        for line in f:
            line = line.strip()
            if line:
                recs.append(json.loads(line))
    return recs


def main(pa, pb):
    A, B = load(pa), load(pb)
    print(f"A={len(A)} records  B={len(B)} records")
    n = 0
    first_div = None
    div_fields = {}
    for i, (a, b) in enumerate(zip(A, B)):
        if a.get("mode") != b.get("mode"):
            print(f"[{i}] MODE {a.get('mode')} vs {b.get('mode')}")
            first_div = first_div or ("mode", i)
            continue
        if a.get("mode") == "eager_oh":
            diffs = [k for k in ("oh", "lh") if a.get(k) != b.get(k)]
        else:
            keys = ["src_k", "src_v", "q", "curblk_k", "src_ks",
                    "ring_k", "ring_v", "rk_pre", "rk_r0", "rk_r1", "rk_r2",
                    "rk_tail", "rv_tail", "rk_slots", "rv_slots"]
            diffs = [k for k in keys if a.get(k) != b.get(k)]
            if a.get("bt") != b.get("bt"):
                diffs.append("(bt)")
        if diffs:
            n += 1
            if first_div is None:
                first_div = (diffs[0], i)
                print(f"[{i}] FIRST DIVERGENCE layer={a.get('layer')} mid={a.get('mid')} "
                      f"askv={a.get('askv')} fields={diffs}")
                print(f"    A: {json.dumps({k: a.get(k) for k in diffs})[:400]}")
                print(f"    B: {json.dumps({k: b.get(k) for k in diffs})[:400]}")
            else:
                for d in diffs:
                    div_fields[d] = div_fields.get(d, 0) + 1
    print(f"records with divergence: {n}/{min(len(A), len(B))}")
    print(f"divergence field histogram: {json.dumps(div_fields, ensure_ascii=False)}")
    if first_div:
        print(f"first divergence: field={first_div[0]} at record #{first_div[1]}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
