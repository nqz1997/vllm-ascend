# R218 wave-7 serve-leg HANDOFF (2026-10-26 02:3xZ) — 接续点（写给任何接手会话）

## 分工（已互认）
- 本会话（腿侧）：NPU 腿、容器 bind 树 /workspace（=host /home/n00928095/R218_UPSTREAM_WORK/oscar_port_ut_tree）唯一写者、serve 证据。
- workspace-2e（CPU 侧，uds:/tmp/cc-socks/4052202.sock）：m-pr-14/16 属主修复推送＋级联 17/18/19-22、四 Draft PR #19764-67 转 ready、PR 评注、§11、最终台账。
- B/C 结果接收人＝workspace-2e（SendMessage）；PR 收尾＝workspace-2e。勿依赖后台提醒。

## 状态（02:3xZ）
- w7wA ✅ total=24 bad=0（INT2 默认异步混合电池 ragged/l4/l4mix/long2×6）
- w7wB ⏳ 运行中（02:20:46 起，生命周期/槽复用 14 文件×3=42 请求）
- w7wC ⏳ 排队（BF16 dev6，6 文件×3；serve_bf16.sh 无 INT2 env＝opt-out 验证点）
- 驱动 /tmp/w7_legs5.sh（pid 见 pgrep -f w7_legs5）；flock /tmp/r218_npu7.lock 串行；监听任务 beemn00nl（"ALL w7w LEGS DONE" 触发）。
- 收集命令：`grep -E 'LEG w7w|ALL w7w' /tmp/r218_w7_legs/legs.log`；逐腿 `tail -3 /tmp/r218_async_diag/w7w{A,B,C}.analysis.txt`；身份 `cat /tmp/r218_w7_legs/w7w*.identity.txt`；原始 `cat /tmp/r218_async_diag/battery_w7w*.txt`；日志 `docker exec r218-main-verify cat /tmp/serve_w7w{A,B,C}.log`。
- 服务收尾（腿全部完成后）：`pkill -f w7_legs5`；`docker exec r218-main-verify bash -lc "pkill -9 -f 'vllm.entrypoints.cli.main|VLLM::EngineCore'"`；监听任务已在后台自然结束（TaskStop 不需要）。

## 被测树身份（运行时＝当前）
- 源码：worktree /tmp/mpr19_wt @HEAD 30f7f2005 ＋未提交修复（①opool getattr×16：middle_candidate/middle_exec hasattr→getattr None 判；②2e 的 xaudit 缓存等小改）＋容器限定 layernorm [R218-CT-SHIM]（仅 bind 树，须 PR 评注披露）。
- [R218ID] 实测 sha256[:16]=81f6adc06cca333e（attention_v1）；git blob sha1=1a3228056（**未推送**——推送 m-pr-20=eb4693ce 落后一轮，2e 须推平）。
- 制品：vllm_ascend_C.cpython-312 .so=eeebeb7c（/vllm-workspace 9.2 构建，gitignored）；libcust_opapi.so=树内 csrc/build（经 op_api/lib 符号链接 shim＋R218_EXTRA_OPP 上 ASCEND_CUSTOM_OPP_PATH，serve_int2.sh:42 已加附加钩子）；launcher r152 sha256=41bce535（#19570 边界修复版，[R112-FAST] r113.orch.v9+r145v3+r218p7bound 实载）；vendor 链 oscar_r144_v133c_grp(c8a8d47a)/r133/r116/r106。
- 无容器临时路径依赖：腿全部走 /workspace bind 树；shim 目录在树内；OPP env 是显式注入（记录在案）。

## bad 判据（勿混淆存活≠正确）
- analyze_battery.py：bad=无 choices 或文本含 '!!!'（损坏标记）；**不等于答案正确**。收尾须补逐请求确定性（同请求跨 rep 文本一致）＋BF16 参考对照（旧 bf16a 腿无存储答案——以 w7wC 自身 rep 间一致性＋默认后端无 INT2 加载为准）。

## 02:4xZ 更新
- flock 队列现状：2e 的 fin_tree_int2 服务在跑（serve_fin_tree_int2.log，APIServer 02:20:51 起）→ 我的 w7wB/w7wC 排其后。w7wB 的 0 响应＝排队中，非挂死。
- **确定性检查（/tmp/determ_check.py）**：w7wA 24 响应全有效但**4/4 文件跨 rep 文本全变**（"FieldType…/backstage…/umerator…"型重复汤）——按用户口径这是"存活≠正确"的关键证据：默认异步下 INT2 decode 非确定（与 r218-int2-decode-perturbation-characterized 的扰动类一致）；P7 旧电池判据仅 '!!!' 标记，不可宣称答案正确。**报告时如实分层：bad=0（损坏标记零）＋跨 rep 非确定（已知扰动类）＋无逐题参考对照**。
- 槽复用证据命令（B 腿完成后）：`docker exec r218-main-verify bash -c "grep -cE 'finish_reason' /tmp/serve_w7wB.log"`（完成事件）＋`grep -E 'free|release|slot' /tmp/serve_w7wB.log | head`（释放/复用）＋42 请求单实例（同一 pid 横跨全程＝生命周期≥2 轮）。缺直接槽号证据就如实标注。
- BF16 opt-out 证据：serve_bf16.sh 无 INT2 env；w7wC 日志应无 [R218ROT]/R112-FAST/int2 加载行（identity.txt 应为空或仅 [R218ID]）。

## 03:2xZ 终局（所有腿完成 02:57:06Z）
- **结果**：w7wA INT2 24/24 有效（判据=有 choices 且无 '!!!' 损坏标记）；w7wB INT2 39/39；
  w7wC BF16 21/21（identity 仅 [R218ID] 81f6adc0，无任何 INT2 横幅＝opt-out 确认）；
  fin_tree_int2 60/60 有效（首行 ERR 为 01:33Z 修复前崩溃残留：runner 追加不截断、
  02:20:46Z 实跑恰 60 POST 全 200、单引擎初始化）；fin_tree_bf16 60/60。
- **正确性分层（PAIRED_ANALYSIS.txt，已归档）**：贪心 temp=0 同输入 BF16/INT2 配对
  45/60 全同、15/60 首 token 分岔、0 措辞漂移（双峰）；BF16 响应内 n 样本 21/21 自一致、
  INT2 36/60；INT2 14/201 非 ASCII 重复尾（BF16 0/201）；跨 rep BF16 4/7 文件稳、
  3/7（l4/s4/reuse）两态翻转，INT2 全文件 4-6 态。**不宣称答案正确**（电池为合成续写探针，
  无 ground truth；答案正确性证据=冻结组合评测组）。
- **槽复用**：调度器级（单 EngineCore 跨 39 请求、Running 0↔8、NS=32 池装 39 请求必复用）；
  无槽号级日志（诊断 env 关）——如实标注。
- **最终树闭环（blob 15/15）**：m-pr-22=67e1c80c6 树内 9 关键文件 == /tmp/mpr19_wt ==
  被测 bind 树（attention_v1 blob 1a322805＝运行时 81f6adc0）；overlay 其余文件在所有者
  分支逐一相等（config→m-pr-01 c1d1772b5、int2_quant→m-pr-02 bc7bd8578、
  ring/r116→m-pr-1012 1c972c980、attention_int2→m-pr-19 372d654a6、prefill→m-pr-18
  b43f052b8）；懒建属性修复在 m-pr-14 6122caebc（middle_candidate 9df844c40）与
  m-pr-16 6c5b2f5a9（middle_exec da60c6f62）。30f7f2005 的 middle 文件**含 getattr 守卫**
  （candidate 9 处；"bare-only 无 getattr"的描述有误，但推送内容＝被测字节，链条成立）。
- **#19764 依赖链已补 #19728**（本会话 PATCH，已验证）。#19767 mergeable_state=dirty（待 CI 重算）。
- **收尾**：stale waiter pid 19249 已杀；容器内 vllm/EngineCore 无残留；驱动/监听器自然退出。
  交接：PR/CI/文章分支提交＝workspace-2e；NPU 腿与证据＝本会话（已归档
  /home/n00928095/R218_UPSTREAM_WORK/delivery/r218_wave7_final/，21 文件）。
